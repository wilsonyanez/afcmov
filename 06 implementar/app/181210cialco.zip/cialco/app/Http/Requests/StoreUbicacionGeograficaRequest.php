<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreUbicacionGeograficaRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
		
        return [
            'uge_codigo_ubicacion' =>'required',
            'uge_nivel' =>'integer|required',
            'uge_nombre' =>'alpha|max:256|required',
            'uge_estado' =>'required',
        ];
    }
    public function messages()
    {
        return [
            'uge_codigo_ubicacion.required' => 'Código Ubicación es requerido',
            'uge_nivel.required' => 'Nivel es requerido',
            'uge_nombre.required' => 'Nombre es requerido',
            'uge_estado.required' => 'Estado es requerido',
        ];
    }
}