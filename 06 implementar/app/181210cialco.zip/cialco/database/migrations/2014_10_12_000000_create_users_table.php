<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('usuarios', function (Blueprint $table) {
            $table->increments('usu_id');
            $table->string('usu_nombre');
            // campos requeridos para logeo laravel
            $table->string('username')->unique();
            $table->string('password');
            $table->string('email')->unique();

            $table->boolean('usu_estado')->default(1);
            $table->timestamp('usu_fecha_creacion')->nullable();
            $table->timestamp('usu_fecha_actualizacion')->nullable();
            // campos requeridos para logeo laravel
            $table->timestamp('email_verified_at')->nullable();
            $table->rememberToken();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('usuarios');
    }
}
