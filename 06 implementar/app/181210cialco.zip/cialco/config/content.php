<?php
return [
    'session'=>[
        'create'=> 'El registo fue agregado correctamente',
        'update'=>'El registro fue actualizado correctamente',
        'error'=>'Ocurrió un error'
    ]
];
