/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Wilson Yánez
 */
public class EstablecimientoDesdeMovil {
    private String establecimiento;
    private String establecimientoDetv;
    private String establecimientoDeth;

    public EstablecimientoDesdeMovil() {
    }

    public EstablecimientoDesdeMovil(String establecimiento, String establecimientoDetv, String establecimientoDeth) {
        this.establecimiento = establecimiento;
        this.establecimientoDetv = establecimientoDetv;
        this.establecimientoDeth = establecimientoDeth;
    }

    public String getEstablecimiento() {
        return establecimiento;
    }

    public void setEstablecimiento(String establecimiento) {
        this.establecimiento = establecimiento;
    }

    public String getEstablecimientoDetv() {
        return establecimientoDetv;
    }

    public void setEstablecimientoDetv(String establecimientoDetv) {
        this.establecimientoDetv = establecimientoDetv;
    }

    public String getEstablecimientoDeth() {
        return establecimientoDeth;
    }

    public void setEstablecimientoDeth(String establecimientoDeth) {
        this.establecimientoDeth = establecimientoDeth;
    }
    
    public void imprimirForm(){
        System.out.println(establecimiento+" "+establecimientoDetv+" "+establecimientoDeth);
    }

}