<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFrecuencaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('frecuencia', function (Blueprint $table) {
            $table->increments('fre_frecuencia_id');
            $table->text('fre_descripcion');
            $table->integer('fre_orden')->default(0);

            // COLUMNAS DE CONTROL
            $table->boolean('fre_estado')->default(true);

            $table->date('fre_fecha_inicio')->nullable();
            $table->date('fre_fecha_fin')->nullable();

            $table->integer('fre_usuario_inserta')->unsigned()->nullable();
            $table->timestamp('fre_fecha_inserta')->nullable();

            $table->integer('fre_usuario_actualiza')->unsigned()->nullable();
            $table->timestamp('fre_fecha_actualiza')->nullable();

            $table->integer('fre_usuario_elimina')->unsigned()->nullable();
            $table->timestamp('fre_fecha_elimina')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('frecuencia');
    }
}
