

<?php $__env->startSection('title', 'Nuevo Representante'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Representante</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   <?php echo Form::open(['route' => 'cialco.representante.store', 'method' => 'post']); ?>


    <div class="box box-primary">
        <?php echo e(Form::hidden('rep_cialco_id',$cialco->cia_cialco_id,['class'=>'form-control'])); ?>

        <div class="box-header with-border">
            <h3 class="box-title">Nuevo</h3>
        </div>
        <div class="box-body">
            <div class="row"> <!-- ROW 1 -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="rep_identificacion">Identificación</label>
                        <?php echo e(Form::text('rep_identificacion',null,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'rep_identificacion'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="rep_contacto">Nombre</label>
                        <?php echo e(Form::text('rep_contacto',null,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'rep_contacto'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="rep_correo_electronico">Correo</label>
                        <?php echo e(Form::text('rep_correo_electronico',null,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'rep_correo_electronico'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
            <div class="row"> <!-- ROW 1 -->
				<div class="col-md-3">
					<label for="rep_fecha_inicio">Fecha Inicio</label>
						<?php echo e(Form::date('rep_fecha_inicio', null, array('id' => 'datepicker'))); ?>

						<?php echo $__env->make('include.error_form_element',['name'=>'rep_fecha_inicio'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
				<div class="col-md-3">
				<label for="rep_fecha_fin">Fecha Fin</label>
						<?php echo e(Form::date('rep_fecha_fin', null, array('id' => 'datepicker'))); ?>

						<?php echo $__env->make('include.error_form_element',['name'=>'rep_fecha_fin'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="rep_estado">Estado</label>
                        <?php echo e(Form::select('rep_estado',['1' => 'Activo', '0' => 'Inactivo'],null,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'rep_estado'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
        </div>


        <div class="box-footer">
            <button type="submit" class="btn btn-primary">Guardar</button>
        </div>
        <?php echo Form::close(); ?>

        <div class="box-footer">
            <a href="<?php echo e(URL::previous()); ?>" class="pull-right btn btn-default">Regresar</a>
        </div>

        <?php $__env->stopSection(); ?>



        <?php $__env->startSection('css'); ?>

            <link rel="stylesheet" href="/css/admin_custom.css">

        <?php $__env->stopSection(); ?>



        <?php $__env->startSection('js'); ?>

            <script> console.log('Hi!'); </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>