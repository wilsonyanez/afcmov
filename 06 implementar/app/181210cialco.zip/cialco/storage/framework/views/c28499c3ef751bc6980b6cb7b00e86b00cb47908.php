
<?php $__env->startSection('title', 'Frecuencia'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Frecuencia</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo Form::model($result, ['method' => 'PATCH','route' => ['frecuencia.update', 'id'=>$result->fre_frecuencia_id]]); ?>

    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Catálogo Frecuencia</h3>
        </div>
        <div class="box-body">
            <div class="row"> <!-- ROW 1 -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="fre_descripcion">Descripción</label>
                        <?php echo e(Form::text('fre_descripcion',$result->fre_descripcion,['class'=>'form-control'])); ?>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="fre_estado">Estado</label>
                        <?php echo e(Form::select('fre_estado',['1' => 'Activo', '0' => 'Inactivo'],$result->fre_estado,['class'=>'form-control'])); ?>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="fre_orden">Orden</label>
                        <?php echo e(Form::number('fre_orden',$result->fre_orden,['class'=>'form-control'])); ?>

                    </div>
                </div>
            </div>
        </div>

        <div class="box-footer">
            <button type="submit" class="btn btn-primary">Editar</button>
        </div>
        <?php echo Form::close(); ?>

        <div class="box-footer">
            <a href="<?php echo e(URL::previous()); ?>" class="pull-right btn btn-default">Regresar</a>
        </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('css'); ?>
        <link rel="stylesheet" href="/css/admin_custom.css">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>