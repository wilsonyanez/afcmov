
<?php $__env->startSection('title', 'Organizaciones'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Organizaciones</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::open(['route' => 'organizacion.store','method'=> 'post']); ?>

    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Organización</h3>
        </div>
        <div class="box-body">
            <div class="row"> <!-- ROW 1 -->
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="org_hecho_derecho">Organización Hecho/Derecho</label>
                        <?php echo e(Form::select('org_hecho_derecho',['1' => 'Hecho', '0' => 'Derecho'],null,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'org_hecho_derecho'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="org_ruc">RUC</label>
						<?php echo e(Form::text('org_ruc',null,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'org_ruc'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="org_razon_social">Razon Social</label>
                        <?php echo e(Form::text('org_razon_social',null,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'org_razon_social'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
            <div class="row">   <!-- ROW 2 -->
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="org_registro_seps">Registro SEPS</label>
                        <?php echo e(Form::select('org_registro_seps',['1' => 'SI', '0' => 'NO'],null,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'org_registro_seps'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="org_acreditado_mag">Acreditado MAG</label>
                        <?php echo e(Form::select('org_acreditado_mag',['1' => 'SI', '0' => 'NO'],null,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'org_acreditado_mag'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
            <div class="row">  <!-- ROW 3 -->
                <div class="col-md-3">
					<div class="form-group">
						<label for="org_nro_productores_hombres">Nro Productores Hombres</label>
						<?php echo e(Form::number('org_nro_productores_hombres',null,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'org_nro_productores_hombres'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="org_nro_productores_mujeres">Nro Productores Mujeres</label>
						<?php echo e(Form::number('org_nro_productores_mujeres',null,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'org_nro_productores_mujeres'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="org_nro_productores_total">Nro Productores Total</label>
						<?php echo e(Form::number('org_nro_productores_total',null,['class'=>'form-control'])); ?>

						<?php echo $__env->make('include.error_form_element',['name'=>'org_nro_productores_total'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
            </div>
            <div class="row">  <!-- ROW 4 -->
				<div class="col-md-3">
					<div class="form-group">
						<label for="org_fecha_inicio">Fecha Inicio</label></br>
						<?php echo e(Form::date('org_fecha_inicio', null, array('id' => 'datepicker'))); ?>

						<?php echo $__env->make('include.error_form_element',['name'=>'org_fecha_inicio'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
                </div>
				<div class="col-md-3">
                    <div class="form-group">
						<label for="org_fecha_fin">Fecha Fin</label></br>
						<?php echo e(Form::date('org_fecha_fin', null, array('id' => 'datepicker'))); ?>

						<?php echo $__env->make('include.error_form_element',['name'=>'org_fecha_fin'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
                </div>
				<div class="col-md-3">
                    <div class="form-group">
                        <label for="org_estado">Estado</label>
                        <?php echo e(Form::select('org_estado',['1' => 'Activo', '0' => 'Inactivo'],null,['class'=>'form-control'])); ?>

						<?php echo $__env->make('include.error_form_element',['name'=>'org_fecha_inicio'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="box-footer">
            <button type="submit" class="btn btn-primary">Crear</button>
        </div>
        <?php echo Form::close(); ?>

        <div class="box-footer">
            <a href="<?php echo e(URL::previous()); ?>" class="pull-right btn btn-default">Regresar</a>
        </div>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('css'); ?>
            <link rel="stylesheet" href="/css/admin_custom.css">
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>