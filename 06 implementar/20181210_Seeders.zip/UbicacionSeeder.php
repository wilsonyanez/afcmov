<?php

use Illuminate\Database\Seeder;

class UbicacionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $sql = __DIR__.'/sql/181006_POS-crear-db_mov-afc.sql';
        DB::unprepared(file_get_contents($sql));

        // Cargar manualmente el scrip SQL de ubicación
       /* $sql = __DIR__.'/sql/181007_POS-insertar-db_mov-afc.sql';
        DB::unprepared(file_get_contents($sql));*/

    }
}
