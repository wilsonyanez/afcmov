<?php

namespace App\Catalogs;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ApoyoInstitucional extends Model
{
    protected $table = 'apoyo_institucional';
    protected $primaryKey = 'ain_apoyo_institucional_id';

    const CREATED_AT = 'ain_fecha_inserta';
    const UPDATED_AT = 'ain_fecha_actualiza';

    use SoftDeletes;
    const DELETED_AT = 'ain_fecha_elimina';

    protected $append = [
        'texto_estado',
        'texto_estado_html'
    ];

    protected $fillable = [
        'ain_descripcion',
        'ain_estado',
        'ain_orden',
        'ain_fecha_inicio'
    ];

    public function ApoyoInstitucional()
    {
        return $this->belongsTo('App\Catalogs\ApoyoInstitucional', 'ain_apoyo_institucional_id');
    }

    public function getTextoEstadoAttribute()
    {
        return ($this->ain_estado ? 'Activo' : 'Inactivo');
    }

    public function getTextoEstadoHtmlAttribute()
    {
        if ($this->ain_estado)
            return ('<span class="label label-success">' . $this->texto_estado . '</span>');
        return ('<span class="label label-default">' . $this->texto_estado . '</span>');
    }
}