  <div class="row">
    <div class="col-md-12">
      <h4><b>Funcionamiento</b></h4>
      <hr/>
    </div>
  </div>


  <div class="row">
     <div class="col-md-4">
        <div class="form-group">
          <label for="exampleInputEmail1">Estado</label>
          <select class="form-control">
            <option>ACTIVO</option>
            <option>PASIVO</option>
          </select>
          <p>
            <span class="label label-primary">Boolean</span>
          </p>
        </div>
      </div>
  </div>



  <div class="row">
    <div class="col-md-6">
      <div class="form-group">
        <label for="exampleInputEmail1">Horario inicio</label>
        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Horario inicio">
        <p>

          <span class="label label-info">fecha ?</span>
        </p>
      </div>
    </div>

    <div class="col-md-6">
      <div class="form-group">
        <label for="exampleInputEmail1">Horario Fin</label>
        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Horario Fin">
        <p>
          <span class="label label-info">fecha ?</span>
        </p>
      </div>
    </div>

  </div>
  <!-- /.row -->

  <div class="row">
    <div class="col-md-6">
      <div class="form-group">
        <label for="exampleInputEmail1">Día :</label>
        <div>
          <input type="checkbox"> L
          <input type="checkbox"> M
          <input type="checkbox"> Mi
          <input type="checkbox"> J
          <input type="checkbox"> V
          <input type="checkbox"> S
          <input type="checkbox"> D
        </div>

        <p>
          <span class="label label-info">numérico ?</span>
          <span class="label label-warning">formato de entrada ? : </span>
        </p>
      </div>
    </div>
    <div class="col-md-4">
      <div class="form-group">
        <label for="exampleInputEmail1">Frecuencia</label>
        <select class="form-control">
          <option>Diaria</option>
          <option>Semanal</option>
          <option>Quincenal</option>
          <option>Mensual</option>

        </select>
        <p>
          <span class="label label-info">Dropdown? de base actual existe? no nueva?</span>
        </p>
      </div>
    </div>


  </div>
  <!-- /.row -->

<div class="row">
    <div class="col-md-12">
      <h4><b>Coordenadas Geográficas del CIALCO</b></h4>
      <hr/>
    </div>
</div>
    <div class="row">
      <div class="col-md-12">
      <b>Coordenadas en X</b>
      </div>

      <div class="col-md-4">
        <div class="form-group">
          <label for="exampleInputEmail1">Grados</label>
          <input type="email" class="form-control" id="exampleInputEmail1" placeholder="">
          <p>
            <span class="label label-primary">STRING</span>
          </p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="form-group">
          <label for="exampleInputEmail1">Minutos</label>
          <input type="email" class="form-control" id="exampleInputEmail1" placeholder="">
          <p>
                       <span class="label label-primary">STRING</span>
         </p>
       </div>
     </div>
       <div class="col-md-4">
        <div class="form-group">
          <label for="exampleInputEmail1">Segundos</label>
          <input type="email" class="form-control" id="exampleInputEmail1" placeholder="">
          <p>
                       <span class="label label-primary">STRING</span>
         </p>
       </div>
     </div>
   </div>
   <!-- /.row -->
       <div class="row">
         <div class="col-md-12">
         <b>Coordenadas en Y</b>
         </div>

         <div class="col-md-4">
           <div class="form-group">
             <label for="exampleInputEmail1">Grados</label>
             <input type="email" class="form-control" id="exampleInputEmail1" placeholder="">
             <p>
               <span class="label label-primary">STRING</span>
             </p>
           </div>
         </div>
         <div class="col-md-4">
           <div class="form-group">
             <label for="exampleInputEmail1">Minutos</label>
             <input type="email" class="form-control" id="exampleInputEmail1" placeholder="">
             <p>
                          <span class="label label-primary">STRING</span>
            </p>
          </div>
        </div>
          <div class="col-md-4">
           <div class="form-group">
             <label for="exampleInputEmail1">Segundos</label>
             <input type="email" class="form-control" id="exampleInputEmail1" placeholder="">
             <p>
                          <span class="label label-primary">STRING</span>
            </p>
          </div>
        </div>
      </div>
      <!-- /.row -->

<div class="row">
    <div class="col-md-12">
      <h4><b>Zona UTM</b></h4>
      <hr/>
    </div>
</div>
    <div class="row"><!--  ROW 2 -->

      <div class="col-md-4">
        <div class="form-group">
          <label for="exampleInputEmail1">Norte</label>
          <select class="form-control">
            <option>15N</option>
            <option>16N</option>
            <option>17N</option>
            <option>18N</option>

          </select>
        </div>
      </div>

      <div class="col-md-4">
        <div class="form-group">
          <label for="exampleInputEmail1">Sur</label>
          <select class="form-control">
            <option>15S</option>
            <option>16S</option>
            <option>17S</option>
            <option>18S</option>
          </select>

        </div>
      </div>



    </div><!-- CLOSE ROW 2 -->