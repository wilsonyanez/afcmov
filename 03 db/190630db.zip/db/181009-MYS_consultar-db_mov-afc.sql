SELECT * FROM sirusafc.productor WHERE CODIGO_INI = '1111111111201810220735' ; 
SELECT * FROM sirusafc.productor WHERE CEDULA_PROD in ('1716128911', '1709364135') ; 
SELECT CODIGO_PROD, CODIGO_INI, CEDULA_PROD, LUGAR_DOMICILIO_PROD, LUGAR_PROV_PROD, LUGAR_CAN_PROD FROM sirusafc.productor WHERE CODIGO_INI = '1111111111201810220735' ; 

SELECT DISTINCT LUGAR_DOMICILIO_PROD FROM productor ;
SELECT DISTINCT CODIGO_PUE_IND FROM productor ;
SELECT * FROM `prueba`.`productor ; 

SELECT DISTINCT TIPO_DEPRO FROM destino_produccion ORDER BY TIPO_DEPRO ; 
AGRICOLA
APICOLA
AVICOLA
BOVINO
CUYES
FORESTAL
OVINO_CAPRINO
PORCICOLA

SELECT DISTINCT TIPO_COMPRADOR_DEPRO FROM destino_produccion ORDER BY TIPO_COMPRADOR_DEPRO ;
0
1
10
11
12
2
3
4
5
7
9
undefined

SELECT * FROM destino_produccion WHERE CODIGO_INI IN ('1016305300857', '1016304140939', '1000403130926', '1000405081531', '1000406091427', '1000406200839', '1024701300901', '1000401300934') ORDER BY CODIGO_INI; 

SELECT * FROM sirusafc.base_reg_civil ;
SELECT * FROM sirusafc.base_reg_civil WHERE CEDULA in ('1716128911', '0703023960', '1709364135', '1709084618') ;
SELECT * FROM base_reg_civil WHERE CEDULA in ('0100967652', '0703023960', '1727223339', '1755840889', '0702354978', '1706172648', '1704997012', '1714818299', '1715241434', '0917385288', '1707527097', '1716638372') ;


SELECT count(*) FROM sirusafc.base_sri ;
SELECT * FROM sirusafc.base_sri ;
SELECT CODIGO, RUC, RAZON_SOCIAL, DIRECCION_LARGA, DIRECCION_CORTA, TELEFONO_TRABAJO, TELEFONO_DOMICILIO, REPRE_LEGAL_NOMBRE, REPRE_LEGAL_IDEN, ESTADO, CODIGO_FIG_ORG, NUMERO_SOCIOS, CORREO FROM sirusafc.base_sri WHERE ESTADO = 'A' ;

SELECT * FROM sirusafc.organizacion_hecho ;
SELECT * FROM sirusafc.afc_infraestructura_m10 ;
SELECT * FROM sirusafc.afc_equipamientom11 ;

SELECT * FROM sirusafc.catalogo_asistencia_objetivo;
1	Aspectos T�cnicos	1
2	Comercializaci�n	2
3	Fortalecimiento Asociativo	3
4	Agroturismo	4
5	Otro	5
SELECT * FROM sirusafc.asistencia_tecnica ;



SELECT * FROM sirusafc.productor WHERE 2
SELECT * FROM sirusafc.productor WHERE CODIGO_PROD IN (701, 703, 709, 714, 962) ; 

SELECT * FROM sirusafc.productor WHERE CODIGO_INI = '1111111111201810220735' ; 
SELECT * FROM sirusafc.productor WHERE CODIGO_PROD IN (820, 962) ; 
SELECT * FROM sirusafc.base_sri WHERE CODIGO IN (57, 58) ; 

SELECT * FROM sirusafc.productor_organizacion ;
701	24
703	27
709	28
709	29
714	30
714	31

SELECT * FROM sirusafc.productor_organizacion 
SELECT * FROM sirusafc.productor_organizacion WHERE CODIGO_PROD = 962 AND CODIGO IN (57, 58) ;
DELETE FROM sirusafc.productor_organizacion WHERE CODIGO_PROD = 820 AND CODIGO = '1716128911';
DELETE FROM sirusafc.productor_organizacion WHERE CODIGO = '1716128911';
SELECT * FROM sirusafc.productor_organizacion WHERE CODIGO IN (56, 57) ;
DELETE FROM sirusafc.productor_organizacion WHERE CODIGO IN (56, 57) ;

SELECT * FROM sirusafc.productor_organizacion_hecho ; 
SELECT * FROM sirusafc.organizacion_hecho ;
SELECT * FROM sirusafc.organizacion_hecho WHERE CODIGO_PROD = 962 ;
DELETE FROM sirusafc.organizacion_hecho WHERE CODIGO_PROD = 962 ;
SELECT * FROM sirusafc.organizacion_hecho WHERE CORREO = '1709364135' ;
DELETE FROM sirusafc.organizacion_hecho WHERE CORREO = '1709364135' ;

SELECT * FROM sirusafc.datos_inicial WHERE USUARIO_CREA_INI = '1709084618' ;
CODIGO_USR,CI_USR,NOMBRE_USR,APELLIDO_USR,LOGIN_USR,PASSWORD_USR,DIRECCION_USR,MAIL_USR,TELEFONO_USR,CELULAR_USR,ESTADO_USR,CODIGO_PER 

INSERT INTO sirusafc.usuarios (CI_USR,NOMBRE_USR,APELLIDO_USR,LOGIN_USR,PASSWORD_USR,DIRECCION_USR,MAIL_USR,TELEFONO_USR,CELULAR_USR,ESTADO_USR) VALUES 
('1709084618','LIBERTAD','TRUJILLO', '1709084618', '12345', 'SAN JOSE Y DE LOS NOGALES CONJ. ENTREPINOS CASA 6-06', 'libertadt@hotmail.com', '3263155', '0992610937', 'A'),
('1709364135','WILSON','YANEZ', '1709364135', '11111', 'SAN JOSE Y DE LOS NOGALES CONJ. ENTREPINOS CASA 6-06', 'wilsonyanez@hotmail.com', '3263155', '0987475903', 'A');

UPDATE sirusafc.usuarios SET LOGIN_USR = '1709364135' WHERE CODIGO_USR = 445 ; 

SELECT CODIGO_USR, CI_USR, NOMBRE_USR, APELLIDO_USR, LOGIN_USR FROM sirusafc.usuarios WHERE ESTADO_USR = 'A' ORDER BY CI_USR; 
SELECT CODIGO_USR, CI_USR, NOMBRE_USR, APELLIDO_USR, LOGIN_USR FROM sirusafc.usuarios WHERE CI_USR IN ('1709084618', '1709364135' ) AND ESTADO_USR = 'A' ORDER BY CI_USR; 

/* ********************************************* */
/* ****************** TERRENOS ***************** */
/* ********************************************* */
SELECT * FROM sirusafc.terrenos WHERE CODIGO_INI = '1709084618120190102200327' ;
DELETE FROM sirusafc.terrenos WHERE CODIGO_INI = '1709084618120190102200327' ;

/* ********************************************* */
/* ************* DESTINO_PRODUCCION ************ */
/* ********************************************* */
SELECT * FROM sirusafc.destino_produccion WHERE CODIGO_INI = '1709084618120190102200327' ;
DELETE FROM sirusafc.destino_produccion WHERE CODIGO_INI = '1709084618120190102200327' ;


SELECT * FROM sirusafc.datos_inicial WHERE USUARIO_CREA_INI = '1709084618' ;