@extends('adminlte::page')
@section('title', 'Organizaciones')
@section('content_header')
    <h1>Organizaciones</h1>
@stop
@section('content')
    <div class="box box-primary">
        <div class="box-header with-border">
            <h2 class="page-header"><i class="fa fa-globe"></i>Detalle Organizaciones</h2>

            <div class="row invoice-info">
                <div class="col-sm-4 invoice-col">
                    <p><b>ID: </b>{{$result->org_organizacion_id}}</p>
                    <p><b>Hecho Derecho: </b>{!!$result->texto_hecho_derecho_html!!}</p>
                    <p><b>RUC: </b>{{$result->org_ruc}}</p>
                    <p><b>Razon Social: </b>{{$result->org_razon_social}}</p>
                    <p><b>Registro SEPS: </b>{!!$result->texto_registro_seps_html!!}</p>
                    <p><b>Acreditado MAG: </b>{!!$result->texto_acreditado_mag_html!!}</p>
                    <p><b>Nro Productores Total: </b>{{$result->org_nro_productores_total}}</p>
                    <p><b>Nro Productores Hombres: </b>{{$result->org_nro_productores_hombres}}</p>
                    <p><b>Nro Productores Mujeres: </b>{{$result->org_nro_productores_mujeres}}</p>
                    <p><b>Fecha Inicio: </b>{{$result->org_fecha_inicio}}</p>
                    <p><b>Fecha Fin: </b>{{$result->org_fecha_fin}}</p>
                    <p><b>Estado: </b>{!!$result->texto_estado_html!!}</p>
                    <p><b>Fecha Creación: </b>{{$result->org_fecha_inserta}}</p>
                </div>
            </div>
            <div class="box-footer">
                <a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
            </div>
        </div>

	@stop
	@section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
	@stop
	@section('js')
@stop