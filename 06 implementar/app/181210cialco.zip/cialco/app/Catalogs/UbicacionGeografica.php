<?php

namespace App\Catalogs;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class UbicacionGeografica extends Model
{
    protected $table='ubicacion_geografica';
    protected $primaryKey = 'uge_ubicacion_geografica_id';

    const CREATED_AT = 'uge_fecha_inserta';
    const UPDATED_AT = 'uge_fecha_actualiza';

    use SoftDeletes;
    const DELETED_AT = 'uge_fecha_elimina';

    protected $append = [
        'texto_estado',
        'texto_estado_html'
    ];

    protected $fillable = [
        'uge_codigo_ubicacion',
        'uge_nivel',
        'uge_nombre',
        'uge_padre_ubicacion',
        'uge_estado'
    ];
    public function ubicaciongeografica()
    {
        return $this->belongsTo('App\Catalogs\UbicacionGeografica', 'uge_ubicacion_geografica_id');
    }
    public function getTextoEstadoAttribute()
    {
        return ($this->uge_estado ? 'Activo' : 'Inactivo');
    }
    public function getTextoEstadoHtmlAttribute()
    {
        if ($this->uge_estado)
            return ('<span class="label label-success">' . $this->texto_estado . '</span>');
        return ('<span class="label label-default">' . $this->texto_estado . '</span>');
    }
}