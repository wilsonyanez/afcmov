<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreApoyoInstitucionalRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'ain_descripcion' =>'alpha|max:128|required',
            'ain_orden' =>'integer|required',
            'ain_fecha_inicio' =>'date|required',
            'ain_estado' =>'required',
        ];
    }
    public function messages()
    {
        return [
            'ain_descripcion.required' => 'Descripción es requerido',
            'ain_orden.required' => 'Orden es requerido',
            'ain_fecha_inicio.required' =>'Fecha inicio es requirido',
            'ain_estado.required' => 'Estado es requerido',

        ];
    }
}