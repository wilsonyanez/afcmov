<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class CialcoOfertaAgropecuaria extends Model
{
    protected $table = 'cialco_oferta_agropecuaria';
    protected $primaryKey = 'coa_cialco_oferta_agro_id';
    const CREATED_AT = 'coa_fecha_inserta';
    const UPDATED_AT = 'coa_fecha_actualiza';

    use SoftDeletes;
    const DELETED_AT = 'coa_fecha_elimina';

    protected $append = [
        'texto_estado',
        'texto_estado_html'
    ];

    protected $fillable = [
        "coa_descripcion_otro",
        "coa_fecha_inicio",
        "coa_fecha_fin",
        "coa_estado",
		"coa_cialco_id",
        "coa_oferta_agropecuaria_id"
    ];

    public function ofertaAgropecuaria()
    {
        return $this->belongsTo('App\Catalogs\ofertaAgropecuaria', 'coa_oferta_agropecuaria_id');
    }

    public function cialco()
    {
        return $this->belongsTo('App\Entities\Cialco', 'coa_cialco_id');
    }

    public function getTextoEstadoAttribute()
    {
        return ($this->coa_estado ? 'Activo' : 'Inactivo');
    }

    public function getTextoEstadoHtmlAttribute()
    {
        if ($this->coa_estado)
            return ('<span class="label label-success">' . $this->texto_estado . '</span>');
        return ('<span class="label label-default">' . $this->texto_estado . '</span>');
    }
}