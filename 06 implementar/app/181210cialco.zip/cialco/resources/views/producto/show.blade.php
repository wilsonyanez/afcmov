@extends('adminlte::page')
@section('title', 'Productos')
@section('content_header')
    <h1>Productos</h1>
@stop
@section('content')
    <div class="box box-primary">
        <div class="box-header with-border">
            <h2 class="page-header"><i class="fa fa-globe"></i>Detalle de Productos</h2>
            <div class="row invoice-info">
                <div class="col-sm-4 invoice-col">
                    <p><b>ID: </b>{{$result->prd_producto_id}}</p>
                    <p><b>Código Producto: </b>{{$result->prd_codigo_producto}}</p>
                    <p><b>Nivel: </b>{{$result->prd_nivel}}</p>
                    <p><b>Nombre: </b>{{$result->prd_nombre}}</p>
                    <p><b>Padre Producto: </b>{{$result->prd_padre_producto}}</p>
                    <p><b>Fecha Inicio: </b>{{$result->prd_fecha_inicio}}</p>
                    <p><b>Fecha Fin: </b>{{$result->prd_fecha_fin}}</p>
                    <p><b>Estado: </b>{!!$result->texto_estado_html!!}</p>
                </div>
            </div>
            <div class="box-footer">
                <a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
            </div>
        </div>
    @stop
    @section('css')
      <link rel="stylesheet" href="/css/admin_custom.css">
    @stop
    @section('js')
@stop
