

<?php $__env->startSection('title', 'Frecuencia'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Frecuencia</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="box box-primary">
        <div class="box-header with-border">
            <h2 class="page-header">
                <i class="fa fa-globe"></i> Listado
                <a class="btn btn-sm btn-default pull-right" href="<?php echo e(route('frecuencia.create')); ?>">Nuevo</a>
            </h2>
        </div>
        <div class="row">
            <div class="col-xs-12 table-responsive">
                <table class="table table-striped">
                <tr>

                  <th>ID</th>
                  <th>Descripción</th>
                  <th>Orden</th>
                  <th>Fecha Inicio</th>
                  <th>Fecha Fin</th>
                  <th>Fecha Creación</th>
                  <th>Estado</th>
                  <th>Acciones</th>
                </tr>
                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                       <td><?php echo e($key+1); ?></td>
                       <td><?php echo e($item->fre_descripcion); ?></td>
                       <td><?php echo e($item->fre_orden); ?></td>
					   <td><?php echo e($item->fre_fecha_inicio); ?></td>
					   <td><?php echo e($item->fre_fecha_fin); ?></td>
                       <td><?php echo e($item->fre_fecha_inserta); ?></td>
                       <td><?php echo $item->texto_estado_html; ?></td>
                        <td>
                            <a href="<?php echo e(route('frecuencia.show',['id'=>$item->fre_frecuencia_id])); ?> "class="label label-primary">Ver</a>
                            <a href="<?php echo e(route('frecuencia.edit',['id'=>$item->fre_frecuencia_id])); ?>" class="label label-primary">Editar</a>
                        </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </table>
        </div>
        </div>
        <div class="box-footer">
        
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>