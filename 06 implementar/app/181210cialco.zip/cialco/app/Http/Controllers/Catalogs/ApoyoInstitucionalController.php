<?php

namespace App\Http\Controllers\Catalogs;

use App\Catalogs\ApoyoInstitucional;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use App\Http\Controllers\Controller;

class ApoyoInstitucionalController extends Controller
{
    public function index()
    {
        $results = ApoyoInstitucional::orderBy('ain_orden','ASC')->get();
        return view('apoyoinstitucional.index', ['results' => $results]);
    }

    public function show($id)
    {

        $result = ApoyoInstitucional::find($id);
        return view('apoyoinstitucional.show', ['result' => $result]);
    }

    public function edit($id)
    {    $order = [
        1 => 1,
        2 => 2,
        3 => 3,
        4 => 4,
        5 => 5,
        6 => 6,
        7 => 7,
        8 => 8,
        9 => 9,
        10 => 10,
    ];
        $result = ApoyoInstitucional::find($id);
        return view('apoyoinstitucional.edit', ['result' => $result,'order'=>$order]);
    }

    public function create()
    {    $order = [
        1 => 1,
        2 => 2,
        3 => 3,
        4 => 4,
        5 => 5,
        6 => 6,
        7 => 7,
        8 => 8,
        9 => 9,
        10 => 10,
    ];
        return view('apoyoinstitucional.create',['order'=>$order]);
    }

    public function store(Request $request)
    {
        try {
            // INSERT
            $result = new ApoyoInstitucional;
            $result->ain_usuario_inserta = Auth::id();
            $result->fill($request->all())->save();

            Session::flash('flash_message', config('content.session.create'));
        } catch (\Exception $e) {
            Session::flash('error', config('content.session.create'));
            return back()->withInput();
        }

        return redirect()->route('apoyoinstitucional.index');
    }

    public function update(Request $request, $id)
    {
        // TODO incluir try
        try {
            request()->validate([
                'ain_descripcion' => 'required',
                'ain_fecha_inicio' => 'required',
                'ain_estado' => 'required',
            ]);

            // UPDATE
            $result = ApoyoInstitucional::find($id);
            $result->ain_usuario_actualiza = Auth::id();
            $result->fill($request->all())->update();

            Session::flash('flash_message', config('content.session.update'));
        } catch (\Exception $e) {
            Session::flash('error', content('content.session.error'));
            return back()->withInput();
        }

        return redirect()->route('apoyoinstitucional.index');
    }

    public function destroy($id)
    {
        // NOT REQUIRED
        /*$result=ApoyoInstitucional::find($id);
        $result->ain_usuario_elimina=Auth::id();
        $result->delete();*/
    }
}