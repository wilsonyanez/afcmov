<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCialcoInterinstitucionalTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cialco_interinstitucional', function (Blueprint $table) {
            $table->increments('int_cialco_interins_id');
            $table->boolean('int_provincial')->nullable()->default(false);
            $table->integer('int_gad_provincial_id')->unsigned()->nullable()->default(0);
            $table->boolean('int_cantonal')->nullable()->default(false);
            $table->integer('int_gad_cantonal_id')->unsigned()->nullable()->default(0);
            $table->boolean('int_parroquial')->nullable()->default(false);
            $table->integer('int_gad_parroquial_id')->unsigned()->nullable()->default(0);
            $table->boolean('int_ong')->nullable()->default(false);
            $table->boolean('int_coop_internacional')->nullable()->default(false);
            $table->boolean('int_instituto_universidad')->nullable()->default(false);
            $table->boolean('int_colectivos')->nullable()->default(false);
            $table->boolean('int_empresa_privada')->nullable()->default(false);
            $table->boolean('int_otro')->nullable()->default(false);
            $table->text('int_descripcion_otro')->nullable();
            $table->boolean('int_mag')->nullable()->default(false);
            $table->text('int_descripcion');
			
            // COLUMNAS DE CONTROL
            $table->boolean('int_estado')->default(true);

            $table->date('int_fecha_inicio');
            $table->date('int_fecha_fin')->nullable();

            $table->integer('int_usuario_inserta')->unsigned()->nullable();
            $table->timestamp('int_fecha_inserta')->nullable();

            $table->integer('int_usuario_actualiza')->unsigned()->nullable();
            $table->timestamp('int_fecha_actualiza')->nullable();

            $table->integer('int_usuario_elimina')->unsigned()->nullable();
            $table->timestamp('int_fecha_elimina')->nullable();

            // FOREINGS
            $table->unsignedInteger('int_accion_fortalecimiento_id');
            $table->foreign('int_accion_fortalecimiento_id')->references('afr_accion_fortalecimiento_id')->on('accion_fortalecimiento');
            $table->unsignedInteger('int_cialco_id');
            $table->foreign('int_cialco_id')->references('cia_cialco_id')->on('cialco');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cialco_interinstitucional');
    }
}