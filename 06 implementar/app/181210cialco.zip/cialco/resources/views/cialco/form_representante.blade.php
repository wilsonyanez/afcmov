 <div class="row">
        <div class="col-md-12">
          <h4><b>Representante CIALCO</b></h4>
          <ul>
            <li>El formulario aparece al presionar el boton NUEVO</li>
            <li>El formulario aparece cuanso se selecciona la opción Editar de la tabla</li>
            <li>Los registros se almacenarán en una tabla hija llamada <b>contacto_representante</b></li>
            </ul>
           <p>


                       </p>
          <hr/>
        </div>
  </div>


  <div class="row">

        <div class="col-md-6">
          <label for="exampleInputEmail1">Identificación representante</label>
          <div class="input-group">

            <input type="text" class="form-control" placeholder="CI">
            <span class="input-group-btn">
              <button type="button" class="btn btn-info btn-flat">Buscar</button>
            </span>
          </div>
           <p>
               <span class="label label-primary">STRING</span>
               <span class="label label-warning">Consulta a SRI para carga de información</span>
             </p>
        </div>

   <div class="col-md-6">
        <div class="form-group">
          <label for="exampleInputEmail1">Nombre representante</label>
          <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Nombre representante">
          <p>
            <span class="label label-primary">STRING</span>
            <span class="label label-warning">Automático luego de consulta</span>

          </p>
        </div>
      </div>
     </div>

        <div class="row">
             <br>
              <div class="col-md-6">
             <div class="form-group">
               <label for="exampleInputEmail1">Fecha de inicio</label>
               <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Fecha de inicio">
               <p>
                 <span class="label label-primary">FECHA</span>
                 <span class="label label-warning">Validación: año 1930 - 2030</span>

               </p>
             </div>
           </div>
           <div class="col-md-6">
             <div class="form-group">
               <label for="exampleInputEmail1">Fecha Finalización</label>
               <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Fecha Finalización">
               <p>
                <span class="label label-primary">FECHA</span>
                <span class="label label-warning">Validación: año 1930 - 2030</span>
              </p>
            </div>
          </div>
          </div>






 <div class="row">
    <div class="col-md-6">
      <div class="form-group">
        <label for="exampleInputEmail1">Teléfono de contacto</label>
        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Teléfono de contacto">
        <p>
          <span class="label label-defaul">STRING</span>
        </p>
      </div>
    </div>

  </div>

  <div class="row">
  <div class="col-md-12">
    <button type="submit" class="btn btn-success">Guardar información Representante</button>
  </div>
  <hr/>
  </div>

    <div class="row">
    <div class="col-md-12">
    <table class="table table-bordered">
                    <tr>
                      <th style="width: 10px">Identificación</th>
                      <th>Nombre de Representante</th>
                      <th>Telefono de contacto</th>
                      <th>Fecha Inicio</th>
                      <th>Fecha Fin</th>
                      <th>Estado</th>
                      <th>Acciones</th>
                    </tr>
                    @for($i=0; $i<5;$i++)
                                      <tr>
                                        <td>1234567890</td>
                                        <td>Contacto {{$i+1}}</td>
                                        <td>593123123</td>
                                        <td>01/01/2018</td>
                                        <td>01/01/2018</td>
                                        <td>
                                        @if($i==0)
                                        <span class="badge bg-green">ACTIVO</span>
                                        @else
                                        <span class="badge bg-default">INACTIVO</span>
                                        @endif
                                        </td>
                                        <td>
                                        <a href="#">Editar</a>
                                        </td>
                                      </tr>
                    @endfor

                  </table>
      <button type="submit" class="btn btn-primary">Nuevo Representante</button>
    </div>
    </div>
