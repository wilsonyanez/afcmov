<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDireccionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('direccion', function (Blueprint $table) {
            $table->increments('dir_direccion_id');

            $table->text('dir_sector')->nullable();
            $table->text('dir_calle_principal')->nullable();
            $table->text('dir_numero')->nullable();
            $table->text('dir_calle_secundaria')->nullable();
            $table->text('dir_referencia')->nullable();
            $table->integer('dir_consumidores')->default(0);

            // COLUMNAS DE CONTROL
            $table->boolean('dir_estado')->default(true);

            $table->date('dir_fecha_inicio')->nullable();
            $table->date('dir_fecha_fin')->nullable();

            $table->integer('dir_usuario_inserta')->unsigned()->nullable();
            $table->timestamp('dir_fecha_inserta')->nullable();

            $table->integer('dir_usuario_actualiza')->unsigned()->nullable();
            $table->timestamp('dir_fecha_actualiza')->nullable();

            $table->integer('dir_usuario_elimina')->unsigned()->nullable();
            $table->timestamp('dir_fecha_elimina')->nullable();

            // FOREINGS
            $table->unsignedInteger('dir_cialco_id');
            $table->foreign('dir_cialco_id')->references('cia_cialco_id')->on('cialco');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('direccion');
    }
}
