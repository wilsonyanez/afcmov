
<?php $__env->startSection('title', 'Frecuencia'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Frecuencia</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::model($result, ['method' => 'PATCH','route' => ['apoyoinstitucional.update', 'id'=>$result->ain_apoyo_institucional_id]]); ?>

    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Catálogo Frecuencia</h3>
        </div>
        <div class="box-body">
            <div class="row"> <!-- ROW 1 -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="ain_descripcion">Descripción</label>
                        <?php echo e(Form::text('ain_descripcion',$result->ain_descripcion,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'ain_descripcion'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
            <div class="row">
                 <div class="col-md-3">
                    <div class="form-group">
                        <label for="ain_orden">Orden</label>
                        <?php echo e(Form::number('ain_orden',$result->ain_orden,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'ain_descripcion'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
                 <div class="col-md-3">
                    <div class="form-group">
                        <label for="ain_fecha_inicio">Fecha Inicio</label>
                        <?php echo e(Form::text('ain_fecha_inicio',$result->ain_fecha_inicio,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'ain_fecha_inicio'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="ain_estado">Estado</label>
                        <?php echo e(Form::select('ain_estado',['1' => 'Activo', '0' => 'Inactivo'],$result->ain_estado,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'ain_estado'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="box-footer">
            <button type="submit" class="btn btn-primary">Editar</button>
        </div>
        <?php echo Form::close(); ?>

        <div class="box-footer">
            <a href="<?php echo e(URL::previous()); ?>" class="pull-right btn btn-default">Regresar</a>
        </div>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('css'); ?>
            <link rel="stylesheet" href="/css/admin_custom.css">
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>