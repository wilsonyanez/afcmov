<?php

use Illuminate\Database\Seeder;

class CialcoInterinstitucionalSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('cialco_interinstitucional')->delete();
        $faker = Faker\Factory::create();

        for ($i = 0; $i < 200; $i++) {
            \DB::table('cialco_interinstitucional')->insert([

                'int_provincial' =>$faker->numberBetween(0,1),
                'int_gad_provincial_id' => $faker->numberBetween(0, 24),
                'int_cantonal' =>$faker->numberBetween(0,1),
                'int_gad_cantonal_id' =>$faker->numberBetween(25,200),
                'int_parroquial' =>$faker->numberBetween(0,1),
                'int_gad_parroquial_id' =>$faker->numberBetween(201,349),
/*                'int_ong' =>$faker->numberBetween(0,1),
                'int_coop_internacional' =>$faker->numberBetween(0,1),
                'int_instituto_universidad' =>$faker->numberBetween(0,1),
                'int_colectivos' =>$faker->numberBetween(0,1),
                'int_empresa_privada' =>$faker->numberBetween(0,1), */
                'int_otro' =>$faker->numberBetween(0,1),
/*                'int_descripcion_otro' => $faker->word,
                'int_mag' =>$faker->numberBetween(0,1), */
                'int_descripcion' => $faker->word,

                'int_fecha_inicio' => date_create('now UTC'),
                'int_fecha_fin' => date_create('now UTC'),

                'int_fecha_inserta' => date_create('now UTC'),
                'int_fecha_actualiza' => date_create('now UTC'),

                /*                'int_apoyo_institucional_id' => ApoyoInstitucional::inRandomOrder()->get()->first()->int_apoyo_institucional_id, */
                'int_apoyo_institucional_id' => $faker->numberBetween(1, 10),
                /*                'coa_cialco_interinstitucional_id' => AccionFortalecimiento::inRandomOrder()->get()->first()->int_accion_fortalecimiento_id, */
                'int_accion_fortalecimiento_id' => $faker->numberBetween(1, 6),
                /*                'coa_cialco_id' => Cialco::inRandomOrder()->get()->first()->cia_cialco_id,    */
                'int_cialco_id' => $faker->numberBetween(1, 100),
            ]);
        }

    }
}
