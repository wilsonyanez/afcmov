

<?php $__env->startSection('title', 'Direcciones'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Direcciones</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Listado</h3>
            
        </div>
        <div class="box-body table-responsive no-padding">
              <table class="table table-hover">
                <tr>

                  <th>CIALCO</th>
                  <th>Sector</th>
                  <th>Calle Principal</th>
                  <th>Número</th>
                  <th>Fecha Inicio</th>
                  <th>Fecha Fin</th>
                  <th>Estado</th>
                </tr>
                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                       <td><a href="<?php echo e(route('cialco.show',['id'=>$item->dir_cialco_id])); ?>"><i><?php echo e($item->cialco->cia_nombre); ?></i></a></td>

                       <td><?php echo e($item->dir_sector); ?></td>
                       <td><?php echo e($item->dir_calle_principal); ?></td>
                       <td><?php echo e($item->dir_numero); ?></td>
                       <td><?php echo e($item->dir_fecha_inicio); ?></td>
                       <td><?php echo e($item->dir_fecha_fin); ?></td>
                       <td><span class="label label-success">Activo</span></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </table>
        </div>
        <div class="box-footer">
        
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>