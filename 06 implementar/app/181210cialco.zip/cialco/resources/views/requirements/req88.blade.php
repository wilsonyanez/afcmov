@extends('adminlte::page')



@section('title', 'Dashboard')



@section('content_header')

    <h1>RQ22-WEB-HU088</h1>
    <p>Como Técnico de Territorio, quiero Registrar Datos de Participantes del Circuito, que me solicita el Administrador AFC para validar la participación en el Mercado de los Circuitos Alternativos de Comercialización de la AFC.</p>
  "Diseño: Cumplir formato detallado en los archivos:
  RQ22-WEB-HU088-DIS073 Participantes del Circuito.png
  "
  "Usabilidad: Cumplir con el detalle descrito en pestaña funcionalidad con identificación: RQ22-WEB-HU088-FUN
  "
  "Rendimiento: Tiempo de respuesta inferior a 5 segundos
  "
  "Satisfacción: Cumplimiento de Pruebas funcionales
  "
@stop



@section('content')

    <p>Welcome to this beautiful admin panel - HDTuto.com.</p>
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Participantes del Circuito (PRODUCTORES)</h3>
        </div>
        <div class="box-body" class="col-md-12">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="exampleInputEmail1">¿Dispone del Sello Arte?</label>
                            <select class="form-control">
                                <option>Si</option>
                                <option>No</option>
                            </select>
                    </div>
                </div>
            </div><br>

            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Cédula</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Código">
                        <p>
                            <span class="label label-info">Búsqueda?</span>
                            <span class="label label-info">Dropdown?</span>
                        </p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Nombre</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Código">
                        <p>
                            <span class="label label-info">Búsqueda?</span>
                            <span class="label label-info">Dropdown?</span>
                        </p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Apellido</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Nombre">
                        <p>
                            <span class="label label-info">Búsqueda?</span>
                            <span class="label label-info">Dropdown?</span>
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Género</label>
                        <select class="form-control">
                            <option>Femenino</option>
                            <option>Masculino</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Fecha de Nacimiento</label>
                        <input type="date" class="form-control" id="exampleInputEmail1" placeholder="Fecha">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Datos de Identificación del Sello</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Datos de Identificación">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Nacionalidad</label>
                        <select class="form-control">
                            <option>Opción 1</option>
                            <option>Opción 2</option>
                            <option>Opción 3</option>
                            <option>Opción 4</option>
                        </select>
                        <p>
                            <span class="label label-info">Dropdown?</span>
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Fecha de Vinculación a Cialco</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Inicio</label>
                        <input type="date" class="form-control" id="exampleInputEmail1" placeholder="Fecha">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Final</label>
                        <input type="date" class="form-control" id="exampleInputEmail1" placeholder="Fecha">
                    </div>
                    <p>
                        <span class="label label-info">Generar Histórico</span>
                    </p>
                </div>
            </div>
            <div class="row">

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Nacionalidad</label>
                        <select class="form-control">
                            <option>Opción 1</option>
                            <option>Opción 2</option>
                            <option>Opción 3</option>
                            <option>Opción 4</option>
                        </select>
                        <p>
                            <span class="label label-info">Dropdown?</span>
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="box-footer">
            <button type="submit" class="btn btn-primary">Adicionar</button>
        </div>
        <div class="box-footer" align="center">
            <button type="submit" class="btn btn-primary">Anterior</button>
            <button type="submit" class="btn btn-primary">Siguiente</button>
        </div>
    </div>


@stop



@section('css')

    <link rel="stylesheet" href="/css/admin_custom.css">

@stop



@section('js')

    <script> console.log('Hi!'); </script>

@stop