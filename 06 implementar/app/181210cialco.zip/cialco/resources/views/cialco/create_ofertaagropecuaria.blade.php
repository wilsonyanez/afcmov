@extends('adminlte::page')
@section('title', 'Nuevo Oferta Agropecuaria por Cialco')
@section('content_header')
    <h1>Oferta Agropecuaria por Cialco</h1>
@stop
@section('content')
	@include('include.alert')
	{!! Form::open(['route' => 'cialco.ofertaagropecuaria.store', 'method' => 'post']) !!}

	<div class="box box-primary">
		{{ Form::hidden('coa_cialco_id',$cialco->cia_cialco_id,['class'=>'form-control'])}}
		<div class="box-header with-border">
			<h3 class="box-title">Nueva</h3>
		</div>
		<div class="box-body">
		  <div class="row">
			<div class="col-md-3">
			  <div class="form-group">
				<label for="coa_descripcion_otro">Descripción otro</label>
				{{ Form::text('coa_descripcion_otro',null,['class'=>'form-control', 'required' => 'required|alpha'])}}
				@include('include.error_form_element',['name'=>'coa_descripcion_otro'])
			  </div>
              <div class="form-group">
                 <label for="coa_oferta_agropecuaria_id">Oferta Agropecuaria</label>
                     {{ Form::select('coa_oferta_agropecuaria_id',$ofertaagropecuarias,null,['class'=>'form-control'])}}
              </div>
			  <div class="form-group">
				 <label for="coa_fecha_inicio">Fecha Inicio</label></br>
				 {{ Form::date('coa_fecha_inicio', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
				 @include('include.error_form_element',['name'=>'coa_fecha_inicio'])
			  </div>
			  <div class="form-group">
				 <label for="coa_fecha_fin">Fecha Fin</label></br>
				 {{ Form::date('coa_fecha_inicio', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
				 @include('include.error_form_element',['name'=>'coa_fecha_fin'])
			  </div>
			</div>
		  </div>
		  <div class="row">  <!-- ROW 2 -->
			<div class="col-md-3">
			  <div class="form-group">
				<label for="coa_estado">Estado</label>
				{{ Form::select('coa_estado',['1' => 'Activo', '0' => 'Inactivo'],null,['class'=>'form-control'])}}
			  </div>
			</div>
		  </div>
		</div>

	<div class="box-footer">
	  <button type="submit" class="btn btn-primary">Guardar</button>
	</div>
	{!! Form::close() !!}
	<div class="box-footer">
		<a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
	</div>

  @stop
  @section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
  @stop
  @section('js')
	<script> console.log('Hi!'); </script>

@stop