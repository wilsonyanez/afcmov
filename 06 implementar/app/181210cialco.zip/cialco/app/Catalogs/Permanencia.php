<?php

namespace App\Catalogs;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Permanencia extends Model
{
    protected $table='permanencia';
    protected $primaryKey = 'per_permanencia_id';

    const CREATED_AT='per_fecha_inserta';
    const UPDATED_AT='per_fecha_actualiza';

    use SoftDeletes;
    const DELETED_AT = 'per_fecha_elimina';

    protected $append = [
        'texto_estado',
        'texto_estado_html'
    ];

    protected $fillable = [
        'per_descripcion',
        'per_estado',
        'per_orden'
    ];
    public function permanencia()
    {
        return $this->belongsTo('App\Catalogs\Permanencia', 'per_permanencia_id');
    }
    public function getTextoEstadoAttribute()
    {
        return ($this->per_estado ? 'Activo' : 'Inactivo');
    }

    public function getTextoEstadoHtmlAttribute()
    {
        if ($this->per_estado)
            return ('<span class="label label-success">' . $this->texto_estado . '</span>');
        return ('<span class="label label-default">' . $this->texto_estado . '</span>');
    }
}