@extends('adminlte::page')
@section('title', 'Permanencia')
@section('content_header')
    <h1>Permanencia</h1>
@stop
@section('content')
    @include('include.alert')
    <div class="box box-primary">
        <div class="box-header with-border">
            <h2 class="page-header">
                <i class="fa fa-globe"></i> Catálogo Permanencias
                <a class="btn btn-sm btn-default pull-right" href="{{route('permanencia.create')}}">Nuevo</a>
            </h2>
        </div>
        <div class="row">
            <div class="col-xs-12 table-responsive">
                <table class="table table-striped">
                                <tr>
                                  <th>ID</th>
                                  <th>Descripción</th>
                                  <th>Orden</th>
								  <th>Fecha Inicio</th>
								  <th>Fecha Fin</th>
                                  <th>Fecha de creación</th>
                                  <th>Estado</th>
                                  <th>Acciones</th>
                                </tr>
                                @foreach($results as $key=>$item)
                                <tr>
                                    <td>{{$item->per_permanencia_id}}</td>
                                    <td>{{$item->per_descripcion}}</td>
                                    <td>{{$item->per_orden}}</td>
								    <td>{{$item->per_fecha_inicio}}</td>
								    <td>{{$item->per_fecha_fin}}</td>
                                    <td>{{$item->per_fecha_inserta}}</td>
                                    <td>{!!$item->texto_estado_html!!}</td>
                                    <td>
                                        <a href="{{route('permanencia.show',['id'=>$item->per_permanencia_id])}} "class="label label-primary">Ver</a>
                                        <a href="{{route('permanencia.edit',['id'=>$item->per_permanencia_id])}}" class="label label-primary">Editar</a>
                                    </td>
                                </tr>
                                @endforeach
                              </table>
                </div>
        </div>




        <div class="box-footer">
            <a class="btn btn-sm btn-default pull-right" href="{{route('permanencia.create')}}">Nuevo</a>
        </div>

@stop



@section('css')

    <link rel="stylesheet" href="/css/admin_custom.css">

@stop



@section('js')

    <script> console.log('Hi!'); </script>

@stop