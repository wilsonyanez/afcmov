@extends('adminlte::page')
@section('title', 'Frecuencia')
@section('content_header')
    <h1>Frecuencia</h1>
@stop
@section('content')
    {!! Form::model($result, ['method' => 'PATCH','route' => ['frecuencia.update', 'id'=>$result->fre_frecuencia_id]]) !!}
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Catálogo Frecuencia</h3>
        </div>
        <div class="box-body">
            <div class="row"> <!-- ROW 1 -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="fre_descripcion">Descripción</label>
                        {{ Form::text('fre_descripcion',$result->fre_descripcion,['class'=>'form-control', 'required' => 'required|alpha'])}}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="fre_orden">Orden</label>
                        {{ Form::number('fre_orden',$result->fre_orden,['class'=>'form-control', 'required' => 'required|integer'])}}
                    </div>
                </div>
				<div class="col-md-3">
					<div class="form-group">
						<label for="fre_fecha_inicio">Fecha Inicio</label></br>
							{{ Form::date('fre_fecha_inicio', $result->fre_fecha_inicio, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
							@include('include.error_form_element',['name'=>'fre_fecha_inicio'])
					</div>
				</div>
            </div>
            <div class="row"> <!-- ROW 2 -->
				<div class="col-md-3">
					<div class="form-group">
						<label for="fre_fecha_fin">Fecha Fin</label></br>
							{{ Form::date('fre_fecha_fin', $result->fre_fecha_fin, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
							@include('include.error_form_element',['name'=>'fre_fecha_fin'])
					</div>
				</div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="fre_estado">Estado</label>
                        {{ Form::select('fre_estado',['1' => 'Activo', '0' => 'Inactivo'],$result->fre_estado,['class'=>'form-control'])}}
                    </div>
                </div>

            </div>
        </div>

	<div class="box-footer">
		<button type="submit" class="btn btn-primary">Editar</button>
	</div>
	{!! Form::close() !!}
	<div class="box-footer">
		<a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
	</div>
    @stop
    @section('css')
        <link rel="stylesheet" href="/css/admin_custom.css">
    @stop
    @section('js')
@stop