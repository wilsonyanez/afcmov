
<?php $__env->startSection('title', 'Cialco Oferta Agropecuaria'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Cialco Oferta Agropecuaria</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo Form::model($result, ['method' => 'PATCH','route' => ['cialcoofertaagropecuaria.update', 'id'=>$result->coa_cialco_oferta_agro_id]]); ?>

    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Cialco Oferta Agropecuaria</h3>
        </div>
        <div class="box-body">
            <div class="row"> <!-- ROW 1 -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="coa_descripcion_otro">Descripción</label>
                        <?php echo e(Form::text('coa_descripcion_otro',$result->coa_descripcion_otro,['class'=>'form-control'])); ?>

                    </div>
                </div>
            </div>
            <div class="row">  <!-- ROW 2 -->
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="coa_fecha_inicio">Fecha Inicio</label>
                        <?php echo e(Form::text('coa_fecha_inicio',$result->coa_fecha_inicio,['class'=>'form-control'])); ?>

                    </div>
                    <div class="form-group">
                        <label for="coa_fecha_fin">Fecha Fin</label>
                        <?php echo e(Form::text('coa_fecha_fin',$result->coa_fecha_fin,['class'=>'form-control'])); ?>

                    </div>
                </div>
            </div>
            <div class="row">  <!-- ROW 2 -->
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="coa_estado">Estado</label>
                        <?php echo e(Form::select('coa_estado',['1' => 'Activo', '0' => 'Inactivo'],$result->coa_estado,['class'=>'form-control'])); ?>

                    </div>
                </div>
            </div>
        </div>

        <div class="box-footer">
            <button type="submit" class="btn btn-primary">Editar</button>
        </div>
        <?php echo Form::close(); ?>

        <div class="box-footer">
            <a href="<?php echo e(URL::previous()); ?>" class="pull-right btn btn-default">Regresar</a>
        </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('css'); ?>
        <link rel="stylesheet" href="/css/admin_custom.css">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>