@extends('adminlte::page')
@section('title', 'Modalidades')
@section('content_header')
    <h1>Representante</h1>
@stop
@section('content')
    @include('include.alert')
    {!! Form::model($result, ['method' => 'PATCH','route' => ['representante.update', 'id'=>$result->rep_representante_id]]) !!}

    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Catálogo Representante</h3>
        </div>
        <div class="box-body">
            <div class="row"> <!-- ROW 1 -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="rep_identificacion">Identificación</label>
                        {{ Form::text('rep_identificacion',null,['class'=>'form-control', 'required' => 'required|alpha|digits:10'])}}
						@include('include.error_form_element',['name'=>'rep_identificacion'])
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="rep_contacto">Nombre</label>
                        {{ Form::text('rep_contacto',$result->rep_contacto,['class'=>'form-control', 'required' => 'required|alpha'])}}
						@include('include.error_form_element',['name'=>'rep_contacto'])
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="rep_correo_electronico">Correo</label>
                        {{ Form::text('rep_correo_electronico',$result->rep_correo_electronico,['class'=>'form-control', 'required' => 'required|email'])}}
						@include('include.error_form_element',['name'=>'rep_correo_electronico'])
                    </div>
                </div>
            </div>
            <div class="row"> <!-- ROW 2 -->
				<div class="col-md-3">
					<div class="form-group">
						<label for="rep_fecha_inicio">Fecha Inicio</label></br>
							{{ Form::date('rep_fecha_inicio', $result->rep_fecha_inicio, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
							@include('include.error_form_element',['name'=>'rep_fecha_inicio'])
					</div>
				</div>
				<div class="col-md-3">
					<div class="form-group">
						<label for="rep_fecha_fin">Fecha Fin</label></br>
							{{ Form::date('rep_fecha_fin', $result->rep_fecha_fin, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
							@include('include.error_form_element',['name'=>'rep_fecha_fin'])
					</div>
				</div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="rep_estado">Estado</label>
                        {{ Form::select('rep_estado',['1' => 'Activo', '0' => 'Inactivo'],null,['class'=>'form-control'])}}
                    </div>
                </div>
            </div>
        </div>


        <div class="box-footer">
            <button type="submit" class="btn btn-primary">Editar</button>
        </div>
        {!! Form::close() !!}
        <div class="box-footer">
            <a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
        </div>

        @stop
        @section('css')
            <link rel="stylesheet" href="/css/admin_custom.css">
        @stop
        @section('js')
            <script> console.log('Hi!'); </script>
@stop