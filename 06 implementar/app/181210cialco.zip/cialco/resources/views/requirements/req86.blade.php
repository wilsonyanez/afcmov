@extends('adminlte::page')



@section('title', 'Dashboard')



@section('content_header')

    <h1>RQ20-WEB-HU086</h1>
    <p>Principal Oferta Agropecuaria</p>

@stop



@section('content')

        <p>Como Técnico de Territorio, quiero Registrar Datos de Productores y su Principal Oferta Agropecuaria, que me solicita el Administrador AFC para validar la participación en el Mercado de los Circuitos Alternativos de Comercialización de la AFC.</p>
        <ul>
          <li>Diseño: Cumplir formato detallado en los archivos: RQ20-WEB-HU086-DIS071 Principal Oferta Agropecuaria.png</li>
          <li>Usabilidad: Cumplir con el detalle descrito en pestaña funcionalidad con identificación: RQ20-WEB-HU086-FUN</li>
          <li>Objetivo: Registrar Datos de Productores y su Principal Oferta Agropecuaria en WEB. Referncia excel</li>
          <li><b>Inquitudes</b></li>
          </ul>
        <div class="box box-primary">
                    <div class="box-header with-border">
                      <h3 class="box-title">Registro de Oferta Agropecuaria</h3>
                    </div>
                    <div class="box-body">

                        <div class="row">
                                <div class="col-md-12">
                                <div class="form-group">
                                                  <div class="checkbox">
                                                    <label>
                                                      <input type="checkbox">
                                                      <Frutas></Frutas>
                                                    </label>
                                                  </div>

                                                  <div class="checkbox">
                                                    <label>
                                                      <input type="checkbox">
                                                      Hortalizas
                                                    </label>
                                                  </div>

                                                  <div class="checkbox">
                                                    <label>
                                                      <input type="checkbox" >
                                                      Granos Secos
                                                    </label>
                                                  </div>
                                                  <div class="checkbox">
                                                    <label>
                                                      <input type="checkbox">
                                                      Granos Frescos
                                                    </label>
                                                  </div>

                                                  <div class="checkbox">
                                                    <label>
                                                      <input type="checkbox" >
                                                      Granos Secos
                                                    </label>
                                                  </div>

                                                </div>

                                          <p><span class="label label-danger">Dropdown? catalogo de donde viene la información</span></p>
                                    </div>




                        </div>
                        <!-- /.row -->



                    </div>

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Almacenar</button>
                      </div>
            </div>

@stop



@section('css')

    <link rel="stylesheet" href="/css/admin_custom.css">

@stop



@section('js')

    <script> console.log('Hi!'); </script>

@stop