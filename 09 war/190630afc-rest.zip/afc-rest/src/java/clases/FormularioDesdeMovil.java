/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Wilson Yánez
 */
public class FormularioDesdeMovil {
    private String formulario;
    private String formularioDetv;
    private String formularioDeth;

    public FormularioDesdeMovil() {
    }

    public FormularioDesdeMovil(String formulario, String formularioDetv, String formularioDeth) {
        this.formulario = formulario;
        this.formularioDetv = formularioDetv;
        this.formularioDeth = formularioDeth;
    }

    public String getFormulario() {
        return formulario;
    }

    public void setFormulario(String formulario) {
        this.formulario = formulario;
    }

    public String getFormularioDetv() {
        return formularioDetv;
    }

    public void setFormularioDetv(String formularioDetv) {
        this.formularioDetv = formularioDetv;
    }

    public String getFormularioDeth() {
        return formularioDeth;
    }

    public void setFormularioDeth(String formularioDeth) {
        this.formularioDeth = formularioDeth;
    }
    
    public void imprimirForm(){
        System.out.println(formulario+" "+formularioDetv+" "+formularioDeth);
    }

}