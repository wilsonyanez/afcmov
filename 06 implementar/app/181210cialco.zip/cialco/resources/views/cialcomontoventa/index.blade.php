@extends('adminlte::page')
@section('title', 'Cialco Monto Venta')
@section('content_header')
    <h1>Cialco Monto Venta</h1>
@stop
  @section('content')
    @include('include.alert')
    <div class="box box-primary">
        <div class="box-header">
            <h2 class="page-header">
                <i class="fa fa-globe"></i> Cialco Monto Venta
            </h2>
        </div>
        <div class="box-body">
              {!! $grid !!}
        </div>
        <div class="box-footer">
        </div>
	  @stop
	  @section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
		@stop
	  @section('js')
@stop