@extends('adminlte::page')

@section('title', 'Coordendas')

@section('content_header')
    <h1>Coordenadas</h1>
@stop

@section('content')
    @include('include.alert')
    <div class="box box-primary">
        <div class="box-header with-border">
            <h2 class="page-header">
                <i class="fa fa-globe"></i> Listado
                {{--<a class="btn btn-sm btn-default pull-right" href="{{route('coordenada.create')}}">Nuevo</a>--}}
            </h2>
        </div>
        <div class="row">
            <div class="col-xs-12 table-responsive">
                <table class="table table-striped">
                <tr>

                  <th>CIALCO</th>
                  <th>Posición X</th>
                  <th>Posición Y</th>
                  <th>Posición Z</th>
                  <th>UTM</th>
                  <th>Fecha Inicio</th>
                  <th>Fecha Fin</th>
                  <th>Estado</th>
                  <th>Fecha Creación</th>
                  {{--<th>Acciones</th>--}}
                </tr>
                @foreach($results as $key=>$item)
                <tr>
                       <td><a href="{{route('cialco.show',['id'=>$item->coo_cialco_id])}}"><i>{{$item->cialco->cia_nombre}}</i></a></td>

                       <td>{{$item->coo_posicion_x}}</td>
                       <td>{{$item->coo_posicion_y}}</td>
                       <td>{{$item->coo_posicion_z}}</td>
                       <td>{{$item->utm->utm_descripcion}}</td>
                       <td>{{$item->coo_fecha_inicio}}</td>
                       <td>{{$item->coo_fecha_fin}}</td>
                       <td>{!!$item->texto_estado_html!!}</td>
                       <td>{{$item->coo_fecha_inserta}}</td>
                   {{-- <td>
                        <a href="{{route('representante.view',['id'=>$item->rep_representante_id])}} "class="label label-primary">Ver</a>
                        <a href="{{route('representante.edit',['id'=>$item->rep_representante_id])}}" class="label label-primary">Editar</a>
                    </td>--}}
                </tr>
                @endforeach
              </table>
            </div>
        </div>
	<div class="box-footer">
	{{--<a class="btn btn-sm btn-default pull-right" href="{{route('cialco.create')}}">Nuevo</a>--}}
	</div>
	@stop
	@section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
	@stop
	@section('js')

@stop