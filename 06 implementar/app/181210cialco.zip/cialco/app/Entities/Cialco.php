<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Cialco extends Model
{
    protected $table = 'cialco';
    protected $primaryKey = 'cia_cialco_id';
    const CREATED_AT = 'cia_fecha_inserta';
    const UPDATED_AT = 'cia_fecha_actualiza';

    use SoftDeletes;
    const DELETED_AT = 'cia_fecha_elimina';

    protected $fillable = [
        'cia_modalidad_id',
        'cia_permanencia_id',
        'cia_nombre',
        'cia_contacto',
        'cia_correo_electronico',
        'cia_sitio_web',
        'cia_estado',
        'cia_fecha_inicio',
        'cia_fecha_fin',
    ];

    protected $append = [
        'texto_estado',
        'texto_estado_html'
    ];

    public function permanencia()
    {
        return $this->belongsTo('App\Catalogs\Permanencia', 'cia_permanencia_id');
    }

    public function modalidad()
    {
        return $this->belongsTo('App\Catalogs\Modalidad', 'cia_modalidad_id');
    }

    public function representantes()
    {
        return $this->hasMany(Representante::class, 'rep_cialco_id', 'cia_cialco_id');
    }
	
    public function direcciones()
    {
        return $this->hasMany(Direccion::class, 'dir_cialco_id', 'cia_cialco_id');
    }

    public function coordenadas()
    {
        return $this->hasMany(Coordenada::class, 'coo_cialco_id', 'cia_cialco_id');
    }

    public function frecuencias(){
        return $this->hasMany('App\Entities\CialcoFrecuencia','cfr_cialco_id','cia_cialco_id');
    }

    public function ofertasagropecuarias()
    {
        return $this->hasMany('App\Entities\CialcoOfertaAgropecuaria', 'coa_cialco_id', 'cia_cialco_id');
    }

    public function organizaciones()
    {
        return $this->hasMany('App\Entities\Organizacion', 'org_cialco_id', 'cia_cialco_id');
    }

    public function productores()
    {
        return $this->hasMany('App\Entities\Productor', 'pro_cialco_id', 'cia_cialco_id');
    }
	
    public function interinstitucionales(){
        return $this->hasMany('App\Entities\CialcoInterinstitucional','int_cialco_id','cia_cialco_id');
    }

	public function productos(){
        return $this->hasMany('App\Entities\CialcoProducto','cpr_cialco_id','cia_cialco_id');
    }
	
    public function montosventas(){
        return $this->hasMany('App\Entities\CialcoMontoVenta','cmv_cialco_id','cia_cialco_id');
    }

    public function getTextoEstadoAttribute()
    {
        return ($this->cia_estado ? 'Activo' : 'Inactivo');
    }

    public function getTextoEstadoHtmlAttribute()
    {
        if ($this->cia_estado)
            return ('<span class="label label-success">' . $this->texto_estado . '</span>');
        return ('<span class="label label-default">' . $this->texto_estado . '</span>');
    }
}