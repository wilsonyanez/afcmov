@extends('adminlte::page')
@section('title', 'Cialco por Monto de Venta')
@section('content_header')
    <h1>Cialco por Monto de Venta</h1>
@stop
@section('content')
  @include('include.alert')
  {!! Form::model($result, ['method' => 'PATCH','route' => ['cialcomontoventa.update', 'id'=>$result->cmv_cialco_monto_venta_id]]) !!}
<div class="box box-primary">
    <div class="box-header with-border">
        <h3 class="box-title">Nuevo</h3>
    </div>
    <div class="box-body">
      <div class="row"> <!-- ROW 1 -->
        <div class="col-md-3">
			<div class="form-group">
				<label for="cmv_cialco_id">Cialco</label>
					{{ Form::select('cmv_cialco_id', $cialcos, $result->cmv_cialco_id, ['class'=>'form-control','placeholder' => 'Seleccione...']) }}
					@include('include.error_form_element',['name'=>'cmv_cialco_id'])
			</div>
        </div>
        <div class="col-md-3">
			<div class="form-group">
				<label for="cmv_ejercicio">Año</label>
					{{ Form::text('cmv_ejercicio',$result->cmv_ejercicio,['class'=>'form-control', 'required' => 'required|integer'])}}
					@include('include.error_form_element',['name'=>'cmv_ejercicio'])
			</div>
        </div>
        <div class="col-md-3">
			<div class="form-group">
				<label for="cmv_periodo">Mes</label>
					{{ Form::text('cmv_periodo',$result->cmv_periodo,['class'=>'form-control'])}}
					@include('include.error_form_element',['name'=>'cmv_periodo'])
			</div>
        </div>
      </div>
      <div class="row"> <!-- ROW 2 -->
        <div class="col-md-3">
			<div class="form-group">
				<label for="cmv_monto">Monto</label>
					{{ Form::text('cmv_monto',number_format($result->cmv_monto, 2, '.', ','),['class'=>'form-control', 'required' => 'required|numeric'])}}
					@include('include.error_form_element',['name'=>'cmv_monto'])
			</div>
        </div>
        <div class="col-md-3">
			<div class="form-group">
				<label for="cmv_fecha_inicio">Fecha Inicio</label></br>
					{{ Form::date('cmv_fecha_inicio', $result->cmv_fecha_inicio, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
					@include('include.error_form_element',['name'=>'cmv_fecha_inicio'])
			</div>
        </div>
        <div class="col-md-3">
			<div class="form-group">
				<label for="cmv_fecha_fin">Fecha Fin</label></br>
					{{ Form::date('cmv_fecha_fin', $result->cmv_fecha_fin, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
					@include('include.error_form_element',['name'=>'cmv_fecha_fin'])
			</div>
        </div>
      </div>
      <div class="row"> <!-- ROW 3 -->
        <div class="col-md-3">
			<div class="form-group">
				<label for="cmv_estado">Estado</label>
					{{ Form::select('cmv_estado',['1' => 'Activo', '0' => 'Inactivo'],$result->cmv_estado,['class'=>'form-control'])}}
			</div>
        </div>
      </div>
    </div>
    <div class="box-footer">
      <button type="submit" class="btn btn-primary">Editar</button>
    </div>
    {!! Form::close() !!}
    <div class="box-footer">
        <a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
    </div>

	@stop
	@section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
	@stop
	@section('js')
		<script> console.log('Hi!'); </script>
@stop