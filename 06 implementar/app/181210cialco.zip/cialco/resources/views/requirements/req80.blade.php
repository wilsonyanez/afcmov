@extends('adminlte::page')



@section('title', 'Dashboard')



@section('content_header')

    <h1>RQ17-MOV-HU080</h1>
    <p>Caracterización de la organización</p>

@stop



@section('content')
        <p>Como Técnico de Territorio, quiero registrar los datos de caracterización de las Organizaciones, que me solicita el Administrador AFC para validar si se otorga o no el Sello de la Agricultura Familiar Campesina (Sello AFC).</p>
        <p><ul>
          <li>Diseño: Cumplir formato detallado en los archivos:RQ13-MOV-HU058-DIS065 Inscripción Organización - Caracterización.png</li>
          <li>Usabilidad: Cumplir con el detalle descrito en pestaña funcionalidad con identificación: RQ13-MOV-HU058-FUN</li>
          <li>Objetivo: Publicar Datos que permiten la caracterización de la Organizaciones a las que Pertenece un Productor en dispositivo móvil, los atributos a desplegar, se los puede encontrar en: RQ08-MOV-HU035-DIS042</li>
          <li><b>Inquitudes</b></li>
          <li>Nombre de la tabla ?</li>
          <li>Formato para definición de nueva tabla?</li>
          <li>Requiere campos de fecha de creación y actualización ?</li>
          </ul></p>

    <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Formulario de Registro</h3>
            </div>
            <div class="box-body">

                <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                  <label for="exampleInputEmail1">Tipo de organización</label>
                                  <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Tipo de organización">
                                  <p><span class="label label-danger">Dropdown? catalogo de donde viene la información</span></p>
                            </div>
                        </div>

                         <div class="col-md-6">
                            <div class="form-group">
                                  <label for="exampleInputEmail1">Tipología</label>
                                  <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Tipologia">
                                  <p><span class="label label-danger">Dropdown? catalogo de donde viene la información</span></p>
                            </div>
                        </div>

                </div>
                <!-- /.row -->
                <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                  <label for="exampleInputEmail1">Fines de la organización</label>
                                  <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Fines de la organización">
                                  <p><span class="label label-danger">Dropdown? Catálogo ? de donde viene la información</span></p>
                            </div>
                        </div>

                         <div class="col-md-6">
                            <div class="form-group">
                                  <label for="exampleInputEmail1">Cuenta Bancaria</label>
                                  <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Cuenta Bancaria">
                                  <p><span class="label label-danger">Dropdown? catalogo de donde viene la información</span></p>
                            </div>
                        </div>

                </div>
                <!-- /.row -->
                <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                  <label for="exampleInputEmail1">Número de socios</label>
                                  <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Número de socios">
                                  <p>

                                  <span class="label label-info">numérico ?</span>
                                  </p>
                            </div>
                        </div>

                         <div class="col-md-6">
                            <div class="form-group">
                                  <label for="exampleInputEmail1">Número de socios en el registro AFC</label>
                                  <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Número de socios en el registro AFC">
                                  <p>
                                  <span class="label label-info">numérico ?</span>
                                  </p>
                            </div>
                        </div>

                </div>
                <!-- /.row -->

                <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                  <label for="exampleInputEmail1">Registro SEPS</label>
                                  <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Registro SEPS">
                                  <p>
                                  <span class="label label-info">numérico ?</span>
                                  <span class="label label-warning">formato de entrada ? : </span>
                                  </p>
                            </div>
                        </div>


                </div>
                <!-- /.row -->

            </div>

            <div class="box-footer">
                <button type="submit" class="btn btn-primary">Almacenar</button>
              </div>
    </div>

@stop



@section('css')

    <link rel="stylesheet" href="/css/admin_custom.css">

@stop



@section('js')

    <script> console.log('Hi!'); </script>

@stop