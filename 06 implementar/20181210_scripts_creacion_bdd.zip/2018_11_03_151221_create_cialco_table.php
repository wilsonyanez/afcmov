<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCialcoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cialco', function (Blueprint $table) {
            $table->increments('cia_cialco_id');
            /*
                A definir:
                cia_ubicacion_geografica
                cia_cordenada_ubicacion_id
            */
            $table->unsignedInteger('cia_permanencia_id');
            $table->foreign('cia_permanencia_id')->references('per_permanencia_id')->on('permanencia');

            $table->unsignedInteger('cia_modalidad_id');
            $table->foreign('cia_modalidad_id')->references('mod_modalidad_id')->on('modalidad');

            $table->text('cia_nombre');
            $table->text('cia_contacto')->nullable();
            $table->text('cia_correo_electronico')->nullable();
            $table->text('cia_sitio_web')->nullable();

            // Columnas de control
            $table->boolean('cia_estado')->default(true);
            
            $table->date('cia_fecha_inicio')->nullable();
            $table->date('cia_fecha_fin')->nullable();

            $table->integer('cia_usuario_inserta')->unsigned()->nullable();
            $table->timestamp('cia_fecha_inserta')->nullable();

            $table->integer('cia_usuario_actualiza')->unsigned()->nullable();
            $table->timestamp('cia_fecha_actualiza')->nullable();

            $table->integer('cia_usuario_elimina')->unsigned()->nullable();
            $table->timestamp('cia_fecha_elimina')->nullable();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cialco');
    }
}
