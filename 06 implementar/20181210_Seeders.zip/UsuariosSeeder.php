<?php

use Illuminate\Database\Seeder;

class UsuariosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('usuarios')->insert([
            'usu_nombre'=>'Usuario CIALCO',
            'username'=>'1234567890',
            'email'=>'mail@mail.com',
            'password'=>bcrypt('1234567890'),
            'usu_fecha_creacion'=>date_create('now UTC'),
            'usu_fecha_actualizacion'=>date_create('now UTC')
        ]);
    }
}
