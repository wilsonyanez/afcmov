<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Coordenada extends Model
{
    protected $table = 'coordenada';
    protected $primaryKey = 'coo_coordenada_id';
    const CREATED_AT = 'coo_fecha_inserta';
    const UPDATED_AT = 'coo_fecha_actualiza';

    use SoftDeletes;
    const DELETED_AT = 'coo_fecha_elimina';

    protected $fillable=[
        'coo_posicion_x',
        'coo_posicion_y',
        'coo_posicion_z',
        'coo_fecha_inicio',
        'coo_fecha_fin',
        'coo_estado',
        'coo_cialco_id',
        'coo_utm_id' 
    ];

    protected $append = [
        'texto_estado',
        'texto_estado_html'
    ];

    public function utm()
    {
        return $this->belongsTo('App\Catalogs\Utm', 'coo_utm_id');
    }

    public function cialco()
    {
        return $this->belongsTo('App\Entities\Cialco', 'coo_cialco_id');
    }

    public function getTextoEstadoAttribute()
    {
        return ($this->coo_estado ? 'Activo' : 'Inactivo');
    }

    public function getTextoEstadoHtmlAttribute()
    {
        if ($this->coo_estado)
            return ('<span class="label label-success">' . $this->texto_estado . '</span>');
        return ('<span class="label label-default">' . $this->texto_estado . '</span>');
    }

}