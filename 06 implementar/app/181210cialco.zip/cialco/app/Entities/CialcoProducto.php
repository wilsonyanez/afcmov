<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class CialcoProducto extends Model
{
    protected $table = 'cialco_producto';
    protected $primaryKey = 'cpr_cialco_producto_id';
    const CREATED_AT = 'cpr_fecha_inserta';
    const UPDATED_AT = 'cpr_fecha_actualiza';

    use SoftDeletes;
    const DELETED_AT = 'cpr_fecha_elimina';

    protected $append = [
        'texto_unidad',
        'texto_unidad_html',
        'texto_estado',
        'texto_estado_html'
    ];

    protected $fillable = [
          'cpr_cialco_id',
          'cpr_producto_id',
          'cpr_ejercicio',
          'cpr_periodo',
          'cpr_precio',
          'cpr_unidad',
          'cpr_fecha_inicio',
          'cpr_fecha_fin',
          'cpr_estado'
    ];

    public function producto()
    {
        return $this->belongsTo('App\Catalogs\Producto', 'cpr_producto_id');
    }

    public function cialco()
    {
        return $this->belongsTo('App\Entities\Cialco', 'cpr_cialco_id');
    }

    public function getTextoUnidadAttribute()
    {
        return ($this->cpr_unidad ? 'Unidades' : 'Kilos' );
    }

    public function getTextoUnidadHtmlAttribute()
    {
        if ($this->cpr_unidad)
            return ('<span class="label label-success">' . $this->texto_unidad . '</span>');
        return ('<span class="label label-default">' . $this->texto_unidad . '</span>');
    }
	
    public function getTextoEstadoAttribute()
    {
        return ($this->cpr_estado ? 'Activo' : 'Inactivo');
    }

    public function getTextoEstadoHtmlAttribute()
    {
        if ($this->cpr_estado)
            return ('<span class="label label-success">' . $this->texto_estado . '</span>');
        return ('<span class="label label-default">' . $this->texto_estado . '</span>');
    }
}