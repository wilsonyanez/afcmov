/*==============================================================*/
/* Table: dpa                                                   */
/*==============================================================*/
SELECT * FROM dpa;
SELECT id_dpa, nivel, texto, cod_dpa FROM dpa;

/*==============================================================*/
/* Table: formulario                                            */
/*==============================================================*/
SELECT * FROM formulario;
SELECT id_formulario,cod_usuario,tipo,numero,fecha,referencia,estado_p,estado_t FROM formulario ;

/*==============================================================*/
/* Table: formulario_detv                                       */
/*==============================================================*/
SELECT * FROM formulario_detv;
SELECT id_fdetv,cod_form,cod_mod,orden,cod_preg,valor FROM formulario_detv ;

/*==============================================================*/
/* Table: formulario_deth                                       */
/*==============================================================*/
SELECT * FROM formulario_deth;
SELECT id_fdeth,cod_form,cod_var,orden,val01,val02,val03,val04,val05,val06,val07,val08,val09,val10,val11,val12,val13,val14,val15,val16 FROM formulario_deth;

SELECT 
  TRIM(d.cod_var) cod_mod,
  d.orden orden,
  TRIM(d.val01) val01,  TRIM(d.val02) val02,  TRIM(d.val03) val03,  TRIM(d.val04) val04,
  TRIM(d.val05) val05,  TRIM(d.val06) val06,  TRIM(d.val07) val07,  TRIM(d.val08) val08,
  TRIM(d.val09) val09,  TRIM(d.val10) val10,  TRIM(d.val11) val11,  TRIM(d.val12) val12,
  TRIM(d.val13) val13,  TRIM(d.val14) val14,  TRIM(d.val15) val15,  TRIM(d.val16) val16,
  d.clave,
  CASE 
    WHEN f.estado_p='0' THEN 'A'
    WHEN f.estado_p='1' THEN 'I'
    ELSE 'O'
  END estado,  
  f.cod_usuario cod_usuario, 
  f.fecha fecha_crea,
  substr(f.clave, 1, f.long_usuario) usuario_mod, 
  to_timestamp(substr(f.clave, f.long_usuario + f.long_identificador + 1), 'YYYYMMDDHH24MISS') fecha_hora_mod
FROM public.formulario f
INNER JOIN public.formulario_deth d ON
  f.id_formulario = d.cod_form
WHERE d.cod_var IN ('m1b', 'm1d', 'm1e')
ORDER BY d.clave, d.cod_var, d.orden ;

SELECT substr('12345', 1, 3)

SELECT
 f.clave clave, u.nombres nombres, u.apellidos apellidos, cast(case when f.numero IS NULL then '0' when f.numero = '' then '0' else f.numero end as integer) numero,
 f.estado_p estado_p, f.cod_usuario cod_usuario, f.fecha fecha_crea, substr(f.clave, 1, f.long_usuario) usuario_mod, 
 to_timestamp(substr(f.clave, f.long_usuario + f.long_identificador + 1), 'YYYYMMDDHH24MI') fecha_hora_mod
FROM public.usuario u
INNER JOIN public.formulario f ON
  u.id_usuario = f.cod_usuario
ORDER BY f.cod_usuario, f.id_formulario asc



/*==============================================================*/
/* Table: establecimiento                                       */
/*==============================================================*/
SELECT * FROM establecimiento;

SELECT
   id_establecimiento,
   cod_usuario,
   tipo,
   numero,
   fecha,
   referencia,
   estado_p,
   estado_t
FROM  establecimiento;

/*==============================================================*/
/* Table: establecimiento_deth                                  */
/*==============================================================*/
SELECT * FROM establecimiento_deth;

SELECT
   id_edeth,
   cod_esta,
   cod_var,
   orden,
   val01,
   val02,
   val03,
   val04,
   val05,
   val06,
   val07,
   val08,
   val09,
   val10,
   val11,
   val12,
   val13,
   val14,
   val15
FROM establecimiento_deth ;

/*==============================================================*/
/* Table: establecimiento_detv                                  */
/*==============================================================*/
SELECT * FROM establecimiento_detv;

SELECT 
   id_edetv,
   cod_esta,
   cod_mod,
   orden,
   cod_preg,
   valor 
FROM establecimiento_detv;

/*==============================================================*/
/* Table: organizacion                                          */
/*==============================================================*/
SELECT * FROM organizacion;

SELECT
   id_organizacion,
   cod_usuario,
   tipo,
   numero,
   fecha,
   referencia,
   estado_p,
   estado_t
FROM organizacion;


/*==============================================================*/
/* Table: organizacion_deth                                     */
/*==============================================================*/
SELECT * FROM organizacion_deth;

SELECT
   id_odeth,
   cod_orga,
   cod_var,
   orden,
   val01,
   val02,
   val03,
   val04,
   val05,
   val06,
   val07,
   val08,
   val09,
   val10,
   val11,
   val12,
   val13,
   val14,
   val15
FROM organizacion_deth;

/*==============================================================*/
/* Table: organizacion_detv                                     */
/*==============================================================*/
SELECT * FROM organizacion_detv;

SELECT 
   id_odetv,
   cod_orga,
   cod_mod,
   orden,
   cod_preg,
   valor 
FROM organizacion_detv;

/*==============================================================*/
/* Table: usuario                                               */
/*==============================================================*/
SELECT * FROM usuario;

SELECT usuario
   id_usuario,
   usuario,
   clave,
   nombres,
   apellidos
FROM usuario ;

/*==============================================================*/
/* Table: varias consultas                                      */
/*==============================================================*/

/* **************************************************************************** */
/* ************************** FORULARIO *************************************** */
/* **************************************************************************** */

SELECT
  f.cod_usuario cod_usuario, f.numero numero, f.fecha fecha_registro, f.estado_p estado_p, f.clave clavecon, 
  substr(f.clave, 1, long_usuario) usu,
  substr(f.clave, long_usuario + 1, long_identificador) sec,
  substr(f.clave, long_usuario + long_identificador + 1) fec
FROM usuario u
INNER JOIN formulario f ON
  u.id_usuario = f.cod_usuario
ORDER BY f.cod_usuario, f.id_formulario asc


SELECT
 f.clave clave, u.nombres nombres, u.apellidos apellidos, cast(case when f.numero IS NULL then '0' when f.numero = '' then '0' else f.numero end as integer) numero, 
 f.estado_p estado_p, f.cod_usuario cod_usuario, f.fecha fecha_crea, substr(f.clave, 1, f.long_usuario) usuario_mod, 
 to_timestamp(substr(f.clave, f.long_usuario + f.long_identificador + 1), 'YYYYMMDDHH24MI') fecha_hora_mod
FROM public.usuario u
INNER JOIN public.formulario f ON
  u.id_usuario = f.cod_usuario
ORDER BY f.cod_usuario, f.id_formulario asc


SELECT 
  id_fdeth,
  cod_form,
  cod_var,
  orden,
  val01,  val02,  val03,  val04,  val05,  val06,  val07,  val08,
  val09,  val10,  val11,  val12,  val13,  val14,  val15,  val16,
  clave
  FROM public.formulario_deth 
WHERE cod_var = 'm1e';

SELECT DISTINCT cod_mod FROM formulario_detv ORDER BY cod_mod;

'm1a', 'm1c', 'm1f', 'm1g', 'm1h'
'v1a', 'v1b', 'v1e', 'v1h', 'v1i', 'v1j', 'v1k', 'v1l', 'v1m', 'v1n'

SELECT 
  d.cod_mod cod_mod,
  d.orden orden,
  d.cod_preg cod_preg,
  TRIM(d.valor) valor,
  TRIM(d.clave) clave,
  CASE 
    WHEN f.estado_p='0' THEN 'A'
    WHEN f.estado_p='1' THEN 'I'
    ELSE 'O'
  END estado,
  f.cod_usuario cod_usuario, 
  f.fecha fecha_crea,
  substr(f.clave, 1, f.long_usuario) usuario_mod, 
  to_timestamp(substr(f.clave, f.long_usuario + f.long_identificador + 1), 'YYYYMMDDHH24MI') fecha_hora_mod
FROM formulario f
INNER JOIN formulario_detv d ON
  f.id_formulario = d.cod_form
WHERE d.cod_mod IN ('m1a', 'm1c', 'm1f', 'm1g', 'm1h')
ORDER BY d.cod_mod, d.orden;


SELECT
  TRIM(d.cod_var) cod_mod,
  d.orden orden,
  TRIM(d.val01) val01,  TRIM(d.val02) val02,  TRIM(d.val03) val03,  TRIM(d.val04) val04,
  TRIM(d.val05) val05,  TRIM(d.val06) val06,  TRIM(d.val07) val07,  TRIM(d.val08) val08,
  TRIM(d.val09) val09,  TRIM(d.val10) val10,  TRIM(d.val11) val11,  TRIM(d.val12) val12,
  TRIM(d.val13) val13,  TRIM(d.val14) val14,  TRIM(d.val15) val15,  TRIM(d.val16) val16,
  d.clave,
  CASE
    WHEN f.estado_p='0' THEN 'A'
    WHEN f.estado_p='1' THEN 'I'
    ELSE 'O'
  END estado, 
  f.cod_usuario cod_usuario, 
  f.fecha fecha_crea, 
  substr(f.clave, 1, f.long_usuario) usuario_mod, 
  to_timestamp(substr(f.clave, f.long_usuario + f.long_identificador + 1), 'YYYYMMDDHH24MI') fecha_hora_mod 
FROM formulario f
INNER JOIN formulario_deth d ON
  f.id_formulario = d.cod_form
-- WHERE d.cod_var IN ('m1b', 'm1d')
ORDER BY d.cod_var, d.orden;

SELECT
 f.clave clave, u.nombres nombres, u.apellidos apellidos, cast(case when f.numero IS NULL then '0' when f.numero = '' then '0' else f.numero end as integer) numero,
 f.estado_p estado_p, f.cod_usuario cod_usuario, f.fecha fecha_crea, substr(f.clave, 1, f.long_usuario) usuario_mod --, 
-- to_timestamp(substr(f.clave, f.long_usuario + f.long_identificador + 1), 'YYYYMMDDHH24MI') fecha_hora_mod
FROM public.usuario u
INNER JOIN public.formulario f ON
  u.id_usuario = f.cod_usuario
ORDER BY f.cod_usuario, f.id_formulario asc



/* **************************************************************************** */
/* ************************ ORGANIZACION ************************************** */
/* **************************************************************************** */
SELECT * FROM organizacion o ;

SELECT
 o.clave clave, u.nombres nombres, u.apellidos apellidos, cast(case when o.numero IS NULL then '0' when o.numero = '' then '0' else o.numero end as integer) numero, 
 o.estado_p estado_p, o.cod_usuario cod_usuario, o.fecha fecha_crea, substr(o.clave, 1, o.long_usuario) usuario_mod, 
 to_timestamp(substr(o.clave, o.long_usuario + o.long_identificador + 1), 'YYYYMMDDHH24MI') fecha_hora_mod
FROM usuario u
INNER JOIN organizacion o ON
  u.id_usuario = o.cod_usuario
ORDER BY o.cod_usuario, o.id_organizacion asc

SELECT 
  d.cod_mod cod_mod,
  d.orden orden,
  d.cod_preg cod_preg,
  TRIM(d.valor) valor,
  TRIM(d.clave) clave,
  CASE 
    WHEN o.estado_p='0' THEN 'A'
    WHEN o.estado_p='1' THEN 'I'
    ELSE 'O'
  END estado,
  o.cod_usuario cod_usuario, 
  o.fecha fecha_crea,
  substr(o.clave, 1, o.long_usuario) usuario_mod, 
  to_timestamp(substr(o.clave, o.long_usuario + o.long_identificador + 1), 'YYYYMMDDHH24MI') fecha_hora_mod
FROM organizacion o
INNER JOIN organizacion_detv d ON
  o.id_organizacion = d.cod_orga
-- WHERE d.cod_mod IN ('o2a', 'o2d', 'o2e', 'o2f', 'o2g')
WHERE d.cod_mod = 'o2a'
ORDER BY TRIM(d.clave), d.cod_mod, d.orden ; 

SELECT 
  TRIM(d.cod_var) cod_mod,
  d.orden orden,
  TRIM(d.val01) val01,  TRIM(d.val02) val02,  TRIM(d.val03) val03,  TRIM(d.val04) val04,
  TRIM(d.val05) val05,  TRIM(d.val06) val06,  TRIM(d.val07) val07,  TRIM(d.val08) val08,
  TRIM(d.val09) val09,  TRIM(d.val10) val10,  TRIM(d.val11) val11,  TRIM(d.val12) val12,
  TRIM(d.val13) val13,  TRIM(d.val14) val14,  TRIM(d.val15) val15,  TRIM(d.val16) val16,
  d.clave,
  CASE 
    WHEN o.estado_p='0' THEN 'A'
    WHEN o.estado_p='1' THEN 'I'
    ELSE 'O'
  END estado,  
  o.cod_usuario cod_usuario, 
  o.fecha fecha_crea,
  substr(o.clave, 1, o.long_usuario) usuario_mod, 
  to_timestamp(substr(o.clave, o.long_usuario + o.long_identificador + 1), 'YYYYMMDDHH24MI') fecha_hora_mod
FROM organizacion o
INNER JOIN organizacion_deth d ON
  o.id_organizacion = d.cod_orga
-- WHERE d.cod_var IN ('o2b', 'o2c', 'o2h')
WHERE d.cod_var = 'o2b' 
ORDER BY d.cod_var, d.orden;

SELECT * FROM formulario_deth d WHERE cod_var = 'm1d' ; 



/*
  d.cod_mod cod_mod,
  d.orden orden,
  d.cod_preg cod_preg,
  TRIM(d.valor) valor,
  TRIM(d.clave) clave,
  CASE
    WHEN o.estado_p='0' THEN 'A'
    WHEN o.estado_p='1' THEN 'I'
    ELSE 'O'
  END estado,
  o.cod_usuario cod_usuario,
  o.fecha fecha_crea,
  substr(o.clave, 1, o.long_usuario) usuario_mod,
  to_timestamp(substr(o.clave, o.long_usuario + o.long_identificador + 1), 'YYYYMMDDHH24MI') fecha_hora_mod,
  TRIM(h.cod_var) cod_mod,
  h.orden orden,
  TRIM(h.val01) val01,  TRIM(h.val02) val02,  TRIM(h.val03) val03,  TRIM(h.val04) val04,
  TRIM(h.val05) val05,  TRIM(h.val06) val06,  TRIM(h.val07) val07,  TRIM(h.val08) val08,
  TRIM(h.val09) val09,  TRIM(h.val10) val10,  TRIM(h.val11) val11,  TRIM(h.val12) val12,
  TRIM(h.val13) val13,  TRIM(h.val14) val14,  TRIM(h.val15) val15,  TRIM(h.val16) val16,
  h.clave,
  CASE 
    WHEN o.estado_p='0' THEN 'A'
    WHEN o.estado_p='1' THEN 'I'
    ELSE 'O'
  END estado,
  o.cod_usuario cod_usuario,
  o.fecha fecha_crea,
  substr(o.clave, 1, o.long_usuario) usuario_mod,
  to_timestamp(substr(o.clave, o.long_usuario + o.long_identificador + 1), 'YYYYMMDDHH24MI') fecha_hora_mod
*/


SELECT 
  d.orden orden,
  d.cod_preg cod_preg,
  TRIM(d.valor) valor,
  TRIM(d.clave) clave,
  CASE 
    WHEN o.estado_p='0' THEN 'A'
    WHEN o.estado_p='1' THEN 'I'
    ELSE 'O'
  END estado,
  o.cod_usuario cod_usuario, 
  o.fecha fecha_crea,
  substr(o.clave, 1, o.long_usuario) usuario_mod, 
  to_timestamp(substr(o.clave, o.long_usuario + o.long_identificador + 1), 'YYYYMMDDHH24MI') fecha_hora_mod
FROM organizacion o
INNER JOIN organizacion_detv d ON
  o.id_organizacion = d.cod_orga
WHERE d.cod_mod = 'o2a' AND d.cod_preg = 'v00_02'
ORDER BY TRIM(d.clave), d.cod_mod, d.orden ; 

SELECT 
  TRIM(d.cod_var) cod_mod,
  d.orden orden,
  TRIM(d.val01) val01,  TRIM(d.val02) val02,  TRIM(d.val03) val03,  TRIM(d.val04) val04,
  TRIM(d.val05) val05,  TRIM(d.val06) val06,  TRIM(d.val07) val07,  TRIM(d.val08) val08,
  TRIM(d.val09) val09,  TRIM(d.val10) val10,  TRIM(d.val11) val11,  TRIM(d.val12) val12,
  TRIM(d.val13) val13,  TRIM(d.val14) val14,  TRIM(d.val15) val15,  TRIM(d.val16) val16,
  d.clave,
  CASE 
    WHEN o.estado_p='0' THEN 'A'
    WHEN o.estado_p='1' THEN 'I'
    ELSE 'O'
  END estado,  
  o.cod_usuario cod_usuario, 
  o.fecha fecha_crea,
  substr(o.clave, 1, o.long_usuario) usuario_mod, 
  to_timestamp(substr(o.clave, o.long_usuario + o.long_identificador + 1), 'YYYYMMDDHH24MI') fecha_hora_mod
FROM organizacion o
INNER JOIN organizacion_deth d ON
  o.id_organizacion = d.cod_orga
WHERE d.cod_var = 'o2b' 
ORDER BY d.clave, d.cod_var, d.orden;


SELECT 
  TRIM(h.cod_var) cod_mod,
  h.orden orden,
  TRIM(h.val12) val12,
  h.clave
FROM organizacion o
INNER JOIN organizacion_deth h ON
  o.id_organizacion = h.cod_orga
WHERE h.cod_var = 'o2b' and h.orden = 1
ORDER BY h.clave, h.cod_var, h.orden;


SELECT 
  TRIM(v.valor) valor 
FROM organizacion o
INNER JOIN organizacion_detv v ON
  o.id_organizacion = v.cod_orga
WHERE v.cod_mod = 'o2a' AND v.cod_preg = 'v00_02'
ORDER BY TRIM(v.valor);


SELECT 
v.cod_preg, 
  TRIM(v.valor) valor,
  TRIM(h.val12) val12,
  h.clave
FROM organizacion o
INNER JOIN organizacion_detv v ON
  o.id_organizacion = v.cod_orga
--  and v.cod_mod = 'o2a' AND v.cod_preg = 'v00_01'
  and v.cod_mod = 'o2a' AND v.cod_preg IN ('v00_01', 'v00_02', 'v00_04', 'v00_05', 'v00_06', 'v00_07')
INNER JOIN organizacion_deth h ON
  o.id_organizacion = h.cod_orga
  and h.cod_var = 'o2b' and h.orden = 1 and h.val01 = '1'
ORDER BY TRIM(h.val12), v.cod_preg;


SELECT 
  TRIM(d.cod_var) cod_mod,
  d.orden orden,
  TRIM(d.val01) val01,  TRIM(d.val02) val02,  TRIM(d.val03) val03,  TRIM(d.val04) val04,
  TRIM(d.val05) val05,  TRIM(d.val06) val06,  TRIM(d.val07) val07,  TRIM(d.val08) val08,
  TRIM(d.val09) val09,  TRIM(d.val10) val10,  TRIM(d.val11) val11,  TRIM(d.val12) val12,
  TRIM(d.val13) val13,  TRIM(d.val14) val14,  TRIM(d.val15) val15,  TRIM(d.val16) val16,
  d.clave,
  CASE 
    WHEN o.estado_p='0' THEN 'A'
    WHEN o.estado_p='1' THEN 'I'
    ELSE 'O'
  END estado,  
  o.cod_usuario cod_usuario, 
  o.fecha fecha_crea,
  substr(o.clave, 1, o.long_usuario) usuario_mod, 
  to_timestamp(substr(o.clave, o.long_usuario + o.long_identificador + 1), 'YYYYMMDDHH24MI') fecha_hora_mod
FROM organizacion o
INNER JOIN organizacion_deth d ON
  o.id_organizacion = d.cod_orga
WHERE d.cod_var IN ('o2b', 'o2c', 'o2h')
ORDER BY d.clave, TRIM(d.cod_var), d.orden;

SELECT 
  TRIM(v.valor) valor,
  TRIM(h.val12) NUMERO_CEDULA,
  h.clave
FROM organizacion o
INNER JOIN organizacion_detv v ON
  o.id_organizacion = v.cod_orga
  and v.cod_mod = 'o2a' AND v.cod_preg = 'v00_02'
INNER JOIN organizacion_deth h ON
  o.id_organizacion = h.cod_orga
  and h.cod_var = 'o2b' and h.orden = 1
ORDER BY TRIM(v.valor), TRIM(h.val12);

UPDATE organizacion_deth SET val12 = '1709364135' WHERE cod_var = 'o2b' AND clave = '1111111111201810230500';
UPDATE organizacion_deth SET val12 = '1716128911' WHERE cod_var = 'o2b' AND clave = '111111111220181106092401';



/* **************************************************************************** */
/* ***************************** CIALCO *************************************** */
/* **************************************************************************** */
SELECT count(*) FROM cialco ;    -- 1
SELECT * FROM cialco ;
SELECT sysdate ;

SELECT
 c.clave clave, u.nombres nombres, u.apellidos apellidos, cast(case when c.numero IS NULL then '0' when c.numero = '' then '0' else c.numero end as integer) numero, 
 c.estado_p estado_p, c.cod_usuario cod_usuario, c.fecha fecha_crea, substr(c.clave, 1, c.long_usuario) usuario_mod, 
 to_timestamp(substr(c.clave, c.long_usuario + c.long_identificador + 1), 'YYYYMMDDHH24MI') fecha_hora_mod 
FROM usuario u
INNER JOIN cialco c ON
  u.id_usuario = c.cod_usuario
ORDER BY c.cod_usuario, c.id_cialco asc ;

SELECT 
  d.orden orden,
  d.cod_preg cod_preg,
  TRIM(d.valor) valor,
  TRIM(d.clave) clave,
  CASE 
    WHEN c.estado_p='0' THEN 'A'
    WHEN c.estado_p='1' THEN 'I'
    ELSE 'O'
  END estado,
  c.cod_usuario cod_usuario, 
  c.fecha fecha_crea,
  substr(c.clave, 1, c.long_usuario) usuario_mod, 
  to_timestamp(substr(c.clave, c.long_usuario + c.long_identificador + 1), 'YYYYMMDDHH24MI') fecha_hora_mod
FROM cialco c
INNER JOIN cialco_detv d ON
  c.id_cialco = d.cod_cial
WHERE d.cod_mod = 'c4a' -- AND d.cod_preg = 'v00_02'
ORDER BY TRIM(d.clave), d.cod_mod, d.orden ; 


SELECT 
  TRIM(d.cod_var) cod_mod,
  d.orden orden,
  TRIM(d.val01) val01,  TRIM(d.val02) val02,  TRIM(d.val03) val03,  TRIM(d.val04) val04,
  TRIM(d.val05) val05,  TRIM(d.val06) val06,  TRIM(d.val07) val07,  TRIM(d.val08) val08,
  TRIM(d.val09) val09,  TRIM(d.val10) val10,  TRIM(d.val11) val11,  TRIM(d.val12) val12,
  TRIM(d.val13) val13,  TRIM(d.val14) val14,  TRIM(d.val15) val15,  TRIM(d.val16) val16,
  d.clave,
  CASE 
    WHEN c.estado_p='0' THEN 'A'
    WHEN c.estado_p='1' THEN 'I'
    ELSE 'O'
  END estado,  
  c.cod_usuario cod_usuario, 
  c.fecha fecha_crea,
  substr(c.clave, 1, c.long_usuario) usuario_mod, 
  to_timestamp(substr(c.clave, c.long_usuario + c.long_identificador + 1), 'YYYYMMDDHH24MI') fecha_hora_mod
FROM cialco c
INNER JOIN cialco_deth d ON
  c.id_cialco = d.cod_cial
-- WHERE d.cod_var IN ('o2b', 'o2c', 'o2h')
WHERE d.cod_var = 'c4b' 
ORDER BY d.cod_var, d.orden;

SELECT 
  d.orden orden,
  d.cod_preg cod_preg,
  TRIM(d.valor) valor,
  TRIM(d.clave) clave,
  CASE 
    WHEN c.estado_p='0' THEN 'A'
    WHEN c.estado_p='1' THEN 'I'
    ELSE 'O'
  END estado,
  c.cod_usuario cod_usuario, 
  c.fecha fecha_crea,
  substr(c.clave, 1, c.long_usuario) usuario_mod, 
  to_timestamp(substr(c.clave, c.long_usuario + c.long_identificador + 1), 'YYYYMMDDHH24MI') fecha_hora_mod
FROM cialco c
INNER JOIN cialco_detv d ON
  c.id_cialco = d.cod_cial
WHERE d.cod_mod = 'c4a' -- AND d.cod_preg = 'v00_02'
ORDER BY TRIM(d.clave), d.cod_mod, d.orden ; 


SELECT
  TRIM(d.cod_var) cod_mod,
  d.orden orden,
  TRIM(d.val01) val01,  TRIM(d.val02) val02,  TRIM(d.val03) val03,  TRIM(d.val04) val04,
  TRIM(d.val05) val05,  TRIM(d.val06) val06,  TRIM(d.val07) val07,  TRIM(d.val08) val08,
  TRIM(d.val09) val09,  TRIM(d.val10) val10,  TRIM(d.val11) val11,  TRIM(d.val12) val12,
  TRIM(d.val13) val13,  TRIM(d.val14) val14,  TRIM(d.val15) val15,  TRIM(d.val16) val16,
  TRIM(d.val17) val17,  TRIM(d.val18) val18,  TRIM(d.val19) val19,
  d.clave,
  CASE 
    WHEN c.estado_p='0' THEN 'A'
    WHEN c.estado_p='1' THEN 'I'
    ELSE 'O'
  END estado,  
  c.cod_usuario cod_usuario, 
  c.fecha fecha_crea,
  substr(c.clave, 1, c.long_usuario) usuario_mod, 
  to_timestamp(substr(c.clave, c.long_usuario + c.long_identificador + 1), 'YYYYMMDDHH24MI') fecha_hora_mod
FROM cialco c
INNER JOIN cialco_deth d ON
  c.id_cialco = d.cod_cial
WHERE d.cod_var = 'c4b' 
ORDER BY d.clave, d.cod_var, d.orden;


SELECT 
  TRIM(h.cod_var) cod_mod,
  h.orden orden,
  TRIM(h.val12) val12,
  h.clave
FROM cialco c
INNER JOIN cialco_deth h ON
  c.id_cialco = h.cod_cial
WHERE h.cod_var = 'c4b' and h.orden = 1
ORDER BY h.clave, h.cod_var, h.orden;


SELECT 
  TRIM(v.valor) valor 
FROM cialco c
INNER JOIN cialco_detv v ON
  c.id_cialco = v.cod_cial
WHERE v.cod_mod = 'c4a' AND v.cod_preg = 'v00_02'
ORDER BY TRIM(v.valor);


SELECT 
  v.cod_preg, 
  TRIM(v.valor) valor,
  TRIM(h.val12) val12,
  h.clave
FROM cialco o
INNER JOIN cialco_detv v ON
  o.id_cialco = v.cod_cial
--  and v.cod_mod = 'o2a' AND v.cod_preg = 'v00_01'
  and v.cod_mod = 'c4a' AND v.cod_preg IN ('v00_01', 'v00_02', 'v00_04', 'v00_05', 'v00_06', 'v00_07')
INNER JOIN cialco_deth h ON
  o.id_cialco = h.cod_cial
  and h.cod_var = 'c4b' and h.orden = 1 and h.val01 = '1'
ORDER BY TRIM(h.val12), v.cod_preg;


SELECT 
  TRIM(d.cod_var) cod_mod,
  d.orden orden,
  TRIM(d.val01) val01,  TRIM(d.val02) val02,  TRIM(d.val03) val03,  TRIM(d.val04) val04,
  TRIM(d.val05) val05,  TRIM(d.val06) val06,  TRIM(d.val07) val07,  TRIM(d.val08) val08,
  TRIM(d.val09) val09,  TRIM(d.val10) val10,  TRIM(d.val11) val11,  TRIM(d.val12) val12,
  TRIM(d.val13) val13,  TRIM(d.val14) val14,  TRIM(d.val15) val15,  TRIM(d.val16) val16,
  TRIM(d.val17) val17,  TRIM(d.val18) val18,  TRIM(d.val19) val19,
  d.clave,
  CASE 
    WHEN c.estado_p='0' THEN 'A'
    WHEN c.estado_p='1' THEN 'I'
    ELSE 'O'
  END estado,  
  c.cod_usuario cod_usuario, 
  c.fecha fecha_crea,
  substr(c.clave, 1, c.long_usuario) usuario_mod, 
  to_timestamp(substr(c.clave, c.long_usuario + c.long_identificador + 1), 'YYYYMMDDHH24MI') fecha_hora_mod
FROM cialco c
INNER JOIN cialco_deth d ON
  c.id_cialco = d.cod_cial
WHERE d.cod_var IN ('c4b', 'c4c', 'c4h')
ORDER BY d.clave, TRIM(d.cod_var), d.orden;


SELECT 
  TRIM(v.valor) valor,
  TRIM(h.val12) NUMERO_CEDULA,
  h.clave
FROM cialco c
INNER JOIN cialco_detv v ON
  c.id_cialco = v.cod_cial
  and v.cod_mod = 'c4a' AND v.cod_preg = 'v00_02'
INNER JOIN cialco_deth h ON
  c.id_cialco = h.cod_cial
  and h.cod_var = 'c4b' and h.orden = 1
ORDER BY TRIM(v.valor), TRIM(h.val12);

UPDATE cialco_deth SET val12 = '1709364135' WHERE cod_var = 'c4b' AND clave = '1111111111201810230500';
UPDATE cialco_deth SET val12 = '1716128911' WHERE cod_var = 'c4b' AND clave = '111111111220181106092401';
