<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRepresentanteTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('representante', function (Blueprint $table) {
            $table->increments('rep_representante_id');
            $table->text('rep_identificacion');
            $table->text('rep_contacto')->nullable();
            $table->text('rep_correo_electronico')->nullable();

            // COLUMNAS DE CONTROL
            $table->boolean('rep_estado')->default(true);

            $table->date('rep_fecha_inicio')->nullable();
            $table->date('rep_fecha_fin')->nullable();

            $table->integer('rep_usuario_inserta')->unsigned()->nullable();
            $table->timestamp('rep_fecha_inserta')->nullable();

            $table->integer('rep_usuario_actualiza')->unsigned()->nullable();
            $table->timestamp('rep_fecha_actualiza')->nullable();

            $table->integer('rep_usuario_elimina')->unsigned()->nullable();
            $table->timestamp('rep_fecha_elimina')->nullable();

            // FOREINGS
            $table->unsignedInteger('rep_cialco_id');
            $table->foreign('rep_cialco_id')->references('cia_cialco_id')->on('cialco');

            // TODO definir columna de relación API

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('representante');
    }
}
