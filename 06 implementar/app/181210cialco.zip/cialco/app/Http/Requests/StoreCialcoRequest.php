<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreCialcoRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'cia_modalidad_id' => 'required',
            'cia_permanencia_id' => 'required',
            'cia_nombre' => 'alpha|max:256|required',
            'cia_correo_electronico' => 'email',
        ];
    }

    public function messages()
    {

        return [
            'cia_nombre.required' => 'Nombre de CIALCO requerido',
            'cia_modalidad_id.required' => 'Modalidad es requerida',
            'cia_permanencia_id.required' => 'Permanencia es requerida',
            'cia_correo_electronico.email' => 'Formato incorrecto',
        ];
    }
}