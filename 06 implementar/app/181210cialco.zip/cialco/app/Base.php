<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

/**
 * Base model for most of the entities
 **/
class Base extends Model
{


    public function __save(array $options = array())
    {
        parent::save($options); // Calls Default Save
    }


    protected $defaultOrder = 'created_at';
    protected $defaultOrderDirection = 'ASC';

    public function scopeForOrg($query, $orgId)
    {
        return $query->where('organization_id', $orgId);
    }

    public function scopeOrdered($query)
    {
        return $query->orderBy($this->defaultOrder, $this->defaultOrderDirection);
    }
}
