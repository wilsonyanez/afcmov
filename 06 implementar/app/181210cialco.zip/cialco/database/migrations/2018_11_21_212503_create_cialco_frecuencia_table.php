<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCialcoFrecuenciaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cialco_frecuencia', function (Blueprint $table) {
            $table->increments('cfr_cialco_frecuencia_id');

            $table->time('cfr_hora_inicio')->nullable();
            $table->time('cfr_hora_fin')->nullable();

            $table->text('cfr_dias')->nullable();
            $table->text('cfr_descripcion')->nullable();

            // COLUMNAS DE CONTROL
            $table->boolean('cfr_estado')->default(true);

            $table->date('cfr_fecha_inicio')->nullable();
            $table->date('cfr_fecha_fin')->nullable();

            $table->integer('cfr_usuario_inserta')->unsigned()->nullable();
            $table->timestamp('cfr_fecha_inserta')->nullable();

            $table->integer('cfr_usuario_actualiza')->unsigned()->nullable();
            $table->timestamp('cfr_fecha_actualiza')->nullable();

            $table->integer('cfr_usuario_elimina')->unsigned()->nullable();
            $table->timestamp('cfr_fecha_elimina')->nullable();

            // FOREINGS
            $table->unsignedInteger('cfr_cialco_id');
            $table->foreign('cfr_cialco_id')->references('cia_cialco_id')->on('cialco');

            // FOREINGS
            $table->unsignedInteger('cfr_frecuencia_id');
            $table->foreign('cfr_frecuencia_id')->references('fre_frecuencia_id')->on('frecuencia');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cialco_frecuencia');
    }
}
