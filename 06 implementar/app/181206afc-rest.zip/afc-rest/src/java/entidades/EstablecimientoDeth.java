/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author david
 */
@Entity
@Table(name = "establecimiento_deth")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "EstablecimientoDeth.findAll", query = "SELECT e FROM EstablecimientoDeth e")
    , @NamedQuery(name = "EstablecimientoDeth.findByIdEdeth", query = "SELECT e FROM EstablecimientoDeth e WHERE e.idEdeth = :idEdeth")
    , @NamedQuery(name = "EstablecimientoDeth.findByCodVar", query = "SELECT e FROM EstablecimientoDeth e WHERE e.codVar = :codVar")
    , @NamedQuery(name = "EstablecimientoDeth.findByOrden", query = "SELECT e FROM EstablecimientoDeth e WHERE e.orden = :orden")
    , @NamedQuery(name = "EstablecimientoDeth.findByVal01", query = "SELECT e FROM EstablecimientoDeth e WHERE e.val01 = :val01")
    , @NamedQuery(name = "EstablecimientoDeth.findByVal02", query = "SELECT e FROM EstablecimientoDeth e WHERE e.val02 = :val02")
    , @NamedQuery(name = "EstablecimientoDeth.findByVal03", query = "SELECT e FROM EstablecimientoDeth e WHERE e.val03 = :val03")
    , @NamedQuery(name = "EstablecimientoDeth.findByVal04", query = "SELECT e FROM EstablecimientoDeth e WHERE e.val04 = :val04")
    , @NamedQuery(name = "EstablecimientoDeth.findByVal05", query = "SELECT e FROM EstablecimientoDeth e WHERE e.val05 = :val05")
    , @NamedQuery(name = "EstablecimientoDeth.findByVal06", query = "SELECT e FROM EstablecimientoDeth e WHERE e.val06 = :val06")
    , @NamedQuery(name = "EstablecimientoDeth.findByVal07", query = "SELECT e FROM EstablecimientoDeth e WHERE e.val07 = :val07")
    , @NamedQuery(name = "EstablecimientoDeth.findByVal08", query = "SELECT e FROM EstablecimientoDeth e WHERE e.val08 = :val08")
    , @NamedQuery(name = "EstablecimientoDeth.findByVal09", query = "SELECT e FROM EstablecimientoDeth e WHERE e.val09 = :val09")
    , @NamedQuery(name = "EstablecimientoDeth.findByVal10", query = "SELECT e FROM EstablecimientoDeth e WHERE e.val10 = :val10")
    , @NamedQuery(name = "EstablecimientoDeth.findByVal11", query = "SELECT e FROM EstablecimientoDeth e WHERE e.val11 = :val11")
    , @NamedQuery(name = "EstablecimientoDeth.findByVal12", query = "SELECT e FROM EstablecimientoDeth e WHERE e.val12 = :val12")
    , @NamedQuery(name = "EstablecimientoDeth.findByVal13", query = "SELECT e FROM EstablecimientoDeth e WHERE e.val13 = :val13")
    , @NamedQuery(name = "EstablecimientoDeth.findByVal14", query = "SELECT e FROM EstablecimientoDeth e WHERE e.val14 = :val14")
    , @NamedQuery(name = "EstablecimientoDeth.findByVal15", query = "SELECT e FROM EstablecimientoDeth e WHERE e.val15 = :val15")
    , @NamedQuery(name = "EstablecimientoDeth.findByVal16", query = "SELECT e FROM EstablecimientoDeth e WHERE e.val16 = :val16")
    , @NamedQuery(name = "EstablecimientoDeth.findByClave", query = "SELECT e FROM EstablecimientoDeth e WHERE e.clave = :clave")})
public class EstablecimientoDeth implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_edeth")
    private Integer idEdeth;
    @Size(max = 20)
    @Column(name = "cod_var")
    private String codVar;
    @Column(name = "orden")
    private Integer orden;
    @Size(max = 2147483647)
    @Column(name = "val01")
    private String val01;
    @Size(max = 2147483647)
    @Column(name = "val02")
    private String val02;
    @Size(max = 2147483647)
    @Column(name = "val03")
    private String val03;
    @Size(max = 2147483647)
    @Column(name = "val04")
    private String val04;
    @Size(max = 2147483647)
    @Column(name = "val05")
    private String val05;
    @Size(max = 2147483647)
    @Column(name = "val06")
    private String val06;
    @Size(max = 2147483647)
    @Column(name = "val07")
    private String val07;
    @Size(max = 2147483647)
    @Column(name = "val08")
    private String val08;
    @Size(max = 2147483647)
    @Column(name = "val09")
    private String val09;
    @Size(max = 2147483647)
    @Column(name = "val10")
    private String val10;
    @Size(max = 2147483647)
    @Column(name = "val11")
    private String val11;
    @Size(max = 2147483647)
    @Column(name = "val12")
    private String val12;
    @Size(max = 2147483647)
    @Column(name = "val13")
    private String val13;
    @Size(max = 2147483647)
    @Column(name = "val14")
    private String val14;
    @Size(max = 2147483647)
    @Column(name = "val15")
    private String val15;
    @Size(max = 2147483647)
    @Column(name = "val16")
    private String val16;
    @Size(max = 30)
    @Column(name = "clave")
    private String clave;
    @JoinColumn(name = "cod_form", referencedColumnName = "id_establecimiento")
    @ManyToOne
    private Establecimiento codEsta;

    public EstablecimientoDeth() {
    }

    public EstablecimientoDeth(Integer idEdeth) {
        this.idEdeth = idEdeth;
    }

    public Integer getIdEdeth() {
        return idEdeth;
    }

    public void setIdEdeth(Integer idEdeth) {
        this.idEdeth = idEdeth;
    }

    public String getCodVar() {
        return codVar;
    }

    public void setCodVar(String codVar) {
        this.codVar = codVar;
    }

    public Integer getOrden() {
        return orden;
    }

    public void setOrden(Integer orden) {
        this.orden = orden;
    }

    public String getVal01() {
        return val01;
    }

    public void setVal01(String val01) {
        this.val01 = val01;
    }

    public String getVal02() {
        return val02;
    }

    public void setVal02(String val02) {
        this.val02 = val02;
    }

    public String getVal03() {
        return val03;
    }

    public void setVal03(String val03) {
        this.val03 = val03;
    }

    public String getVal04() {
        return val04;
    }

    public void setVal04(String val04) {
        this.val04 = val04;
    }

    public String getVal05() {
        return val05;
    }

    public void setVal05(String val05) {
        this.val05 = val05;
    }

    public String getVal06() {
        return val06;
    }

    public void setVal06(String val06) {
        this.val06 = val06;
    }

    public String getVal07() {
        return val07;
    }

    public void setVal07(String val07) {
        this.val07 = val07;
    }

    public String getVal08() {
        return val08;
    }

    public void setVal08(String val08) {
        this.val08 = val08;
    }

    public String getVal09() {
        return val09;
    }

    public void setVal09(String val09) {
        this.val09 = val09;
    }

    public String getVal10() {
        return val10;
    }

    public void setVal10(String val10) {
        this.val10 = val10;
    }

    public String getVal11() {
        return val11;
    }

    public void setVal11(String val11) {
        this.val11 = val11;
    }

    public String getVal12() {
        return val12;
    }

    public void setVal12(String val12) {
        this.val12 = val12;
    }

    public String getVal13() {
        return val13;
    }

    public void setVal13(String val13) {
        this.val13 = val13;
    }

    public String getVal14() {
        return val14;
    }

    public void setVal14(String val14) {
        this.val14 = val14;
    }

    public String getVal15() {
        return val15;
    }

    public void setVal15(String val15) {
        this.val15 = val15;
    }

    public String getVal16() {
        return val16;
    }

    public void setVal16(String val16) {
        this.val16 = val16;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public Establecimiento getCodEsta() {
        return codEsta;
    }

    public void setCodEsta(Establecimiento codEsta) {
        this.codEsta = codEsta;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idEdeth != null ? idEdeth.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof EstablecimientoDeth)) {
            return false;
        }
        EstablecimientoDeth other = (EstablecimientoDeth) object;
        if ((this.idEdeth == null && other.idEdeth != null) || (this.idEdeth != null && !this.idEdeth.equals(other.idEdeth))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.EstablecimientoDeth[ idEdeth=" + idEdeth + " ]";
    }

}
