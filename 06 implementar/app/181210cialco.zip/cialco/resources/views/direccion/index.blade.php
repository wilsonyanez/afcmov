@extends('adminlte::page')

@section('title', 'Direcciones')

@section('content_header')
    <h1>Direcciones</h1>
@stop

@section('content')
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Listado</h3>
            {{--<a class="btn btn-sm btn-default pull-right" href="{{route('representante.create')}}">Nuevo</a>--}}
        </div>
        <div class="box-body table-responsive no-padding">
              <table class="table table-hover">
                <tr>

                  <th>CIALCO</th>
                  <th>Sector</th>
                  <th>Calle Principal</th>
                  <th>Número</th>
                  <th>Fecha Inicio</th>
                  <th>Fecha Fin</th>
                  <th>Estado</th>
                </tr>
                @foreach($results as $key=>$item)
                <tr>
                       <td><a href="{{route('cialco.show',['id'=>$item->dir_cialco_id])}}"><i>{{$item->cialco->cia_nombre}}</i></a></td>

                       <td>{{$item->dir_sector}}</td>
                       <td>{{$item->dir_calle_principal}}</td>
                       <td>{{$item->dir_numero}}</td>
                       <td>{{$item->dir_fecha_inicio}}</td>
                       <td>{{$item->dir_fecha_fin}}</td>
                       <td><span class="label label-success">Activo</span></td>
                </tr>
                @endforeach
              </table>
        </div>
	<div class="box-footer">
	{{--<a class="btn btn-sm btn-default pull-right" href="{{route('cialco.create')}}">Nuevo</a>--}}
	</div>
	@stop
	@section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
	@stop
	@section('js')

@stop