@extends('adminlte::page')

@section('title', 'Nuevo Representante')

@section('content_header')
    <h1>Representante</h1>
@stop

@section('content')
    @include('include.alert')
   {!! Form::open(['route' => 'cialco.representante.store', 'method' => 'post']) !!}

    <div class="box box-primary">
        {{ Form::hidden('rep_cialco_id',$cialco->cia_cialco_id,['class'=>'form-control'])}}
        <div class="box-header with-border">
            <h3 class="box-title">Nuevo</h3>
        </div>
        <div class="box-body">
            <div class="row"> <!-- ROW 1 -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="rep_identificacion">Identificación</label>
                        {{ Form::text('rep_identificacion',null,['class'=>'form-control', 'required' => 'required|alpha|digits:10'])}}
                        @include('include.error_form_element',['name'=>'rep_identificacion'])
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="rep_contacto">Nombre</label>
                        {{ Form::text('rep_contacto',null,['class'=>'form-control', 'required' => 'required|alpha'])}}
                        @include('include.error_form_element',['name'=>'rep_contacto'])
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="rep_correo_electronico">Correo</label>
                        {{ Form::text('rep_correo_electronico',null,['class'=>'form-control', 'required' => 'required|email'])}}
                        @include('include.error_form_element',['name'=>'rep_correo_electronico'])
                    </div>
                </div>
            </div>
            <div class="row"> <!-- ROW 1 -->
				<div class="col-md-3">
					<label for="rep_fecha_inicio">Fecha Inicio</label></br>
						{{ Form::date('rep_fecha_inicio', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
						@include('include.error_form_element',['name'=>'rep_fecha_inicio'])
				</div>
				<div class="col-md-3">
				<label for="rep_fecha_fin">Fecha Fin</label></br>
						{{ Form::date('rep_fecha_fin', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
						@include('include.error_form_element',['name'=>'rep_fecha_fin'])
				</div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="rep_estado">Estado</label>
                        {{ Form::select('rep_estado',['1' => 'Activo', '0' => 'Inactivo'],null,['class'=>'form-control'])}}
                        @include('include.error_form_element',['name'=>'rep_estado'])
                    </div>
                </div>
            </div>
        </div>

        <div class="box-footer">
            <button type="submit" class="btn btn-primary">Guardar</button>
        </div>
        {!! Form::close() !!}
        <div class="box-footer">
            <a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
        </div>

	@stop
	@section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
	@stop
	@section('js')
		<script> console.log('Hi!'); </script>
@stop