@extends('adminlte::page')
@section('title', 'Cialco Productos')
@section('content_header')
    <h1>Cialco Productos</h1>
@stop
@section('content')
    @include('include.alert')
    {!! Form::open(['route' => 'cialco.cialcoproducto.store','method'=> 'post']) !!}
    <div class="box box-primary">
        {{ Form::hidden('cpr_cialco_id',$cialco->cia_cialco_id,['class'=>'form-control'])}}
        <div class="box-header with-border">
            <h3 class="box-title">Cialco Productos</h3>
        </div>
        <div class="box-body">
            <div class="row"> <!-- ROW 1 -->
                <div class="col-md-3">
					<div class="form-group">
						<label for="cpr_producto_id">Productos</label>
							{{ Form::select('cpr_producto_id', $productos, null, ['class'=>'form-control','placeholder' => 'Seleccione...']) }}
							@include('include.error_form_element',['name'=>'cpr_producto_id'])
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="cpr_ejercicio">Año</label>
							{{ Form::number('cpr_ejercicio',null,['class'=>'form-control', 'required' => 'required|integer'])}}
							@include('include.error_form_element',['name'=>'cpr_ejercicio'])
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="cpr_periodo">Mes</label>
							{{ Form::number('cpr_periodo',null,['class'=>'form-control'])}}
							@include('include.error_form_element',['name'=>'cpr_periodo'])
					</div>
				</div>
            </div>
            <div class="row">  <!-- ROW 2 -->
                <div class="col-md-3">
					<div class="form-group">
						<label for="cpr_precio">Precio</label>
							{{ Form::number('cpr_precio',number_format(null, 2, '.', ','),['class'=>'form-control', 'required' => 'required|numeric'])}}
							@include('include.error_form_element',['name'=>'cpr_precio'])
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="cpr_unidad">Unidad (Kg)</label>
						    {{ Form::select('cpr_unidad',['3' => 'Unidades', '2' => 'Litros', '1' => 'Kilos'],$result->cpr_unidad,['class'=>'form-control'])}}
							@include('include.error_form_element',['name'=>'cpr_unidad'])
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="cpr_fecha_inicio">Fecha Inicio</label></br>
							{{ Form::date('cpr_fecha_inicio', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yy-mm-dd", firstDay: 1});')) }}
							@include('include.error_form_element',['name'=>'cpr_fecha_inicio'])
					</div>
				</div>
            </div>
            <div class="row">  <!-- ROW 3 -->
                <div class="col-md-3">
					<div class="form-group">
						<label for="cpr_fecha_fin">Fecha Fin</label></br>
							{{ Form::date('cpr_fecha_fin', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yy-mm-dd", firstDay: 1});')) }}
							@include('include.error_form_element',['name'=>'cpr_fecha_fin'])
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="cpr_estado">Estado</label>
							{{ Form::select('cpr_estado',['1' => 'Activo', '0' => 'Inactivo'],null,['class'=>'form-control'])}}
					</div>
				</div>
            </div>
        </div>

	<div class="box-footer">
		<button type="submit" class="btn btn-primary">Crear</button>
	</div>
	{!! Form::close() !!}
	<div class="box-footer">
		<a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
	</div>
	@stop
	@section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
	@stop
	@section('js')
@stop