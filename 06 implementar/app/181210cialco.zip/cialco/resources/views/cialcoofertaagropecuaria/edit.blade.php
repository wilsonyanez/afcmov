@extends('adminlte::page')
@section('title', 'Cialco Oferta Agropecuaria')
@section('content_header')
    <h1>Cialco Oferta Agropecuaria</h1>
@stop
@section('content')
  @include('include.alert')
    {!! Form::model($result, ['method' => 'PATCH','route' => ['cialcoofertaagropecuaria.update', 'id'=>$result->coa_cialco_oferta_agro_id]]) !!}
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Cialco Oferta Agropecuaria</h3>
        </div>
        <div class="box-body">
            <div class="row"> <!-- ROW 1 -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="coa_descripcion_otro">Descripción</label>
                        {{ Form::text('coa_descripcion_otro',$result->coa_descripcion_otro,['class'=>'form-control', 'required' => 'required|alpha'])}}
                    </div>
                </div>
            </div>
            <div class="row">  <!-- ROW 2 -->
                <div class="col-md-3">
				  <div class="form-group">
					 <label for="coa_oferta_agropecuaria_id">Oferta Agropecuaria</label>
						 {{ Form::select('coa_oferta_agropecuaria_id',$ofertaagropecuarias,null,['class'=>'form-control'])}}
				  </div>
                    <div class="form-group">
                        <label for="coa_fecha_inicio">Fecha Inicio</label>
						{{ Form::date('coa_fecha_inicio', $result->coa_fecha_inicio, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
                    </div>
                    <div class="form-group">
                        <label for="coa_fecha_fin">Fecha Fin</label>
						{{ Form::date('coa_fecha_inicio', $result->coa_fecha_inicio, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
                    </div>
                </div>
            </div>
            <div class="row">  <!-- ROW 2 -->
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="coa_estado">Estado</label>
                        {{ Form::select('coa_estado',['1' => 'Activo', '0' => 'Inactivo'],$result->coa_estado,['class'=>'form-control'])}}
                    </div>
                </div>
            </div>
        </div>

	<div class="box-footer">
		<button type="submit" class="btn btn-primary">Editar</button>
	</div>
	{!! Form::close() !!}
	<div class="box-footer">
		<a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
	</div>
    @stop
    @section('css')
        <link rel="stylesheet" href="/css/admin_custom.css">
    @stop
    @section('js')
@stop