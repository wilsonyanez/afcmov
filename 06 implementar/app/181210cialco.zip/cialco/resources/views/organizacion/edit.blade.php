@extends('adminlte::page')
@section('title', 'Organizaciones')
@section('content_header')
    <h1>Organizaciones</h1>
@stop
@section('content')
    @include('include.alert')
    {!! Form::model($result, ['method' => 'PATCH','route' => ['organizacion.update', 'id'=>$result->org_organizacion_id]]) !!}
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Organización</h3>
        </div>
        <div class="box-body">
            <div class="row"> <!-- ROW 1 -->
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="org_hecho_derecho">Organización Hecho/Derecho</label>
                        {{ Form::select('org_hecho_derecho',['1' => 'Hecho', '0' => 'Derecho'],$result->org_hecho_derecho,['class'=>'form-control'])}}
                        @include('include.error_form_element',['name'=>'org_hecho_derecho'])
                    </div>
                </div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="org_ruc">RUC</label>
						{{ Form::text('org_ruc',$result->org_ruc,['class'=>'form-control', 'required' => 'required|alpha|digits:13'])}}
                        @include('include.error_form_element',['name'=>'org_ruc'])
					</div>
				</div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="org_razon_social">Razon Social</label>
                        {{ Form::text('org_razon_social',$result->org_razon_social,['class'=>'form-control', 'required' => 'required|alpha'])}}
                        @include('include.error_form_element',['name'=>'org_razon_social'])
                    </div>
                </div>
            </div>
            <div class="row">   <!-- ROW 2 -->
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="org_registro_seps">Registro SEPS</label>
                        {{ Form::select('org_registro_seps',['1' => 'SI', '0' => 'NO'],$result->org_registro_seps,['class'=>'form-control'])}}
                        @include('include.error_form_element',['name'=>'org_registro_seps'])
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="org_acreditado_mag">Acreditado MAG</label>
                        {{ Form::select('org_acreditado_mag',['1' => 'SI', '0' => 'NO'],$result->org_acreditado_mag,['class'=>'form-control'])}}
                        @include('include.error_form_element',['name'=>'org_acreditado_mag'])
                    </div>
                </div>
            </div>
            <div class="row">  <!-- ROW 3 -->
                <div class="col-md-3">
					<div class="form-group">
						<label for="org_nro_productores_hombres">Nro Productores Hombres</label>
						{{ Form::number('org_nro_productores_hombres',$result->org_nro_productores_hombres,['class'=>'form-control', 'required' => 'required|integer'])}}
                        @include('include.error_form_element',['name'=>'org_nro_productores_hombres'])
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="org_nro_productores_mujeres">Nro Productores Mujeres</label>
						{{ Form::number('org_nro_productores_mujeres',$result->org_nro_productores_mujeres,['class'=>'form-control', 'required' => 'required|integer'])}}
                        @include('include.error_form_element',['name'=>'org_nro_productores_mujeres'])
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="org_nro_productores_total">Nro Productores Total</label>
						{{ Form::number('org_nro_productores_total',$result->org_nro_productores_total,['class'=>'form-control', 'required' => 'required|integer'])}}
                        @include('include.error_form_element',['name'=>'org_nro_productores_total'])
					</div>
				</div>
            </div>
            <div class="row">  <!-- ROW 4 -->
				<div class="col-md-3">
					<div class="form-group">
						<label for="org_fecha_inicio">Fecha Inicio</label></br>
						{{ Form::date('org_fecha_inicio', $result->org_fecha_inicio, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
						@include('include.error_form_element',['name'=>'org_fecha_inicio'])
					</div>
                </div>
				<div class="col-md-3">
					<div class="form-group">
					    <label for="org_fecha_fin">Fecha Fin</label></br>
						{{ Form::date('org_fecha_fin', $result->org_fecha_fin, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
						@include('include.error_form_element',['name'=>'org_fecha_fin'])
					</div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="org_estado">Estado</label>
                        {{ Form::select('org_estado',['1' => 'Activo', '0' => 'Inactivo'],$result->org_estado,['class'=>'form-control'])}}
						@include('include.error_form_element',['name'=>'org_fecha_inicio'])
                    </div>
                </div>
            </div>
        </div>

	<div class="box-footer">
		<button type="submit" class="btn btn-primary">Editar</button>
	</div>
	{!! Form::close() !!}
	<div class="box-footer">
		<a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
	</div>
	@stop
	@section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
	@stop
	@section('js')
@stop