<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Entities\AccionFortalecimiento;
use App\Entities\ApoyoInstitucional;
use App\Catalogs\Dpa;
use App\Catalogs\Frecuencia;
use App\Catalogs\Modalidad;
use App\Catalogs\OfertaAgropecuaria;
use App\Catalogs\Permanencia;
use App\Catalogs\Producto;
use App\Catalogs\UbicacionGeografica;
use App\Catalogs\Utm;
use App\Entities\Cialco;
use App\Entities\CialcoFrecuencia;
use App\Entities\CialcoInterinstitucional;
use App\Entities\CialcoMontoVenta;
use App\Entities\CialcoOfertaAgropecuaria;
use App\Entities\CialcoProducto;
use App\Entities\Coordenada;
use App\Entities\Direccion;
use App\Entities\Organizacion;
use App\Entities\Productor;
use App\Entities\Representante;

use App\User;
use Illuminate\Support\Facades\Hash;

/*
 * RQ13-MOV-HU058-DIS065
 */
Route::get('req80', function () {
    return view('requirements.req80');
});
Route::get('req81', function () {
    return view('requirements.req81');
});
Route::get('req82', function () {
    return view('requirements.req82');
});
Route::get('req83', function () {
    return view('requirements.req83');
});
Route::get('req84', function () {
    return view('requirements.req84');
});
Route::get('req85', function () {
    // Implementación temporal hasta definir el Controlador y Modelo

    $modalidades =
        [0 => 'FERIA',
         1 => 'CANASTA',
         2 => 'VENTA EN FINCA',
         3 => 'AGROTURISMO',
         4 => 'TIENDA',
         5 => 'COMPRA PÚBLICA',
         6 => 'HORECA',
         7 => 'OTRO'];

    $circuitos = [
        1 => 'Nuevo',
        2 => 'Fortalecido'
    ];


    return view('requirements.req85', ['modalidades' => $modalidades, 'circuitos' => $circuitos]);

});
Route::get('req86', function () {
    return view('requirements.req86');
});
Route::get('req87', function () {
    return view('requirements.req87');
});
Route::get('req88', function () {
    return view('requirements.req88');
});
Route::get('req89', function () {
    return view('requirements.req89');
});
Route::get('req90', function () {
    return view('requirements.req90');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::group(['middleware' => 'auth'], function () {

});

Route::get('/', function () {
    return view('welcome');
});


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::resource('accionfortalecimiento', 'Catalogs\AccionFortalecimientoController')->middleware('auth');
Route::resource('apoyoinstitucional', 'Catalogs\ApoyoInstitucionalController')->middleware('auth');
Route::resource('frecuencia', 'Catalogs\FrecuenciaController')->middleware('auth')->middleware('auth');
Route::resource('modalidad', 'Catalogs\ModalidadController')->middleware('auth')->middleware('auth');
Route::resource('ofertaagropecuaria', 'Catalogs\OfertaAgropecuariaController')->middleware('auth');
Route::resource('permanencia', 'Catalogs\PermanenciaController')->middleware('auth');
Route::resource('producto', 'Catalogs\ProductoController')->middleware('auth');
Route::resource('ubicaciongeografica', 'Catalogs\UbicacionGeograficaController')->middleware('auth');
Route::resource('utm', 'Catalogs\UtmController')->middleware('auth');

// TODO Controlador temporal para visualización de registros
Route::resource('cialcofrecuencia', 'CialcoFrecuenciaController')->middleware('auth');
Route::resource('cialcointerinstitucional', 'CialcoInterinstitucionalController')->middleware('auth');
Route::resource('cialcomontoventa', 'CialcoMontoVentaController')->middleware('auth');
Route::resource('cialcoofertaagropecuaria', 'CialcoOfertaAgropecuariaController')->middleware('auth');
Route::resource('cialcoproducto', 'CialcoProductoController')->middleware('auth');
Route::resource('coordenada', 'CoordenadaController')->middleware('auth');
Route::resource('direccion', 'DireccionController')->middleware('auth');
Route::resource('organizacion', 'OrganizacionController')->middleware('auth');
Route::resource('productor', 'ProductorController')->middleware('auth');
Route::resource('representante', 'RepresentanteController')->middleware('auth');

//CIALCO
Route::get('cialco/{id}/accionfortalecimiento/create', ['as' => 'cialco.accionfortalecimiento.create', 'uses' => 'CialcoController@createAccionFortalecimiento'])->middleware('auth');
Route::post('cialco/accionfortalecimiento/store', ['as' => 'cialco.accionfortalecimiento.store', 'uses' => 'CialcoController@storeAccionFortalecimiento'])->middleware('auth');
Route::get('cialco/{id}/accionfortalecimiento/destroy', ['as' => 'cialco.accionfortalecimiento.destroy', 'uses' => 'CialcoController@destroyAccionFortalecimiento'])->middleware('auth');

Route::get('cialco/{id}/apoyoinstitucional/create', ['as' => 'cialco.apoyoinstitucional.create', 'uses' => 'CialcoController@createApoyoInstitucional'])->middleware('auth');
Route::post('cialco/apoyoinstitucional/store', ['as' => 'cialco.apoyoinstitucional.store', 'uses' => 'CialcoController@storeApoyoInstitucional'])->middleware('auth');
Route::get('cialco/{id}/apoyoinstitucional/destroy', ['as' => 'cialco.apoyoinstitucional.destroy', 'uses' => 'CialcoController@destroyApoyoInstitucional'])->middleware('auth');

Route::get('cialco/{id}/frecuencia/create', ['as' => 'cialco.frecuencia.create', 'uses' => 'CialcoController@createFrecuencia'])->middleware('auth');
Route::post('cialco/frecuencia/store', ['as' => 'cialco.frecuencia.store', 'uses' => 'CialcoController@storeFrecuencia'])->middleware('auth');
Route::get('cialco/{id}/frecuencia/destroy', ['as' => 'cialco.frecuencia.destroy', 'uses' => 'CialcoController@destroyFrecuencia'])->middleware('auth');

Route::get('cialco/{id}/ofertaagropecuaria/create', ['as' => 'cialco.ofertaagropecuaria.create', 'uses' => 'CialcoController@createOfertaAgropecuaria'])->middleware('auth');
Route::post('cialco/ofertaagropecuaria/store', ['as' => 'cialco.ofertaagropecuaria.store', 'uses' => 'CialcoController@storeOfertaAgropecuaria'])->middleware('auth');
Route::get('cialco/{id}/ofertaagropecuaria/destroy', ['as' => 'cialco.ofertaagropecuaria.destroy', 'uses' => 'CialcoController@destroyOfertaAgropecuaria'])->middleware('auth');

Route::get('cialco/{id}/producto/create', ['as' => 'cialco.producto.create', 'uses' => 'CialcoController@createProducto'])->middleware('auth');
Route::post('cialco/producto/store', ['as' => 'cialco.producto.store', 'uses' => 'CialcoController@storeProducto'])->middleware('auth');
Route::get('cialco/{id}/producto/destroy', ['as' => 'cialco.producto.destroy', 'uses' => 'CialcoController@destroyProducto'])->middleware('auth');

Route::get('cialco/{id}/ubicaciongeografica/create', ['as' => 'cialco.ubicaciongeografica.create', 'uses' => 'CialcoController@createUbicacionGeografica'])->middleware('auth');
Route::post('cialco/ubicaciongeografica/store', ['as' => 'cialco.ubicaciongeografica.store', 'uses' => 'CialcoController@storeUbicacionGeografica'])->middleware('auth');
Route::get('cialco/{id}/ubicaciongeografica/destroy', ['as' => 'cialco.ubicaciongeografica.destroy', 'uses' => 'CialcoController@destroyUbicacionGeografica'])->middleware('auth');

Route::get('cialco', ['as' => 'cialco.index', 'uses' => 'CialcoController@index'])->middleware('auth');
Route::get('cialco/create', ['as' => 'cialco.create', 'uses' => 'CialcoController@create'])->middleware('auth');
Route::post('cialco/store', ['as' => 'cialco.store', 'uses' => 'CialcoController@store'])->middleware('auth');
Route::get('cialco/{id}', ['as' => 'cialco.show', 'uses' => 'CialcoController@show'])->middleware('auth');

Route::get('cialco/{id}/cialcofrecuencia/create', ['as' => 'cialco.cialcofrecuencia.create', 'uses' => 'CialcoController@createCialcoFrecuencia'])->middleware('auth');
Route::post('cialco/cialcofrecuencia/store', ['as' => 'cialco.cialcofrecuencia.store', 'uses' => 'CialcoController@storeCialcoFrecuencia'])->middleware('auth');
Route::get('cialco/{id}/cialcofrecuencia/destroy', ['as' => 'cialco.cialcofrecuencia.destroy', 'uses' => 'CialcoController@destroyCialcoFrecuencia'])->middleware('auth');

Route::get('cialco/{id}/cialcointerinstitucional/create', ['as' => 'cialco.cialcointerinstitucional.create', 'uses' => 'CialcoController@createCialcoInterinstitucional'])->middleware('auth');
Route::post('cialco/cialcointerinstitucional/store', ['as' => 'cialco.cialcointerinstitucional.store', 'uses' => 'CialcoController@storeCialcoInterinstitucional'])->middleware('auth');
Route::get('cialco/{id}/cialcointerinstitucional/destroy', ['as' => 'cialco.cialcointerinstitucional.destroy', 'uses' => 'CialcoController@destroyCialcoInterinstitucional'])->middleware('auth');

Route::get('cialco/{id}/cialcomontoventa/create', ['as' => 'cialco.cialcomontoventa.create', 'uses' => 'CialcoController@createCialcoMontoVenta'])->middleware('auth');
Route::post('cialco/cialcomontoventa/store', ['as' => 'cialco.cialcomontoventa.store', 'uses' => 'CialcoController@storeCialcoMontoVenta'])->middleware('auth');
Route::get('cialco/{id}/cialcomontoventa/destroy', ['as' => 'cialco.cialcomontoventa.destroy', 'uses' => 'CialcoController@destroyCialcoMontoVenta'])->middleware('auth');

Route::get('cialco/{id}/cialcoofertaagropecuaria/create', ['as' => 'cialco.cialcoofertaagropecuaria.create', 'uses' => 'CialcoController@createCialcoOfertaAgropecuaria'])->middleware('auth');
Route::post('cialco/cialcoofertaagropecuaria/store', ['as' => 'cialco.cialcoofertaagropecuaria.store', 'uses' => 'CialcoController@storeCialcoOfertaAgropecuaria'])->middleware('auth');
Route::get('cialco/{id}/cialcoofertaagropecuaria/destroy', ['as' => 'cialco.cialcoofertaagropecuaria.destroy', 'uses' => 'CialcoController@destroyCialcoOfertaAgropecuaria'])->middleware('auth');

Route::get('cialco/{id}/cialcoproducto/create', ['as' => 'cialco.cialcoproducto.create', 'uses' => 'CialcoController@createCialcoProducto'])->middleware('auth');
Route::post('cialco/cialcoproducto/store', ['as' => 'cialco.cialcoproducto.store', 'uses' => 'CialcoController@storeCialcoProducto'])->middleware('auth');
Route::get('cialco/{id}/cialcoproducto/destroy', ['as' => 'cialco.cialcoproducto.destroy', 'uses' => 'CialcoController@destroyCialcoProducto'])->middleware('auth');

Route::get('cialco/{id}/coordenada/create', ['as' => 'cialco.coordenada.create', 'uses' => 'CialcoController@createCoordenada'])->middleware('auth');
Route::post('cialco/coordenada/store', ['as' => 'cialco.coordenada.store', 'uses' => 'CialcoController@storeCoordenada'])->middleware('auth');
Route::get('cialco/{id}/coordenada/destroy', ['as' => 'cialco.coordenada.destroy', 'uses' => 'CialcoController@destroyCoordenada'])->middleware('auth');

Route::get('cialco/{id}/direccion/create', ['as' => 'cialco.direccion.create', 'uses' => 'CialcoController@createDireccion'])->middleware('auth');
Route::post('cialco/direccion/store', ['as' => 'cialco.direccion.store', 'uses' => 'CialcoController@storeDireccion'])->middleware('auth');
Route::get('cialco/{id}/direccion/destroy', ['as' => 'cialco.direccion.destroy', 'uses' => 'CialcoController@destroyDireccion'])->middleware('auth');

Route::get('cialco/{id}/organizacion/create', ['as' => 'cialco.organizacion.create', 'uses' => 'CialcoController@createOrganizacion'])->middleware('auth');
Route::post('cialco/organizacion/store', ['as' => 'cialco.organizacion.store', 'uses' => 'CialcoController@storeOrganizacion'])->middleware('auth');
Route::get('cialco/{id}/organizacion/destroy', ['as' => 'cialco.organizacion.destroy', 'uses' => 'CialcoController@destroyOrganizacion'])->middleware('auth');

Route::get('cialco/{id}/productor/create', ['as' => 'cialco.productor.create', 'uses' => 'CialcoController@createProductor'])->middleware('auth');
Route::post('cialco/productor/store', ['as' => 'cialco.productor.store', 'uses' => 'CialcoController@storeProductor'])->middleware('auth');
Route::get('cialco/{id}/productor/destroy', ['as' => 'cialco.productor.destroy', 'uses' => 'CialcoController@destroyProductor'])->middleware('auth');

Route::get('cialco/{id}/representante/create', ['as' => 'cialco.representante.create', 'uses' => 'CialcoController@createRepresentante'])->middleware('auth');
Route::post('cialco/representante/store', ['as' => 'cialco.representante.store', 'uses' => 'CialcoController@storeRepresentante'])->middleware('auth');
Route::get('cialco/{id}/representante/destroy', ['as' => 'cialco.representante.destroy', 'uses' => 'CialcoController@destroyRepresentante'])->middleware('auth');


// FOR TESTING
Route::get('afr/', function () {
    /*$rep=AccionFortalecimiento::where('pro_cialco_id',1)->get();
        dd($coa);*/
    $cialco = Cialco::find(1);
    dd($cialco->accionfortalecimiento);
});

Route::get('ain/', function () {
    /*$rep=ApoyoInstitucional::where('pro_cialco_id',1)->get();
        dd($coa);*/
    $cialco = Cialco::find(1);
    dd($cialco->apoyoinstitucional);
});

Route::get('dpa/', function () {
    $ubicacion = Dpa::find('01');
    dd($ubicacion);
});

Route::get('rep/', function () {
    /*$rep=Representante::where('rep_cialco_id',1)->get();
        dd($rep);*/
    $cialco = Cialco::find(1);
    dd($cialco->representantes);
});

Route::get('ofa/', function () {
    /*$rep=OfertaAgropecuaria::where('ofa_cialco_id',1)->get();
        dd($ofa);*/
    $cialco = Cialco::find(1);
    dd($cialco->ofertaagropecuaria);
});

Route::get('coa/', function () {
    /*$rep=CialcoOfertaAgropecuaria::where('coa_cialco_id',1)->get();
        dd($coa);*/
    $cialco = Cialco::find(1);
    dd($cialco->cialcoofertaagropecuaria);
});

Route::get('uge/', function () {
    /*$rep=UbicacionGeografica::where('coa_cialco_id',1)->get();
        dd($coa);*/
    $cialco = Cialco::find(1);
    dd($cialco->ubicaciongeografica);
});

Route::get('org/', function () {
    /*$rep=Organizacion::where('coa_cialco_id',1)->get();
        dd($coa);*/
    $cialco = Cialco::find(1);
    dd($cialco->organizacion);
});

Route::get('pro/', function () {
    /*$rep=Productor::where('pro_cialco_id',1)->get();
        dd($coa);*/
    $cialco = Cialco::find(1);
    dd($cialco->productor);
});

Route::get('int/', function () {
    /*$rep=CialcoInterinstitucional::where('int_cialco_id',1)->get();
        dd($coa);*/
    $cialco = Cialco::find(1);
    dd($cialco->cialcointerinstitucional);
});

Route::get('prd/', function () {
    /*$rep=CialcoProducto::where('int_cialco_id',1)->get();
        dd($coa);*/
    $cialco = Cialco::find(1);
    dd($cialco->producto);
});

Route::get('cpr/', function () {
    /*$rep=CialcoProducto::where('int_cialco_id',1)->get();
        dd($coa);*/
    $cialco = Cialco::find(1);
    dd($cialco->cialcoproductos);
});


Route::get('cmv/', function () {
    /*$rep=CialcoProducto::where('int_cialco_id',1)->get();
        dd($coa);*/
    $cialco = Cialco::find(1);
    dd($cialco->cialcomontoventa);
});

// Testing JSON Store
Route::get('frec', function () {
  /*  $model = Permanencia::find(1);
    $model->delete();*/

    $arr=[
        1=>'L',
        2=>'M',
        3=>'Mi',
        4=>'J',
        5=>'J',
        6=>'S',
        7=>'D',
    ];
    dd($arr);
    $json_e=json_encode($arr);
    $json_d=json_decode($json_e,true);
    dd($json_d);
});
