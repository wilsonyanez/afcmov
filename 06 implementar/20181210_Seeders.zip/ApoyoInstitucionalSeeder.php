<?php

use Illuminate\Database\Seeder;

class ApoyoInstitucionalSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('apoyo_institucional')->insert([
            'ain_descripcion'=>'Gad Provincial',
            'ain_orden' => 1,
            'ain_fecha_inicio'=>date_create('now UTC'),
            'ain_fecha_inserta'=>date_create('now UTC'),
            'ain_fecha_actualiza'=>date_create('now UTC')
        ]);
        \DB::table('apoyo_institucional')->insert([
            'ain_descripcion'=>'Gad Cantonal',
            'ain_orden' => 2,
            'ain_fecha_inicio'=>date_create('now UTC'),
            'ain_fecha_inserta'=>date_create('now UTC'),
            'ain_fecha_actualiza'=>date_create('now UTC')
        ]);
        \DB::table('apoyo_institucional')->insert([
            'ain_descripcion'=>'Gad Parroquial',
            'ain_orden' => 3,
            'ain_fecha_inicio'=>date_create('now UTC'),
            'ain_fecha_inserta'=>date_create('now UTC'),
            'ain_fecha_actualiza'=>date_create('now UTC')
        ]);
        \DB::table('apoyo_institucional')->insert([
            'ain_descripcion'=>'ONG',
            'ain_orden' => 4,
            'ain_fecha_inicio'=>date_create('now UTC'),
            'ain_fecha_inserta'=>date_create('now UTC'),
            'ain_fecha_actualiza'=>date_create('now UTC')
        ]);
        \DB::table('apoyo_institucional')->insert([
            'ain_descripcion'=>'Cooperación Internacional',
            'ain_orden' => 5,
            'ain_fecha_inicio'=>date_create('now UTC'),
            'ain_fecha_inserta'=>date_create('now UTC'),
            'ain_fecha_actualiza'=>date_create('now UTC')
        ]);
        \DB::table('apoyo_institucional')->insert([
            'ain_descripcion'=>'Institutos o Universidades',
            'ain_orden' => 6,
            'ain_fecha_inicio'=>date_create('now UTC'),
            'ain_fecha_inserta'=>date_create('now UTC'),
            'ain_fecha_actualiza'=>date_create('now UTC')
        ]);
        \DB::table('apoyo_institucional')->insert([
            'ain_descripcion'=>'Colectivos',
            'ain_orden' => 7,
            'ain_fecha_inicio'=>date_create('now UTC'),
            'ain_fecha_inserta'=>date_create('now UTC'),
            'ain_fecha_actualiza'=>date_create('now UTC')
        ]);
        \DB::table('apoyo_institucional')->insert([
            'ain_descripcion'=>'Empresa privadas',
            'ain_orden' => 8,
            'ain_fecha_inicio'=>date_create('now UTC'),
            'ain_fecha_inserta'=>date_create('now UTC'),
            'ain_fecha_actualiza'=>date_create('now UTC')
        ]);
        \DB::table('apoyo_institucional')->insert([
            'ain_descripcion'=>'MAG',
            'ain_orden' => 9,
            'ain_fecha_inicio'=>date_create('now UTC'),
            'ain_fecha_inserta'=>date_create('now UTC'),
            'ain_fecha_actualiza'=>date_create('now UTC')
        ]);
        \DB::table('apoyo_institucional')->insert([
            'ain_descripcion'=>'Otro',
            'ain_orden' => 10,
            'ain_fecha_inicio'=>date_create('now UTC'),
            'ain_fecha_inserta'=>date_create('now UTC'),
            'ain_fecha_actualiza'=>date_create('now UTC')
        ]);
    }
}