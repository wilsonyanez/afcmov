@extends('adminlte::page')



@section('title', 'Dashboard')



@section('content_header')

    <h1>RQ23-WEB-HU089</h1>
    <p>Como Técnico de Territorio, quiero Registrar Datos de Apoyo institucional al CIALCO, que me solicita el Administrador AFC para validar la participación en el Mercado de los Circuitos Alternativos de Comercialización de la AFC.</p>
"Diseño: Cumplir formato detallado en los archivos:
RQ23-WEB-HU089-DIS074 Apoyo institucional al CIALCO.png
"
"Usabilidad: Cumplir con el detalle descrito en pestaña funcionalidad con identificación: RQ23-WEB-HU089-FUN
"
"Rendimiento: Tiempo de respuesta inferior a 5 segundos
"
"Satisfacción: Cumplimiento de Pruebas funcionales
"
@stop



@section('content')

    <p>Welcome to this beautiful admin panel - HDTuto.com.</p>
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Apoyo Institucional al Cialco</h3>
            <p>Ordenanzas (Municipio)<br>Proyectos de Vinculación<br>Asistencia Técnica (609 Proviciales, Parroquiales)<br>
                Promoción y Difusión<br>Financiamiento</p>
            <div class="row">

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Institución</label>
                        <select class="form-control">
                            <option>Opción 1</option>
                            <option>Opción 2</option>
                            <option>Opción 3</option>
                            <option>Opción 4</option>
                        </select>
                        <p>
                            <span class="label label-info">Dropdown?</span>
                            <span class="label label-info">Búsqueda?</span>
                        </p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Línea de Apoyo</label>
                        <select class="form-control">
                            <option>Opción 1</option>
                            <option>Opción 2</option>
                            <option>Opción 3</option>
                            <option>Opción 4</option>
                        </select>
                        <p>
                            <span class="label label-info">Dropdown?</span>
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">

                <div class="col-md-12">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Descripción</label>
                        <textarea class="form-control" rows="3" placeholder="Descripción máximo 150 caracteres"></textarea>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Año</label>
                        <input type="date" class="form-control" id="exampleInputEmail1" placeholder="Fecha">
                    </div>
                </div>
            </div>

        </div>


        <div class="box-footer">
            <button type="submit" class="btn btn-primary">Agregar</button>
        </div>

    </div>

@stop



@section('css')

    <link rel="stylesheet" href="/css/admin_custom.css">

@stop



@section('js')

    <script> console.log('Hi!'); </script>

@stop