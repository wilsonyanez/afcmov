<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreFrecuenciaRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'fre_descripcion' =>'alpha|max:256|required',
            'fre_orden' =>'integer|required',
            'fre_estado' =>'required',
        ];
    }
    public function messages()
    {
        return [
            'fre_descripcion.required' => 'Descripción es requerido',
            'fre_orden.required' => 'Orden es requerido',
            'fre_estado.required' => 'Estado es requerido',

        ];
    }
}