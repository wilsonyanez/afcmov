<?php

use Illuminate\Database\Seeder;

class ModalidadSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('modalidad')->insert([
            'mod_descripcion'=>'Feria',
            'mod_fecha_inserta'=>date_create('now UTC'),
            'mod_fecha_actualiza'=>date_create('now UTC')
        ]);
        \DB::table('modalidad')->insert([
            'mod_descripcion'=>'Canasta',
            'mod_fecha_inserta'=>date_create('now UTC'),
            'mod_fecha_actualiza'=>date_create('now UTC')
        ]);
        \DB::table('modalidad')->insert([
            'mod_descripcion'=>'Venta en finca',
            'mod_fecha_inserta'=>date_create('now UTC'),
            'mod_fecha_actualiza'=>date_create('now UTC')
        ]);
        \DB::table('modalidad')->insert([
            'mod_descripcion'=>'Agroturismo',
            'mod_fecha_inserta'=>date_create('now UTC'),
            'mod_fecha_actualiza'=>date_create('now UTC')
        ]);
        \DB::table('modalidad')->insert([
            'mod_descripcion'=>'Tienda',
            'mod_fecha_inserta'=>date_create('now UTC'),
            'mod_fecha_actualiza'=>date_create('now UTC')
        ]);
        \DB::table('modalidad')->insert([
            'mod_descripcion'=>'Compra pública',
            'mod_fecha_inserta'=>date_create('now UTC'),
            'mod_fecha_actualiza'=>date_create('now UTC')
        ]);
        \DB::table('modalidad')->insert([
            'mod_descripcion'=>'Otro',
            'mod_otro'=>true,
            'mod_fecha_inserta'=>date_create('now UTC'),
            'mod_fecha_actualiza'=>date_create('now UTC')
        ]);
    }
}
