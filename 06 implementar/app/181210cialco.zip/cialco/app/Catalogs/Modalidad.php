<?php

namespace App\Catalogs;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Modalidad extends Model
{
    protected $table = 'modalidad';
    protected $primaryKey = 'mod_modalidad_id';
    const CREATED_AT = 'mod_fecha_inserta';
    const UPDATED_AT = 'mod_fecha_actualiza';

    use SoftDeletes;
    const DELETED_AT = 'mod_fecha_elimina';

    protected $append = [
        'texto_estado',
        'texto_estado_html'
    ];
    protected $fillable = [
        'mod_descripcion',
        'mod_estado',
        'mod_orden'
    ];
    public function modalidad()
    {
        return $this->belongsTo('App\Catalogs\Modalidad', 'mod_modalidad_id');
    }
    public function getTextoEstadoAttribute()
    {
        return ($this->mod_estado ? 'Activo' : 'Inactivo');
    }

    public function getTextoEstadoHtmlAttribute()
    {
        if ($this->mod_estado)
            return ('<span class="label label-success">' . $this->texto_estado . '</span>');
        return ('<span class="label label-default">' . $this->texto_estado . '</span>');
    }
}