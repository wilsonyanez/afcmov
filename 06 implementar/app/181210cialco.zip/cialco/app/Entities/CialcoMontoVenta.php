<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class CialcoMontoVenta extends Model
{
    protected $table = 'cialco_monto_venta';
    protected $primaryKey = 'cmv_cialco_monto_venta_id';
    const CREATED_AT = 'cmv_fecha_inserta';
    const UPDATED_AT = 'cmv_fecha_actualiza';

    use SoftDeletes;
    const DELETED_AT = 'cmv_fecha_elimina';

    protected $append = [
        'texto_estado',
        'texto_estado_html'
    ];

    protected $fillable = [
        'cmv_cialco_monto_venta_id',
        'cmv_cialco_id',
        'cmv_ejercicio',
        'cmv_periodo',
        'cmv_monto',
        'cmv_fecha_inicio',
        'cmv_fecha_fin',
        'cmv_estado'
    ];

    public function cialco()
    {
        return $this->belongsTo('App\Entities\Cialco', 'cmv_cialco_id');
    }

    public function getTextoEstadoAttribute()
    {
        return ($this->cmv_estado ? 'Activo' : 'Inactivo');
    }

    public function getTextoEstadoHtmlAttribute()
    {
        if ($this->cmv_estado)
            return ('<span class="label label-success">' . $this->texto_estado . '</span>');
        return ('<span class="label label-default">' . $this->texto_estado . '</span>');
    }	
}