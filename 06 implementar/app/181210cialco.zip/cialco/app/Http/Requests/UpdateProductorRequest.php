<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateProductorRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'pro_dispone_sello_afc' => 'required',
            'pro_numero_cedula' => 'integer|digits:1|required0',
            'pro_nombres' => 'alpha|max:256|required',
            'pro_apellidos' => 'alpha|max:256|required',
            'pro_genero' => 'required',
            'pro_fecha_nacimiento' => 'date|required',
            'pro_nacionalidad' => 'alpha|max:256|required',
            'pro_fecha_inicio' => 'date|required',
            'pro_estado' => 'required',
        ];
    }
	
    public function messages()
    {
        return [
            'pro_dispone_sello_afc' => 'Sello AFC es requerido',
            'pro_numero_cedula' => 'Número de cédula es requerido',
            'pro_nombres' => 'Nombres es requerido',
            'pro_apellidos' => 'Apellidos es requerido',
            'pro_genero' => 'Género es required',
            'pro_fecha_nacimiento' => 'Fecha de nacimientos es requerido',
            'pro_nacionalidad' => 'Nacionalidad es requerido',
            'pro_fecha_inicio' => 'Fecha de inicio es requerido',
            'pro_estado' => 'Estado es requerido',
        ];
    }
}