<?php

use Illuminate\Database\Seeder;

class AccionFortalecimientoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('accion_fortalecimiento')->insert([
            'afr_descripcion' => 'Fortalecimiento de Capacidades',
            'afr_orden' => 1,
            'afr_fecha_inserta' => date_create('now UTC'),
            'afr_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('accion_fortalecimiento')->insert([
            'afr_descripcion' => 'Asistencia técnica',
            'afr_orden' => 2,
            'afr_fecha_inserta' => date_create('now UTC'),
            'afr_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('accion_fortalecimiento')->insert([
            'afr_descripcion' => 'Gestión del uso del espacio',
            'afr_orden' => 3,
            'afr_fecha_inserta' => date_create('now UTC'),
            'afr_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('accion_fortalecimiento')->insert([
            'afr_descripcion' => 'Gestión de Ordenazas, convenios y acuerdos',
            'afr_orden' => 4,
            'afr_fecha_inserta' => date_create('now UTC'),
            'afr_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('accion_fortalecimiento')->insert([
            'afr_descripcion' => 'Estrategias de Promoción y Difusión',
            'afr_orden' => 5,
            'afr_fecha_inserta' => date_create('now UTC'),
            'afr_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('accion_fortalecimiento')->insert([
            'afr_descripcion' => 'Gestión de recursos',
            'afr_orden' => 6,
            'afr_fecha_inserta' => date_create('now UTC'),
            'afr_fecha_actualiza' => date_create('now UTC')
        ]);
    }
}