<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCialcoProductoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cialco_producto', function (Blueprint $table) {
            $table->increments('cpr_cialco_producto_id');
            $table->integer('cpr_ejercicio')->unsigned()->default(0);
            $table->integer('cpr_periodo')->unsigned()->default(0);
            $table->decimal('cpr_precio', 9, 2)->default(0);
            $table->integer('cpr_unidad')->unsigned()->default(0);

            // COLUMNAS DE CONTROL
            $table->boolean('cpr_estado')->default(true);

            $table->date('cpr_fecha_inicio');
            $table->date('cpr_fecha_fin')->nullable();

            $table->integer('cpr_usuario_inserta')->unsigned()->nullable();
            $table->timestamp('cpr_fecha_inserta')->nullable();

            $table->integer('cpr_usuario_actualiza')->unsigned()->nullable();
            $table->timestamp('cpr_fecha_actualiza')->nullable();

            $table->integer('cpr_usuario_elimina')->unsigned()->nullable();
            $table->timestamp('cpr_fecha_elimina')->nullable();

            // FOREINGS
            $table->unsignedInteger('cpr_producto_id');
            $table->foreign('cpr_producto_id')->references('prd_producto_id')->on('producto');
            $table->unsignedInteger('cpr_cialco_id');
            $table->foreign('cpr_cialco_id')->references('cia_cialco_id')->on('cialco');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cialco_producto');
    }
}