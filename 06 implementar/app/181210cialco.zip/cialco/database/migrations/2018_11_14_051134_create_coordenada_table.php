<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCoordenadaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('coordenada', function (Blueprint $table) {
            $table->increments('coo_coordenada_id');
            $table->float('coo_posicion_x',14,6)->nullable();
            $table->float('coo_posicion_y',14,6)->nullable();
            $table->float('coo_posicion_z',14,6)->nullable();

            // COLUMNAS DE CONTROL
            $table->boolean('coo_estado')->default(true);

            $table->date('coo_fecha_inicio')->nullable();
            $table->date('coo_fecha_fin')->nullable();

            $table->integer('coo_usuario_inserta')->unsigned()->nullable();
            $table->timestamp('coo_fecha_inserta')->nullable();

            $table->integer('coo_usuario_actualiza')->unsigned()->nullable();
            $table->timestamp('coo_fecha_actualiza')->nullable();

            $table->integer('coo_usuario_elimina')->unsigned()->nullable();
            $table->timestamp('coo_fecha_elimina')->nullable();

            // FOREINGS
            $table->unsignedInteger('coo_cialco_id');
            $table->foreign('coo_cialco_id')->references('cia_cialco_id')->on('cialco');

            $table->unsignedInteger('coo_utm_id');
            $table->foreign('coo_utm_id')->references('utm_utm_id')->on('utm');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('coordenada');
    }
}
