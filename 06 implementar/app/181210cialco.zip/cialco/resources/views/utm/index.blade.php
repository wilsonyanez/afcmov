@extends('adminlte::page')
@section('title', 'UTM')
@section('content_header')
    <h1>UTM</h1>
@stop
@section('content')
    @include('include.alert')
    <div class="box box-primary">
        <div class="box-header with-border">
            <h2 class="page-header">
                <i class="fa fa-globe"></i> Listado
            <a class="btn btn-sm btn-default pull-right" href="{{route('utm.create')}}">Nuevo</a>
                </h2>
        </div>
        <div class="row">
            <div class="col-xs-12 table-responsive">
                <table class="table table-striped">
                <tr>

                  <th>ID</th>
                  <th>Descripción</th>
                  <th>Orden</th>
                  <th>Fecha Inicio</th>
                  <th>Fecha Fin</th>
                  <th>Fecha Creación</th>
                  <th>Estado</th>
                  <th>Acciones</th>
                </tr>
                @foreach($results as $key=>$item)
                <tr>
                       <td>{{$key+1}}</td>
                       <td>{{$item->utm_descripcion}}</td>
                       <td>{{$item->utm_orden}}</td>
					   <td>{{$item->utm_fecha_inicio}}</td>
					   <td>{{$item->utm_fecha_fin}}</td>
                       <td>{{$item->utm_fecha_inserta}}</td>
                       <td>{!!$item->texto_estado_html!!}</td>
                    <td>
                        <a href="{{route('utm.show',['id'=>$item->utm_utm_id])}} "class="label label-primary">Ver</a>
                        <a href="{{route('utm.edit',['id'=>$item->utm_utm_id])}}" class="label label-primary">Editar</a>
                    </td>
                </tr>
                @endforeach
              </table>
        </div>
        </div>
        <div class="box-footer">
        {{--<a class="btn btn-sm btn-default pull-right" href="{{route('cialco.create')}}">Nuevo</a>--}}
        </div>
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')

@stop