<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class CialcoFrecuencia extends Model
{
    protected $table = 'cialco_frecuencia';
    protected $primaryKey = 'cfr_cialco_frecuencia_id';
    const CREATED_AT = 'cfr_fecha_inserta';
    const UPDATED_AT = 'cfr_fecha_actualiza';

    use SoftDeletes;
    const DELETED_AT = 'cfr_fecha_elimina';

    protected $append = [
        'texto_estado',
        'texto_estado_html'
    ];

    protected $fillable = [
        "cfr_hora_inicio",
        "cfr_hora_fin",
        "cfr_dias",
        "cfr_descripcion",
        "cfr_fecha_inicio",
        "cfr_fecha_fin",
        "cfr_estado",
		"cfr_cialco_id",
        "cfr_frecuencia_id",
    ];

    public function frecuencia()
    {
        return $this->belongsTo('App\Catalogs\Frecuencia', 'cfr_frecuencia_id');
    }

    public function cialco()
    {
        return $this->belongsTo('App\Entities\Cialco', 'cfr_cialco_id');
    }

    public function getTextoEstadoAttribute()
    {
        return ($this->cfr_estado ? 'Activo' : 'Inactivo');
    }

    public function getTextoEstadoHtmlAttribute()
    {
        if ($this->cfr_estado)
            return ('<span class="label label-success">' . $this->texto_estado . '</span>');
        return ('<span class="label label-default">' . $this->texto_estado . '</span>');
    }
}