@extends('adminlte::page')
@section('title', 'Cialco Interinstitucional')
@section('content_header')
    <h1>Cialco Interinstitucional</h1>
@stop
  @section('content')
    @include('include.alert')
    <div class="box box-primary">
        <div class="box-header">
            <h2 class="page-header">
                <i class="fa fa-globe"></i> Cialco Interinstitucional
            </h2>
        </div>
        <div class="box-body">
              {!! $grid !!}
        </div>
	<div class="box-footer">
	</div>
  @stop
  @section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
    @stop
  @section('js')
@stop