SELECT * FROM formulario;
SELECT substr(clave, 1, 9) || '-' || substr(clave, 10, 1) || '-' || substr(clave, 11, 12) FROM formulario;
UPDATE formulario SET clave = substr(clave, 1, 9) || '-' || substr(clave, 10, 1) || '-' || substr(clave, 11, 12) ;

SELECT * FROM formulario_deth;
UPDATE formulario_deth SET clave = substr(clave, 1, 9) || '-' || substr(clave, 10, 1) || '-' || substr(clave, 11, 12) ;

SELECT * FROM formulario_detv;
UPDATE formulario_detv SET clave = substr(clave, 1, 9) || '-' || substr(clave, 10, 1) || '-' || substr(clave, 11, 12) ;

SELECT * FROM formulario_detv WHERE id_fdetv = 75 and cod_mod = 'm1a' and cod_preg = 'v00_10';
UPDATE formulario_detv SET valor = 'maria@gmail.com' WHERE id_fdetv = 75 and cod_mod = 'm1a' and cod_preg = 'v00_10';

SELECT * FROM organizacion;
UPDATE organizacion SET clave = substr(clave, 1, 9) || '-' || substr(clave, 10, 1) || '-' || substr(clave, 11, 12) ;

SELECT * FROM organizacion_deth;
UPDATE organizacion_deth SET clave = substr(clave, 1, 9) || '-' || substr(clave, 10, 1) || '-' || substr(clave, 11, 12) ;

SELECT * FROM organizacion_detv;
UPDATE organizacion_detv SET clave = substr(clave, 1, 9) || '-' || substr(clave, 10, 1) || '-' || substr(clave, 11, 12) ;

SELECT * FROM establecimiento;
UPDATE establecimiento SET clave = substr(clave, 1, 9) || '-' || substr(clave, 10, 1) || '-' || substr(clave, 11, 12) ;

SELECT * FROM establecimiento_deth;
UPDATE establecimiento_deth SET clave = substr(clave, 1, 9) || '-' || substr(clave, 10, 1) || '-' || substr(clave, 11, 12) ;

SELECT * FROM establecimiento_detv;
UPDATE establecimiento_detv SET clave = substr(clave, 1, 9) || '-' || substr(clave, 10, 1) || '-' || substr(clave, 11, 12) ;

SELECT * FROM organizacion_deth WHERE cod_orga BETWEEN 3 AND 20;
DELETE FROM organizacion_deth WHERE cod_orga BETWEEN 3 AND 20;

SELECT * FROM organizacion_detv WHERE cod_orga BETWEEN 3 AND 20;
DELETE FROM organizacion_detv WHERE cod_orga BETWEEN 3 AND 20;

SELECT * FROM organizacion WHERE id_organizacion BETWEEN 3 AND 20;
DELETE FROM organizacion WHERE id_organizacion BETWEEN 3 AND 20;

UPDATE organizacion SET tipo = 'A' ;

SELECT * FROM organizacion_deth WHERE id_odeth = 19;
UPDATE organizacion_deth SET val01 = '3' WHERE id_odeth = 19 ;

SELECT * FROM organizacion_deth WHERE id_odeth = 20;
UPDATE organizacion_deth SET orden = '2' WHERE id_odeth = 20 ;

SELECT * FROM organizacion_detv WHERE cod_orga = 21 ;

SELECT * FROM organizacion_detv WHERE cod_orga = 21 and cod_mod = 'c4g';
UPDATE organizacion_detv SET cod_mod = 'c4h' WHERE cod_orga = 21 and cod_mod = 'c4g' ;

SELECT * FROM organizacion_detv WHERE cod_orga = 21 and cod_mod = 'c4f';
UPDATE organizacion_detv SET cod_mod = 'c4g' WHERE cod_orga = 21 and cod_mod = 'c4f' ;

SELECT * FROM organizacion_detv WHERE cod_orga = 21 and cod_mod = 'c4e';
UPDATE organizacion_detv SET cod_mod = 'c4f' WHERE cod_orga = 21 and cod_mod = 'c4e' ;

SELECT * FROM organizacion_detv WHERE cod_orga = 21 and cod_mod = 'c4d';
UPDATE organizacion_detv SET cod_mod = 'c4e' WHERE cod_orga = 21 and cod_mod = 'c4d' ;


SELECT * FROM cialco_deth WHERE cod_var = "c4h";
SELECT * FROM cialco_deth WHERE id_cdeth = 12 ;
UPDATE cialco_deth SET orden = '2' WHERE id_cdeth = 12 ;

select d.*,pro.texto as pro,can.texto as can,par.texto as par from cialco_deth d, dpa par, dpa can, dpa pro 
where d.val03=par.id_dpa and par.cod_dpa=can.id_dpa and can.cod_dpa=pro.id_dpa and cod_cial=1 and cod_var='c4h' order by orden

select d.*,pro.texto as pro,can.texto as can from cialco_deth d dpa can, dpa pro 
where d.val05=can.id_dpa and can.cod_dpa=pro.id_dpa and cod_cial=1 and cod_var='c4h' order by orden

select d.*, pro.texto as pro from cialco_deth d, dpa pro where d.val03=pro.id_dpa and cod_cial=1 and cod_var='c4h' order by orden

SELECT * FROM cialco_deth WHERE cod_var = 'c4i' ;
DELETE FROM cialco_deth WHERE cod_var = 'c4i';

commit;


select * from cialco_deth where cod_cial=1 order by id_cdeth;

SELECT * FROM cialco_deth WHERE cod_var = 'c4b' ;
UPDATE cialco_deth SET val08 = 'EL TROJE 2' WHERE id_cdeth = 1 ;