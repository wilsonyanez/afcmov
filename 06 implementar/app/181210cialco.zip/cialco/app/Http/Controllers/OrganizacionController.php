<?php

namespace App\Http\Controllers;

use App\Entities\Organizacion;
use App\Http\Requests\StoreOrganizacionRequest;
use App\Entities\Cialco;
use App\Entities\CialcoFrecuencia;
use App\Http\Requests\StoreCialcoRequest;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;

class OrganizacionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $resutls=Organizacion::get();
        return view('organizacion.index',['results'=>$resutls]);
    }

	public function cialco()
    {
		$cialco = Cialco::with('cialco')->get();
        return view('cialco.show', compact('$cialco'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
		$cialcos = Cialco::pluck('cia_nombre', 'cia_cialco_id');
        return view('organizacion.create', ['cialcos' => $cialcos]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            Organizacion::create($request->all());
            Session::flash('flash_message', Config::get('session.create'));
        } catch (\Exception $e) {
            Session::flash('error', Config::get('session.error'));
            return back()->withInput();
        }

        return redirect()->route('organizacion.show', ['id' => $organizacion->org_organizacion_id]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $result= Organizacion::find($id);
        return view('organizacion.show',['result' =>$result]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $result = Organizacion::find($id);
        return view('organizacion.edit',['result'=>$result]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $result = Organizacion::find($id);

        request()->validate([
           'org_hecho_derecho' => 'required',
           'org_ruc' => 'required',
           'org_razon_social' => 'required',
           'org_registro_seps' => 'required',
           'org_acreditado_mag' => 'required',
           'org_nro_productores_total',
           'org_nro_productores_hombres',
           'org_nro_productores_mujeres',
           'org_fecha_inicio' => 'required',
           'org_estado' => 'required',
        ]);

        $input = $request->all();
        $result->fill($input)->save();
        Session::flash('flash_message','El registro fue actualizado exitosamente');

        return redirect()->route('organizacion.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
	
	
}