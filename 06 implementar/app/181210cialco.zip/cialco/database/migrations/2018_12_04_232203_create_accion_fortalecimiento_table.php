<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAccionFortalecimientoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('accion_fortalecimiento', function (Blueprint $table) {
            $table->increments('afr_accion_fortalecimiento_id');
            $table->text('afr_descripcion');
            $table->integer('afr_orden')->unsigned()->nullable();

            $table->date('afr_fecha_inicio')->nullable();
            $table->date('afr_fecha_fin')->nullable();

            // TODO Verificar si es necesario agregar integridad referencial para usuario
            $table->boolean('afr_estado')->default(true);

            $table->integer('afr_usuario_inserta')->unsigned()->nullable();
            $table->timestamp('afr_fecha_inserta')->nullable();

            $table->integer('afr_usuario_actualiza')->unsigned()->nullable();
            $table->timestamp('afr_fecha_actualiza')->nullable();

            $table->integer('afr_usuario_elimina')->unsigned()->nullable();
            $table->timestamp('afr_fecha_elimina')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('accion_fortalecimiento');
    }
}