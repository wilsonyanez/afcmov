<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddApoyoInstitucionalToCialcoInterinstitucional extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('cialco_interinstitucional', function (Blueprint $table) {

            // FOREINGS
            $table->unsignedInteger('int_apoyo_institucional_id')->after('int_accion_fortalecimiento_id');
            $table->foreign('int_apoyo_institucional_id')->references('ain_apoyo_institucional_id')->on('apoyo_institucional');
            // DROPS
            $table->dropColumn(['int_ong']);
            $table->dropColumn(['int_coop_internacional']);
            $table->dropColumn(['int_instituto_universidad']);
            $table->dropColumn(['int_colectivos']);
            $table->dropColumn(['int_empresa_privada']);
            $table->dropColumn(['int_descripcion_otro']);
            $table->dropColumn(['int_mag']);
        });
    }
	
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('cialco_interinstitucional', function (Blueprint $table) {
            // DROPS
            $table->dropColumn(['int_apoyo_institucional_id']);
            // CREATE
            $table->boolean('int_ong')->nullable()->default(false);
            $table->boolean('int_coop_internacional')->nullable()->default(false);
            $table->boolean('int_instituto_universidad')->nullable()->default(false);
            $table->boolean('int_colectivos')->nullable()->default(false);
            $table->boolean('int_empresa_privada')->nullable()->default(false);
            $table->text('int_descripcion_otro')->nullable();
            $table->boolean('int_mag')->nullable()->default(false);
        });
    }
}