<?php

use Illuminate\Database\Seeder;

class ProductorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        $faker = Faker\Factory::create();
        for($i=0 ; $i<200; $i++){
            \DB::table('productor')->insert([
                'pro_dispone_sello_afc'=>$faker->numberBetween(0,1),
                'pro_identificacion_sello_afc' =>$faker->ean13,
                'pro_numero_cedula' =>$faker->ean13,
                'pro_nombres' =>$faker->name,
                'pro_apellidos' =>$faker->name,
                'pro_genero'=>$faker->numberBetween(0,1),
                'pro_fecha_nacimiento' => date_create('now UTC'),
                'pro_nacionalidad' => $faker->numberBetween(0, 150),
                'pro_cialco_id'=>$faker->numberBetween(1,100),
                'pro_estado'=>$faker->numberBetween(0,1),
                'pro_fecha_inicio'=>date_create('now UTC'),
                'pro_fecha_fin'=>date_create('now UTC'),
                'pro_fecha_inserta'=>date_create('now UTC'),
                'pro_fecha_actualiza'=>date_create('now UTC'),

            ]);
        }
    }
}