@extends('adminlte::page')
@section('title', 'Permanencia')
@section('content_header')
   <h1>Permanencia</h1>
@stop
@section('content')
    {!! Form::open(['route' => 'permanencia.store','method'=> 'post']) !!}
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Catálogo Permanencia</h3>
        </div>
        <div class="box-body">
            <div class="row"> <!-- ROW 1 -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="per_descripcion">Descripción</label>
                        {{ Form::text('per_descripcion',null,['class'=>'form-control', 'required' => 'required|alpha'])}}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="per_orden">Orden</label>
                        {{ Form::number('per_orden',null,['class'=>'form-control', 'required' => 'required|integer'])}}
						@include('include.error_form_element',['name'=>'per_orden'])
                    </div>
                </div>
				<div class="col-md-3">
					<div class="form-group">
						<label for="per_fecha_inicio">Fecha Inicio</label></br>
							{{ Form::date('per_fecha_inicio', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
							@include('include.error_form_element',['name'=>'per_fecha_inicio'])
					</div>
				</div>
            </div>
            <div class="row"> <!-- ROW 2 -->
				<div class="col-md-3">
					<div class="form-group">
						<label for="per_fecha_fin">Fecha Fin</label></br>
							{{ Form::date('per_fecha_fin', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
							@include('include.error_form_element',['name'=>'per_fecha_fin'])
					</div>
				</div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="per_estado">Estado</label>
                        {{ Form::select('per_estado',['1' => 'Activo', '0' => 'Inactivo'],null,['class'=>'form-control'])}}
						@include('include.error_form_element',['name'=>'per_estado'])
                    </div>
                </div>
            </div>
        </div>

	<div class="box-footer">
		<button type="submit" class="btn btn-primary">Agregar</button>
	</div>
	{!! Form::close ()!!}
	<div class="box-footer">
		<a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
	</div>
	@stop
	@section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
	@stop
	@section('js')
		<script> console.log('Hi!'); </script>
@stop