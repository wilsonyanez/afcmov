TRUNCATE TABLE usuario ;

TRUNCATE TABLE formulario ;

TRUNCATE TABLE formulario_detv ;

TRUNCATE TABLE formulario_deth ;

TRUNCATE TABLE dpa ;
