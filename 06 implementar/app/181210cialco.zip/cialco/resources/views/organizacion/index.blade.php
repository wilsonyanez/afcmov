@extends('adminlte::page')
@section('title', 'Organizaciones')
@section('content_header')
    <h1>Organizaciones</h1>
@stop
@section('content')
    @include('include.alert')
    <div class="box box-primary">
        <div class="box-header with-border">
            <h2 class="page-header">
                <i class="fa fa-globe"></i> Listado
            </h2>
        </div>
        <div class="row">
            <div class="col-xs-14 table-responsive">
                <table class="table table-striped">
                <tr>
                  <th>ID</th>
                  <th>Organización hecho/derecho</th>
                  <th>RUC</th>
                  <th>Razon Social</th>
                  <th>Registro SEPS</th>
                  <th>Acreditado MAG</th>
                  <th>Nro Productores Total</th>
                  <th>Nro Productores Hombres</th>
                  <th>Nro Productores Mujeres</th>
                  <th>Fecha Inicio</th>
                  <th>Fecha Fin</th>
                  <th>Estado</th>
                  <th>Fecha Creación</th>
				  <th>Acciones</th>
                </tr>
                @foreach($results as $key=>$item)
                <tr>
                  <td>{{$key+1}}</td>
                  <td>{!!$item->texto_hecho_derecho_html!!}</td>
                  <td>{{$item->org_ruc}}</td>
                  <td>{{$item->org_razon_social}}</td>
                  <td>{!!$item->texto_registro_seps_html!!}</td>
                  <td>{!!$item->texto_acreditado_mag_html!!}</td>
                  <td>{{$item->org_nro_productores_total}}</td>
                  <td>{{$item->org_nro_productores_hombres}}</td>
                  <td>{{$item->org_nro_productores_mujeres}}</td>
                  <td>{{$item->org_fecha_inicio}}</td>
                  <td>{{$item->org_fecha_fin}}</td>
                  <td>{!!$item->texto_estado_html!!}</td>
                  <td>{{$item->org_fecha_inserta}}</td>
                  <td>
                     <a href="{{route('organizacion.show',['id'=>$item->org_organizacion_id])}} "class="label label-primary">Ver</a>
                     <a href="{{route('organizacion.edit',['id'=>$item->org_organizacion_id])}}" class="label label-primary">Editar</a>
                  </td>
                </tr>
                @endforeach
              </table>
            </div>
        </div>
	<div class="box-footer">
	{{--<a class="btn btn-sm btn-default pull-right" href="{{route('cialco.create')}}">Nuevo</a>--}}
	</div>
	@stop
	@section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
	@stop
	@section('js')
@stop