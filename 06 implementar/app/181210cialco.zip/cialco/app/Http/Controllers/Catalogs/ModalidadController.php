<?php

namespace App\Http\Controllers\Catalogs;

use App\Catalogs\Modalidad;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use App\Http\Controllers\Controller;

class ModalidadController extends Controller
{
    public function index()
    {
        $results = Modalidad::orderBy('mod_orden','ASC')->get();
        return view('modalidad.index', ['results' => $results]);
    }

    public function show($id)
    {

        $result = Modalidad::find($id);
        return view('modalidad.view', ['result' => $result]);
    }

    public function edit($id)
    {    $order = [
        1 => 1,
        2 => 2,
        3 => 3,
        4 => 4,
        5 => 5,
        6 => 6,
        7 => 7,
        8 => 8,
        9 => 9,
        10 => 10,
    ];
        $result = Modalidad::find($id);
        return view('modalidad.edit', ['result' => $result,'order'=>$order]);
    }

    public function create()
    {    $order = [
        1 => 1,
        2 => 2,
        3 => 3,
        4 => 4,
        5 => 5,
        6 => 6,
        7 => 7,
        8 => 8,
        9 => 9,
        10 => 10,
    ];
        return view('modalidad.create',['order'=>$order]);
    }

    public function store(Request $request)
    {
        try {
            // INSERT
            $result = new Modalidad;
            $result->mod_usuario_inserta = Auth::id();
            $result->fill($request->all())->save();

            Session::flash('flash_message', config('content.session.create'));
        } catch (\Exception $e) {
            Session::flash('error', config('content.session.create'));
            return back()->withInput();
        }

        return redirect()->route('modalidad.index');
    }

    public function update(Request $request, $id)
    {
        // TODO incluir try
        try {
            request()->validate([
                'mod_descripcion' => 'required',
                'mod_estado' => 'required',
            ]);

            // UPDATE
            $result = Modalidad::find($id);
            $result->mod_usuario_actualiza = Auth::id();
            $result->fill($request->all())->update();

            Session::flash('flash_message', config('content.session.update'));
        } catch (\Exception $e) {
            Session::flash('error', content('content.session.error'));
            return back()->withInput();
        }

        return redirect()->route('modalidad.index');
    }

    public function destroy($id)
    {
        // NOT REQUIRED
        /*$result=Modalidad::find($id);
        $result->mod_usuario_elimina=Auth::id();
        $result->delete();*/

    }
}