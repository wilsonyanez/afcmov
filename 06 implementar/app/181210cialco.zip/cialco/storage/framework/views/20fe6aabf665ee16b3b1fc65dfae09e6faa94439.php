

<?php $__env->startSection('title', 'Modalidades'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Modalidades</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-primary">
        <div class="box-header with-border">
            <h2 class="page-header"><i class="fa fa-globe"></i>Detalle Modalidades</h2>

            <div class="row invoice-info">
                <div class="col-sm-4 invoice-col">
                    <p><b>ID: </b><?php echo e($result->mod_modalidad_id); ?></p>
                    <p><b>Descripción: </b><?php echo e($result->mod_descripcion); ?></p>
                    <p><b>Estado: </b><?php echo $result->texto_estado_html; ?></p>

                </div>
            </div>
            <div class="box-footer">
                <a href="<?php echo e(URL::previous()); ?>" class="pull-right btn btn-default">Regresar</a>
            </div>
        </div>



        <?php $__env->stopSection(); ?>



        <?php $__env->startSection('css'); ?>

            <link rel="stylesheet" href="/css/admin_custom.css">

        <?php $__env->stopSection(); ?>



        <?php $__env->startSection('js'); ?>

            <script> console.log('Hi!'); </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>