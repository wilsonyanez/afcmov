<?php

namespace App\Http\Controllers;

use App\Entities\CialcoOfertaAgropecuaria;
use App\Http\Requests\StoreCialcoOfertaAgropecuariaRequest;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;

class CialcoOfertaAgropecuariaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $grid = \DataGrid::source(CialcoOfertaAgropecuaria::with('cialco'));
        $grid->add('coa_cialco_oferta_agro_id','ID', true)->style("width:100px");
        $grid->add('{{$cialco->cia_nombre}}','Cialco');
        $grid->add('coa_descripcion_otro','Descripción',true);
        $grid->add('coa_fecha_inicio','Fecha Inicio',true);
        $grid->add('coa_fecha_fin','Fecha Fin',true);
        $grid->add('texto_estado','Estado',true);
        $grid->add('<a href="/cialcoofertaagropecuaria/{{$coa_cialco_oferta_agro_id}}"><span class="glyphicon glyphicon-eye-open"> </span></span></a>','');
        $grid->link('/cialcoofertaagropecuaria/create',"Nuevo", "TR");
        $grid->add('<a href="/cialcoofertaagropecuaria/{{$coa_cialco_oferta_agro_id}}/edit"><span class="glyphicon glyphicon-pencil"> </span></span></a>','');
        $grid->paginate(20);

        $resutls=CialcoOfertaAgropecuaria::get();
        return view('cialcoofertaagropecuaria.index',['results'=>$resutls,'grid'=>$grid]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $result= CialcoOfertaAgropecuaria::find($id);
        return view('cialcoofertaagropecuaria.view',['result' =>$result]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $result = CialcoOfertaAgropecuaria::find($id);
        return view('cialcoofertaagropecuaria.edit',['result'=>$result]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $result = CialcoOfertaAgropecuaria::find($id);

        request()->validate([
          'coa_descripcion_otro',
          'coa_fecha_inicio' => 'required',
          'coa_fecha_fin',
          'coa_estado' => 'required',
        ]);

        $input = $request->all();
        $result->fill($input)->save();
        Session::flash('flash_message','El registro fue actualizado exitosamente');

        return redirect()->route('cialcoofertaagropecuaria.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}