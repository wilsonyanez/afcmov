<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCialcoMontoVentaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cialco_monto_venta', function (Blueprint $table) {
            $table->increments('cmv_cialco_monto_venta_id');
            $table->integer('cmv_ejercicio')->unsigned()->default(0);
            $table->integer('cmv_periodo')->unsigned()->default(0);
            $table->decimal('cmv_monto', 9, 2)->default(0);

            // COLUMNAS DE CONTROL
            $table->boolean('cmv_estado')->default(true);

            $table->date('cmv_fecha_inicio');
            $table->date('cmv_fecha_fin')->nullable();

            $table->integer('cmv_usuario_inserta')->unsigned()->nullable();
            $table->timestamp('cmv_fecha_inserta')->nullable();

            $table->integer('cmv_usuario_actualiza')->unsigned()->nullable();
            $table->timestamp('cmv_fecha_actualiza')->nullable();

            $table->integer('cmv_usuario_elimina')->unsigned()->nullable();
            $table->timestamp('cmv_fecha_elimina')->nullable();

            // FOREINGS
            $table->unsignedInteger('cmv_cialco_id');
            $table->foreign('cmv_cialco_id')->references('cia_cialco_id')->on('cialco');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cialco_monto_venta');
    }
}