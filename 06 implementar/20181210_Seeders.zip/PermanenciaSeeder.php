<?php

use Illuminate\Database\Seeder;

class PermanenciaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('permanencia')->insert([
            'per_descripcion'=>'Nuevo',
            'per_fecha_inserta'=>date_create('now UTC'),
            'per_fecha_actualiza'=>date_create('now UTC')
        ]);

        \DB::table('permanencia')->insert([
            'per_descripcion'=>'Fortalecido',
            'per_fecha_inserta'=>date_create('now UTC'),
            'per_fecha_actualiza'=>date_create('now UTC')
        ]);
    }
}
