
<?php $__env->startSection('title', 'Nuevo Cialco por Productos'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Cialco por Productos</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::model($result, ['method' => 'PATCH','route' => ['cialcoproducto.update', 'id'=>$result->cpr_cialco_producto_id]]); ?>

	<div class="box box-primary">
		<div class="box-header with-border">
			<h3 class="box-title">Editar</h3>
		</div>
		<div class="box-body">
		  <div class="row"> <!-- ROW 1 -->
			<div class="col-md-3">
				<div class="form-group">
					<label for="cpr_cialco_id">Cialco</label>
						<?php echo e(Form::select('cpr_cialco_id', $cialcos, $result->cpr_cialco_id, ['class'=>'form-control','placeholder' => 'Seleccione...'])); ?>

						<?php echo $__env->make('include.error_form_element',['name'=>'cpr_cialco_id'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
					<label for="cpr_producto_id">Productos</label>
						<?php echo e(Form::select('cpr_producto_id', $productos, $result->cpr_producto_id, ['class'=>'form-control','placeholder' => 'Seleccione...'])); ?>

						<?php echo $__env->make('include.error_form_element',['name'=>'cpr_producto_id'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
					<label for="cpr_ejercicio">Año</label>
						<?php echo e(Form::number('cpr_ejercicio',$result->cpr_ejercicio,['class'=>'form-control'])); ?>

						<?php echo $__env->make('include.error_form_element',['name'=>'cpr_ejercicio'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
			</div>
		</div>
		<div class="row"> <!-- ROW 2 -->
			<div class="col-md-3">
				<div class="form-group">
					<label for="cpr_periodo">Mes</label>
						<?php echo e(Form::number('cpr_periodo',$result->cpr_periodo,['class'=>'form-control'])); ?>

						<?php echo $__env->make('include.error_form_element',['name'=>'cpr_periodo'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
					<label for="cpr_precio">Precio</label>
						<?php echo e(Form::number('cpr_precio',$result->cpr_precio,['class'=>'form-control'])); ?>

						<?php echo $__env->make('include.error_form_element',['name'=>'cpr_precio'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
			</div>
			<div class="col-md-3">		
				<div class="form-group">
					<label for="cpr_unidad">Unidad (Kg)</label>
						<?php echo e(Form::select('cpr_unidad',['3' => 'Unidades', '2' => 'Litros', '1' => 'Kilos'],$result->cpr_unidad,['class'=>'form-control'])); ?>

						<?php echo $__env->make('include.error_form_element',['name'=>'cpr_unidad'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			  </div>
			</div>
		</div>
		<div class="row"> <!-- ROW 3 -->
			<div class="col-md-3">
			<div class="form-group">
				<label for="cpr_fecha_inicio">Fecha Inicio</label></br>
					<?php echo e(Form::date('cpr_fecha_inicio', $result->cpr_fecha_inicio, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});'))); ?>

					<?php echo $__env->make('include.error_form_element',['name'=>'cpr_fecha_inicio'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
			</div>
			<div class="col-md-3">
			<div class="form-group">
				<label for="cpr_fecha_fin">Fecha Fin</label></br>
					<?php echo e(Form::date('cpr_fecha_fin', $result->cpr_fecha_fin, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});'))); ?>

					<?php echo $__env->make('include.error_form_element',['name'=>'cpr_fecha_fin'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
			</div>
			<div class="col-md-3">
			  <div class="form-group">
				<label for="cpr_estado">Estado</label>
					<?php echo e(Form::select('cpr_estado',['1' => 'Activo', '0' => 'Inactivo'],$result->cpr_estado,['class'=>'form-control'])); ?>

				</div>
			</div>
		  </div>
		</div>
		<div class="box-footer">
		  <button type="submit" class="btn btn-primary">Editar</button>
		</div>
		<?php echo Form::close(); ?>

		<div class="box-footer">
			<a href="<?php echo e(URL::previous()); ?>" class="pull-right btn btn-default">Regresar</a>
		</div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('css'); ?>
		<link rel="stylesheet" href="/css/admin_custom.css">
	  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>