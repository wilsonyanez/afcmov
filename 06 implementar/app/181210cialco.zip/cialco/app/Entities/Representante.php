<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Representante extends Model
{
    protected $table = 'representante';
    protected $primaryKey = 'rep_representante_id';
    const CREATED_AT = 'rep_fecha_inserta';
    const UPDATED_AT = 'rep_fecha_actualiza';

    use SoftDeletes;
    const DELETED_AT = 'rep_fecha_elimina';

    protected $append = [
        'texto_estado',
        'texto_estado_html'
    ];

    public function cialco()
    {
        return $this->belongsTo('App\Entities\Cialco', 'rep_cialco_id');
    }

    public function getTextoEstadoAttribute()
    {
        return ($this->rep_estado ? 'Activo' : 'Inactivo');
    }

    public function getTextoEstadoHtmlAttribute()
    {
        if ($this->rep_estado)
            return ('<span class="label label-success">' . $this->texto_estado . '</span>');
        return ('<span class="label label-default">' . $this->texto_estado . '</span>');
    }

    protected $fillable = [
        'rep_cialco_id',
        'rep_identificacion',
        'rep_contacto',
        'rep_correo_electronico',
        'rep_estado',
        'rep_fecha_inicio',
        'rep_fecha_fin',
    ];

    public function representante()
    {
        return $this->belongsTo('App\Catalogs\Representante', 'rep_representante_id');
    }

}