@extends('adminlte::page')
@section('title', 'Cialco')
@section('content_header')
    <h1>Cialco</h1>
@stop

@section('content')
@include('include.alert')
    <div class="box box-primary"> <!-- Ini Clase BOX -->
        <div class="box-header with-border">
            <h2 class="page-header">
               {{-- <i class="fa fa-globe"></i>--}} Información
                    <a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
            </h2>

            <div class="row invoice-info">
                <div class="col-md-2">
                    <address>
                        <strong>Modalidad</strong><br>
                        {{$result->modalidad->mod_descripcion}}<br>
                        <br/>
                        <strong>Permanencia</strong><br>
                        {{$result->permanencia->per_descripcion}}<br>
                    </address>
                </div>
                <div class="col-md-3">
                    <address>
                        <strong>{{$result->cia_nombre}}</strong><br>
                        {{$result->cia_contacto}}<br>
                        {{$result->cia_correo_electronico}}<br>
                        {{$result->cia_sitio_web}}<br>
                    </address>
                </div>
                <div class="col-md-2">
                    <address>
					    <strong>Vigencia</strong><br>
                        <strong>Fecha de inicio:</strong><br>
						{{$result->fecha_inicio}}<br>
                        <strong>Fecha de fin:</strong><br>
						{{$result->fecha_fin}}<br>
						<strong>Estado:</strong><br>
                        {!!$result->texto_estado_html!!}<br>
                    </address>
                </div>
                <div class="col-md-2">
                    <address>
                        <strong>Localización</strong><br>
                        PICHINCHA<br>
                        QUITO<br>
                        Eloy Alfaro<br>
                    </address>
                </div>
                <div class="col-md-3">
                    <address>
                         <strong>Productores vinculados</strong><br>
                         Hombres #<br>
                         Mujeres #<br>
                         Total #<br>
                         Org. Participantes #<br>
                         <br/>
                          <strong>Consumidores vinculados</strong><br>
                          Número #<br>
                         <span class="label label-primary">En desarrollo</span>
                    </address>
                </div>
            </div>

            <div class="row">
                <div class="col-md-8 table-responsive">
                    <h2 class="page-header">Representantes</h2>
                    <table class="table table-striped">
                        <tr>
							<th>ID</th>
							<th>Identificación</th>
							<th>Contacto</th>
							<th>Correo electrónico</th>
							<th>Fecha Incio</th>
							<th>Fecha Fin</th>
							<th>Estado</th>
							<th>Acciones</th>
                        </tr>
                        @foreach($result->representantes as $key=>$item)
                            <tr>
								<td>{{$key+1}}</td>
								<td>{{$item->rep_identificacion}}</td>
								<td>{{$item->rep_contacto}}</td>
								<td>{{$item->rep_correo_electronico}}</td>
								<td>{{$item->rep_fecha_inicio}}</td>
								<td>{{$item->rep_fecha_fin}}</td>
								<td>{!!$item->texto_estado_html!!}</td>
                                <td>
                                   <a  class="btn btn-block btn-danger btn-xs" href="{{route('cialco.representante.destroy',['id'=>$item->rep_representante_id])}}">Eliminar</a>
                                </td>
                            </tr>
                        @endforeach
                    </table>
                    <p><span class="label label-primary">Viene de tabla REPRESENTANTES</span></p>
                    <a class="btn btn-default pull-right" href="{{route('cialco.representante.create',['id'=>$result->cia_cialco_id])}}">Nuevo Representante</a>
                </div>
             </div>

             <div class="row">
                <div class="col-md-12 table-responsive">
                    <h2 class="page-header">Direcciones</h2>
                    <table class="table table-striped">
						<tr>
							<th>ID</th>
							<th>Sector</th>
							<th>Principal</th>
							<th>Número</th>
							<th>Secundaria</th>
							<th>Referencia</th>
							<th>Estimado Consumidores</th>
							<th>Fecha Incio</th>
							<th>Fecha Fin</th>
							<th>Estado</th>
							<th>Acciones</th>
						</tr>
						@foreach($result->direcciones as $key=>$item)
							<tr>
								<td>{{$key+1}}</td>
								<td>{{$item->dir_sector}}</td>
								<td>{{$item->dir_calle_principal}}</td>
								<td>{{$item->dir_numero}}</td>
								<td>{{$item->dir_calle_secundaria}}</td>
								<td>{{$item->dir_referencia}}</td>
								<td>{{$item->dir_consumidores}}</td>
								<td>{{$item->dir_fecha_inicio}}</td>
								<td>{{$item->dir_fecha_fin}}</td>
								<td>{!!$item->texto_estado_html!!}</td>
								<td>
								<a  class="btn btn-block btn-danger btn-xs" href="{{route('cialco.direccion.destroy',['id'=>$item->dir_direccion_id])}}">Eliminar</a>
								</td>
							</tr>
						@endforeach
                    </table>
                    <p><span class="label label-primary">Viene de tabla DIRECCIONES</span></p>
                    <a class="btn btn-default pull-right " href="{{route('cialco.direccion.create',['id'=>$result->cia_cialco_id])}}">Nueva Dirección</a>
                </div>
             </div>

             <div class="row">
				<div class="col-md-12 table-responsive">
					<h2 class="page-header">Coordenadas Geográficas</h2>
					 <table class="table table-striped">
						<tr>
							<th>ID</th>
							<th>Posición X</th>
							<th>Posición Y</th>
							<th>Posición Z</th>
							<th>UTM</th>
							<th>Fecha Incio</th>
							<th>Fecha Fin</th>
							<th>Estado</th>
							<th>Acciones</th>
						</tr>
						@foreach($result->coordenadas as $key=>$item)
							<tr>
								<td>{{$item->coo_coordenada_id}}</td>
								<td>{{$item->coo_posicion_x}}</td>
								<td>{{$item->coo_posicion_y}}</td>
								<td>{{$item->coo_posicion_z}}</td>
								<td>{{$item->utm->utm_descripcion}}</td>
								<td>{{$item->coo_fecha_inicio}}</td>
								<td>{{$item->coo_fecha_fin}}</td>
								<td>{!!$item->texto_estado_html!!}</td>
								<td>
								<a  class="btn btn-block btn-danger btn-xs" href="{{route('cialco.coordenada.destroy',['id'=>$item->coo_coordenada_id])}}">Eliminar</a>
								</td>
							</tr>
						@endforeach
					</table>
					<p><span class="label label-primary">Viene de tabla COORDENADAS</span></p>
					<a class="btn btn-default pull-right " href="{{route('cialco.coordenada.create',['id'=>$result->cia_cialco_id])}}">Nueva Coordenada</a>
				</div>
             </div>

             <div class="row">
				<div class="col-md-12 table-responsive">
					<h2 class="page-header">Frecuencias</h2>
					 <table class="table table-striped">
						<tr>
							<th>ID</th>
							<th>Hora Inicio</th>
							<th>Hora Fin</th>
							<th>Días</th>
						    <th>Descripción</th>
							<th>Frecuencia</th>
							<th>Fecha Incio</th>
							<th>Fecha Fin</th>
							<th>Estado</th>
							<th>Acciones</th>
						</tr>
						@foreach($result->frecuencias as $key=>$item)
							<tr>
								<td>{{$item->cfr_cialco_frecuencia_id}}</td>
								<td>{{$item->cfr_hora_inicio}}</td>
								<td>{{$item->cfr_hora_fin}}</td>
								<td>{{$item->cfr_dias}}</td>
								<td>{{$item->cfr_descripcion}}</td>
								<td>{{$item->frecuencia->fre_descripcion}}</td>
								<td>{{$item->cfr_fecha_inicio}}</td>
								<td>{{$item->cfr_fecha_fin}}</td>
								<td>{!!$item->texto_estado_html!!}</td>

								<td>
									<a  class="btn btn-block btn-danger btn-xs" href="{{route('cialco.frecuencia.destroy',['id'=>$item->cfr_cialco_frecuencia_id])}}">Eliminar</a>
								</td>
							</tr>
						@endforeach
					</table>
					<p><span class="label label-primary">Viene de tabla FRECUENCIAS</span></p>
					<a class="btn btn-default pull-right " href="{{route('cialco.frecuencia.create',['id'=>$result->cia_cialco_id])}}">Nueva Frecuencia</a>
				</div>
             </div>

             <div class="row">
				<div class="col-md-12 table-responsive">
					<h2 class="page-header">Ofertas Agropecuarias</h2>
					<table class="table table-striped">
						<tr>
						  <th>ID</th>
						  <th>Descripción</th>
						  <th>Oferta Agropecuaria</th>
						  <th>Fecha Inicio</th>
						  <th>Fecha Fin</th>
						  <th>Estado</th>
						  <th>Acciones</th>
						</tr>
						@foreach($result->ofertasagropecuarias as $key=>$item)
						<tr>
							<td>{{$item->coa_cialco_oferta_agro_id}}</td>
							<td>{{$item->coa_descripcion_otro}}</td>
							<td>{{$item->ofertaagropecuaria->ofa_descripcion}}</td>
							<td>{{$item->coa_fecha_inicio}}</td>
							<td>{{$item->coa_fecha_fin}}</td>
							<td>{!!$item->texto_estado_html!!}</td>
							<td>
								<a class="btn btn-block btn-danger btn-xs" href="{{route('cialco.ofertaagropecuaria.destroy',['id'=>$item->coa_cialco_oferta_agro_id])}}">Eliminar</a>
							</td>
						</tr>
						@endforeach
 					</table>
					<p><span class="label label-primary">Viene de tabla OFERTAS AGROPECUARIAS</span></p>
					<a class="btn btn-default pull-right " href="{{route('cialco.ofertaagropecuaria.create',['id'=>$result->cia_cialco_id])}}">Nueva Oferta Agropecuaria</a>
				</div>
             </div>

             <div class="row">
				<div class="col-md-12 table-responsive">
					<h2 class="page-header">Organizaciones</h2>
					<table class="table table-striped">
						<tr>
						  <th>ID</th>
						  <th>Hecho Derecho</th>
						  <th>RUC</th>
						  <th>Razón Social</th>
						  <th>Registro SEPS</th>
						  <th>Acreditado MAG</th>
						  <th>Nro Productores Total</th>
						  <th>Nro Productores Hombres</th>
						  <th>Nro Productores Mujeres</th>
						  <th>Fecha Inicio</th>
						  <th>Fecha Fin</th>
						  <th>Estado</th>
						  <th>Fecha Creación</th>
						  <th>Acciones</th>
						</tr>
						@foreach($result->organizaciones as $key=>$item)
						<tr>
							<td>{{$item->org_organizacion_id}}</td>
							<td>{!!$item->texto_hecho_derecho_html!!}</td>
							<td>{{$item->org_ruc}}</td>
							<td>{{$item->org_razon_social}}</td>
							<td>{!!$item->texto_registro_seps_html!!}</td>
							<td>{!!$item->texto_acreditado_mag_html!!}</td>
							<td>{{$item->org_nro_productores_total}}</td>
							<td>{{$item->org_nro_productores_hombres}}</td>
							<td>{{$item->org_nro_productores_mujeres}}</td>
							<td>{{$item->org_fecha_inicio}}</td>
							<td>{{$item->org_fecha_fin}}</td>
							<td>{!!$item->texto_estado_html!!}</td>
                            <td>{{$item->org_fecha_inserta}}</td>
							<td>
								<a class="btn btn-block btn-danger btn-xs" href="{{route('cialco.organizacion.destroy',['id'=>$item->org_cialco_id])}}">Eliminar</a>
							</td>
						</tr>
						@endforeach
 					</table>
					<p><span class="label label-primary">Viene de tabla ORGANIZACIONES</span></p>
					<a class="btn btn-default pull-right " href="{{route('cialco.organizacion.create',['id'=>$result->cia_cialco_id])}}">Nueva Organización</a>
				</div>
             </div>

             <div class="row">
				<div class="col-md-12 table-responsive">
					<h2 class="page-header">Productores</h2>
					<table class="table table-striped">
						<tr>
						  <th>ID</th>
						  <th>Dispone Sello AFC</th>
						  <th>Identificacion Sello AFC</th>
						  <th>Número Cédula</th>
						  <th>Nombres</th>
						  <th>Apellidos</th>
						  <th>Género</th>
						  <th>Fecha Nacimiento</th>
						  <th>Nacionalidad</th>
						  <th>Fecha Inicio</th>
						  <th>Fecha Fin</th>
						  <th>Estado</th>
						  <th>Fecha Creación</th>
						  <th>Acciones</th>
						</tr>
						@foreach($result->productores as $key=>$item)
						<tr>
						  <td>{{$item->pro_productor_id}}</td>
						  <td>{!!$item->texto_dispone_sello_afc_html!!}</td>
						  <td>{{$item->pro_identificacion_sello_afc}}</td>
						  <td>{{$item->pro_numero_cedula}}</td>
						  <td>{{$item->pro_nombres}}</td>
						  <td>{{$item->pro_apellidos}}</td>
						  <td>{!!$item->texto_genero_html!!}</td>
						  <td>{{$item->pro_fecha_nacimiento}}</td>
						  <td>{{$item->pro_nacionalidad}}</td>
						  <td>{{$item->pro_fecha_inicio}}</td>
						  <td>{{$item->pro_fecha_fin}}</td>
						  <td>{!!$item->texto_estado_html!!}</td>
						  <td>{{$item->pro_fecha_inserta}}</td>
							<td>
								<a class="btn btn-block btn-danger btn-xs" href="{{route('cialco.productor.destroy',['id'=>$item->pro_cialco_id])}}">Eliminar</a>
							</td>
						</tr>
						@endforeach
 					</table>
					<p><span class="label label-primary">Viene de tabla PRODUCTORES</span></p>
					<a class="btn btn-default pull-right " href="{{route('cialco.productor.create',['id'=>$result->cia_cialco_id])}}">Nuevo Productor</a>
				</div>
             </div>

             <div class="row">
				<div class="col-md-12 table-responsive">
					<h2 class="page-header">Interinstitucional</h2>
					<table class="table table-striped">
						<tr>
						  <th>ID</th>
						  <th>Accion Fortalecimiento</th>
						  <th>Apoyo Institucional</th>
						  <th>Provincial</th>
						  <th>Cantonal</th>
						  <th>Parroquial</th>
						  <th>Otro</th>
						  <th>Descripción</th>
						  <th>Fecha Inicio</th>
						  <th>Fecha Fin</th>
						  <th>Estado</th>
						  <th>Fecha Creación</th>
						  <th>Acciones</th>
						</tr>
						@foreach($result->interinstitucionales as $key=>$item)
						<tr>
						  <td>{{$item->int_cialco_interins_id}}</td>
						  <td>{{$item->accionfortalecimiento->afr_descripcion}}</td>
						  <td>{{$item->apoyoinstitucional->ain_descripcion}}</td>
						  <td>{!!$item->texto_provincial_html!!}   </td>
						  <td>{!!$item->texto_cantonal_html!!}   </td>
						  <td>{!!$item->texto_parroquial_html!!}   </td>
						  <td>{!!$item->texto_otro_html!!}</td>
						  <td>{{$item->int_descripcion}}</td>
						  <td>{{$item->int_fecha_inicio}}</td>
						  <td>{{$item->int_fecha_fin}}</td>
						  <td>{!!$item->texto_estado_html!!}</td>
						  <td>{{$item->int_fecha_inserta}}</td>
							<td>
								<a class="btn btn-block btn-danger btn-xs" href="{{route('cialco.cialcointerinstitucional.destroy',['id'=>$item->int_cialco_id])}}">Eliminar</a>
							</td>
						</tr>
						@endforeach
 					</table>
					<p><span class="label label-primary">Viene de tabla CIALCO INTERINSTITUCIONAL</span></p>
					<a class="btn btn-default pull-right " href="{{route('cialco.cialcointerinstitucional.create',['id'=>$result->cia_cialco_id])}}">Nuevo apoyo interinstitucional</a>
				</div>
             </div>

             <div class="row">
				<div class="col-md-12 table-responsive">
					<h2 class="page-header">Productos</h2>
					<table class="table table-striped">
						<tr>
						  <th>ID</th>
						  <th>Año</th>
						  <th>Mes</th>
						  <th>Precio</th>
						  <th>Unidad</th>
						  <th>Fecha Inicio</th>
						  <th>Fecha Fin</th>
						  <th>Estado</th>
						  <th>Acciones</th>
						</tr>
						@foreach($result->productos as $key=>$item)
						<tr>
							<td>{{$item->producto->prd_nombre}}</td>
							<td>{{$item->cpr_ejercicio}}</td>
							<td>{{$item->cpr_periodo}}</td>
							<td>{{$item->cpr_precio}}</td>
							<td>{!!$item->texto_unidad_html!!}</td>
							<td>{{$item->cpr_fecha_inicio}}</td>
							<td>{{$item->cpr_fecha_fin}}</td>
							<td>{!!$item->texto_estado_html!!}</td>
							<td>
								<a class="btn btn-block btn-danger btn-xs" href="{{route('cialco.cialcoproducto.destroy',['id'=>$item->cpr_producto_id])}}">Eliminar</a>
							</td>
						</tr>
						@endforeach
 					</table>
					<p><span class="label label-primary">Viene de tabla PRODUCTOS</span></p>
					<a class="btn btn-default pull-right " href="{{route('cialco.cialcoproducto.create',['id'=>$result->cia_cialco_id])}}">Nuevo Producto</a>
				</div>
             </div>


             <div class="row">
				<div class="col-md-12 table-responsive">
					<h2 class="page-header">Montos de Ventas</h2>
					<table class="table table-striped">
						<tr>
						  <th>ID</th>
						  <th>Año</th>
						  <th>Mes</th>
						  <th>Monto</th>
						  <th>Fecha Inicio</th>
						  <th>Fecha Fin</th>
						  <th>Estado</th>
						  <th>Acciones</th>
						</tr>
						@foreach($result->montosventas as $key=>$item)
						<tr>
							<td>{{$item->cmv_cialco_monto_venta_id}}</td>
							<td>{{$item->cmv_ejercicio}}</td>
							<td>{{$item->cmv_periodo}}</td>
							<td>{{$item->cmv_monto}}</td>
							<td>{{$item->cmv_fecha_inicio}}</td>
							<td>{{$item->cmv_fecha_fin}}</td>
							<td>{!!$item->texto_estado_html!!}</td>
							<td>
								<a class="btn btn-block btn-danger btn-xs" href="{{route('cialco.cialcomontoventa.destroy',['id'=>$item->cmv_cialco_monto_venta_id])}}">Eliminar</a>
							</td>
						</tr>
						@endforeach
 					</table>
					<p><span class="label label-primary">Viene de tabla MONTOS DE VENTAS</span></p>
					<a class="btn btn-default pull-right " href="{{route('cialco.cialcomontoventa.create',['id'=>$result->cia_cialco_id])}}">Nuevo Monto de Venta</a>
				</div>
             </div>

			 
            <div class="row">
                <br/><hr/>
            </div>

            <div class="row no-print">
				<div class="col-xs-12">
					<a href="invoice-print.html" target="_blank" class="btn btn-default"><i class="fa fa-print"></i> Print</a>
				   {{-- <button type="button" class="btn btn-success pull-right"><i class="fa fa-credit-card"></i> Submit Payment
					</button>--}}
				   {{-- <button type="button" class="btn btn-primary pull-right" style="margin-right: 5px;">
						<i class="fa fa-download"></i> Generate PDF
					</button>--}}
				</div>
			</div>
        </div>
	<div class="box-footer">
	</div>  <!-- Fin Clase BOX -->
	@stop
	@section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
	@stop
	@section('js')

@stop