  <div class="row">
    <div class="col-md-12">
      <h4><b>Ubicación</b></h4>
      <hr/>
    </div>
  </div>

      <div class="row">
            <div class="col-md-12">
                  <div class="form-group">
                    <label for="dir_sector">Sector</label>
                    {{ Form::text('dir_sector',null,['class'=>'form-control'])}}
                    @include('include.error_form_element',['name'=>'dir_sector'])
                  </div>
            </div>
      </div>


    <div class="row">
      <div class="col-md-6">
        <div class="form-group">
          <label for="dir_calle_principal">Calle Principal</label>
           {{ Form::text('dir_calle_principal',null,['class'=>'form-control'])}}
            @include('include.error_form_element',['name'=>'dir_calle_principal'])
        </div>
      </div>
      <div class="col-md-2">
        <div class="form-group">
          <label for="dir_numero">Número #</label>
          {{ Form::text('dir_numero',null,['class'=>'form-control'])}}
          @include('include.error_form_element',['name'=>'dir_numero'])
        </div>
      </div>
    </div>


    <div class="row">
      <div class="col-md-6">
        <div class="form-group">
          <label for="dir_calle_secundaria">Calle Secundaria</label>
          {{ Form::text('dir_calle_secundaria',null,['class'=>'form-control'])}}
            @include('include.error_form_element',['name'=>'dir_calle_secundaria'])
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="dir_referencia">Referencia</label>
          {{ Form::text('dir_referencia',null,['class'=>'form-control'])}}
          @include('include.error_form_element',['name'=>'dir_referencia'])
       </div>
     </div>
   </div>
   <!-- /.row -->
