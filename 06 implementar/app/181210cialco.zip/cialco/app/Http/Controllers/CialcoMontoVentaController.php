<?php

namespace App\Http\Controllers;

use App\Entities\Cialco;
use App\Entities\CialcoMontoVenta;
use App\Http\Requests\StoreCialcoRequest;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;

class CialcoMontoVentaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		
        $grid = \DataGrid::source(CialcoMontoVenta::with('cialco'));
        $grid->add('cmv_cialco_monto_venta_id','ID', true)->style("width:100px");
        $grid->add('{{$cialco->cia_nombre}}','Cialco');
        $grid->add('cmv_ejercicio','Año',true);
        $grid->add('cmv_periodo','Mes',true);
        $grid->add('cmv_monto','Precio',true);
        $grid->add('cmv_fecha_inicio','Fecha Inicio',true);
        $grid->add('cmv_fecha_fin','Fecha Fin',true);
        $grid->add('texto_estado','Estado',true);
        $grid->add('<a href="/cialcomontoventa/{{$cmv_cialco_monto_venta_id}}"><span class="glyphicon glyphicon-eye-open"> </span></span></a>','');
        $grid->link('/cialcomontoventa/create',"Nuevo", "TR");
        $grid->add('<a href="/cialcomontoventa/{{$cmv_cialco_monto_venta_id}}/edit"><span class="glyphicon glyphicon-pencil"> </span></span></a>','');
        $grid->paginate(20);

        $resutls = CialcoMontoVenta::get();
        return view('cialcomontoventa.index',['results'=>$resutls,'grid'=>$grid]);
    }

	public function cialco()
    {
		$cialco = Cialco::with('cialco')->get();
        return view('cialco.show', compact('$cialco'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
		$cialcos = Cialco::pluck('cia_nombre', 'cia_cialco_id');
        return view('cialcomontoventa.create', ['cialcos' => $cialcos]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreCialcoMontoVentaRequest $request)
    {
        try {
            CialcoMontoVenta::create($request->all());
            Session::flash('flash_message', Config::get('session.create'));
        } catch (\Exception $e) {
            Session::flash('error', Config::get('session.error'));
            return back()->withInput();
        }

        return redirect()->route('cialcomontoventa.show', ['id' => $cialcomontoventa->cmv_cialco_monto_venta_id]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $result= CialcoMontoVenta::find($id);
        return view('cialcomontoventa.show',['result' =>$result]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $result = CialcoMontoVenta::find($id);
		$cialcos = Cialco::pluck('cia_nombre', 'cia_cialco_id');
        return view('cialcomontoventa.edit',['result'=>$result, 'cialcos'=>$cialcos]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $result = CialcoMontoVenta::find($id);

        request()->validate([
          'cmv_cialco_id' => 'required',
          'cmv_ejercicio' => 'required',
          'cmv_periodo' => 'required',
          'cmv_monto' => 'required',
          'cmv_fecha_inicio' => 'required',
          'cmv_estado' => 'required',
        ]);

        $input = $request->all();
        $result->fill($input)->save();
        Session::flash('flash_message','El registro fue actualizado exitosamente');

        return redirect()->route('cialcomontoventa.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}