<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreCialcoOfertaAgropecuariaRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
		    'coa_descripcion_otro' => 'alpha|max:128|required',
            'coa_fecha_inicio' =>'date|required',
            'coa_estado' =>'required',
			'coa_oferta_agropecuaria_id' =>'required',
        ];
    }
    public function messages(){
        return [
		    'coa_descripcion_otro.required' => 'Descripción es requerida',
            'coa_fecha_inicio.required' => 'Fecha Inicio es requerido',
            'coa_estado.required' => 'Estado es requerido',
            'coa_oferta_agropecuaria_id.required' => 'Oferta agropecuaria es requerida',
        ];
    }
}