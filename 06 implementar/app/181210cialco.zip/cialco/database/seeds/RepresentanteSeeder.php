<?php

use Illuminate\Database\Seeder;

class RepresentanteSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create();
        for($i=0 ; $i<200; $i++){
            \DB::table('representante')->insert([
                'rep_identificacion'=>$faker->ean13,
                'rep_contacto'=>$faker->name,
                'rep_correo_electronico'=>$faker->email,
                'rep_fecha_inicio'=>date_create('now UTC'),
                'rep_fecha_fin'=>date_create('now UTC'),
                'rep_fecha_inserta'=>date_create('now UTC'),
                'rep_fecha_actualiza'=>date_create('now UTC'),
                'rep_cialco_id' => $faker->numberBetween(1,100),
            ]);
        }
    }
}
