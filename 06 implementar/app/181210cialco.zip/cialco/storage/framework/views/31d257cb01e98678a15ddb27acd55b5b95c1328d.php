<?php if($errors->has($name)): ?>
    <small class="text-danger"><?php echo e($errors->first($name)); ?></small>
<?php endif; ?>