<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateModalidadTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('modalidad', function (Blueprint $table) {
            $table->increments('mod_modalidad_id');
            $table->text('mod_descripcion');

            $table->date('mod_fecha_inicio')->nullable();
            $table->date('mod_fecha_fin')->nullable();

            // TODO Campo para verificación de opción de llenado 'OTRO -> especifique'
            $table->boolean('mod_otro')->default(false);

            // TODO Verificar si es necesario agregar integridad referencial para usuario
            $table->boolean('mod_estado')->default(true);

            $table->integer('mod_usuario_inserta')->unsigned()->nullable();
            $table->timestamp('mod_fecha_inserta')->nullable();

            $table->integer('mod_usuario_actualiza')->unsigned()->nullable();
            $table->timestamp('mod_fecha_actualiza')->nullable();

            $table->integer('mod_usuario_elimina')->unsigned()->nullable();
            $table->timestamp('mod_fecha_elimina')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('modalidad');
    }
}
