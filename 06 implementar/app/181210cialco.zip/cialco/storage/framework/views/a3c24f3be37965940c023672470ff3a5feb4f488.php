<div class="row">
    <div class="col-md-12">
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger alert-dismissable">
                <i class="icon fa fa-warning"></i> Ocurrió un error!
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(Session::has('flash_message')): ?>
            <div class="alert alert-success">
                <i class="fa fa-fw fa-check"></i> <?php echo e(Session::get('flash_message')); ?>

            </div>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger">
                <i class="fa fa-fw fa-check"></i> <?php echo e(Session::get('error')); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
