<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreCialcoDireccionRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'dir_cialco_id' =>'required',
            'dir_sector' =>'alpha|max:256|required',
            'dir_calle_principal' =>'alpha|max:256|required',
            'dir_numero' =>'required' =>'alpha|max:20|required',
            /*'dir_calle_secundaria' =>'required',
            'dir_referencia' =>'required'*/
        ];
    }

    public function messages()
    {

        return [
            'dir_cialco_id.required' => 'Código Cialco requerido',
            'dir_sector.required' => 'Sector es requerido',
            'dir_calle_principal.required' => 'Calle Principal es requerida',
            'dir_numero.required' => 'Número es requerido',
        ];
    }
}