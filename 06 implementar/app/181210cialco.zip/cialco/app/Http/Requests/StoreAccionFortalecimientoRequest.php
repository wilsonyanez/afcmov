<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreAccionFortalecimientoRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'afr_descripcion' =>'|alpha|max:128|required',
            'afr_orden' =>'integer|required',
            'afr_estado' =>'required',
        ];
    }
    public function messages()
    {
        return [
            'afr_descripcion.required' => 'Descripción es requerido',
            'afr_orden.required' => 'Orden es requerido',
            'afr_estado.required' => 'Estado es requerido',

        ];
    }
}