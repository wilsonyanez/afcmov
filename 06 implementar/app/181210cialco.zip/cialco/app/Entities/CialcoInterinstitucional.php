<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class CialcoInterinstitucional extends Model
{
    protected $table = 'cialco_interinstitucional';
    protected $primaryKey = 'int_cialco_interins_id';
    const CREATED_AT = 'int_fecha_inserta';
    const UPDATED_AT = 'int_fecha_actualiza';

    use SoftDeletes;
    const DELETED_AT = 'int_fecha_elimina';

    protected $append = [
        'texto_provincial',
        'texto_provincial_html',
        'texto_cantonal',
        'texto_cantonal_html',
        'texto_parroquial',
        'texto_parroquial_html',
        'texto_otro',
        'texto_otro_html',
        'texto_estado',
        'texto_estado_html'
    ];

    protected $fillable = [
        'int_cialco_id',
		'int_accion_fortalecimiento_id',
		'int_apoyo_institucional_id',
        'int_provincial',
        'int_gad_provincial_id',
        'int_cantonal',
        'int_gad_cantonal_id',
        'int_parroquial',
        'int_gad_parroquial_id',
        'int_descripcion',
        'int_fecha_inicio',
        'int_fecha_fin',
        'int_estado'
    ];

    public function accionfortalecimiento()
    {
        return $this->belongsTo('App\Catalogs\AccionFortalecimiento', 'int_accion_fortalecimiento_id');
    }

    public function apoyoinstitucional()
    {
        return $this->belongsTo('App\Catalogs\ApoyoInstitucional', 'int_apoyo_institucional_id');
    }

    public function ubicacionprovincial()
    {
        return $this->belongsTo('App\Catalogs\UbicacionGeografica', 'int_gad_provincial_id');
    }

    public function ubicacioncantonal()
    {
        return $this->belongsTo('App\Catalogs\UbicacionGeografica', 'int_gad_cantonal_id');
    }

    public function ubicacionparroquial()
    {
        return $this->belongsTo('App\Catalogs\UbicacionGeografica', 'int_gad_parroquial_id');
    }
	
    public function cialco()
    {
        return $this->belongsTo('App\Entities\Cialco', 'int_cialco_id');
    }

    public function getTextoProvincialAttribute()
    {
        return ($this->int_provincial ? 'SI' : 'NO');
    }

    public function getTextoProvincialHtmlAttribute()
    {
        if ($this->int_provincial)
            return ('<span class="label label-success">' . $this->texto_provincial . '</span>');
        return ('<span class="label label-default">' . $this->texto_provincial . '</span>');
    }

    public function getTextoCantonalAttribute()
    {
        return ($this->int_cantonal ? 'SI' : 'NO');
    }

    public function getTextoCantonalHtmlAttribute()
    {
        if ($this->int_cantonal)
            return ('<span class="label label-success">' . $this->texto_cantonal . '</span>');
        return ('<span class="label label-default">' . $this->texto_cantonal . '</span>');
    }

    public function getTextoParroquialAttribute()
    {
        return ($this->int_parroquial ? 'SI' : 'NO');
    }

    public function getTextoParroquialHtmlAttribute()
    {
        if ($this->int_parroquial)
            return ('<span class="label label-success">' . $this->texto_parroquial . '</span>');
        return ('<span class="label label-default">' . $this->texto_parroquial . '</span>');
    }

    public function getTextoOngAttribute()
    {
        return ($this->int_ong ? 'SI' : 'NO');
    }

    public function getTextoOngHtmlAttribute()
    {
        if ($this->int_ong)
            return ('<span class="label label-success">' . $this->texto_ong . '</span>');
        return ('<span class="label label-default">' . $this->texto_ong . '</span>');
    }

    public function getTextoCoopInternacionalAttribute()
    {
        return ($this->int_coop_internacional ? 'SI' : 'NO');
    }

    public function getTextoCoopInternacionalHtmlAttribute()
    {
        if ($this->int_coop_internacional)
            return ('<span class="label label-success">' . $this->texto_coop_internacional . '</span>');
        return ('<span class="label label-default">' . $this->texto_coop_internacional . '</span>');
    }

    public function getTextoInstitutoUniversidadAttribute()
    {
        return ($this->int_instituto_universidad ? 'SI' : 'NO');
    }

    public function getTextoInstitutoUniversidadHtmlAttribute()
    {
        if ($this->int_instituto_universidad)
            return ('<span class="label label-success">' . $this->texto_instituto_universidad . '</span>');
        return ('<span class="label label-default">' . $this->texto_instituto_universidad . '</span>');
    }

    public function getTextoColectivosAttribute()
    {
        return ($this->int_colectivos ? 'SI' : 'NO');
    }

    public function getTextoColectivosHtmlAttribute()
    {
        if ($this->int_colectivos)
            return ('<span class="label label-success">' . $this->texto_colectivos . '</span>');
        return ('<span class="label label-default">' . $this->texto_colectivos . '</span>');
    }

    public function getTextoEmpresaPrivadaAttribute()
    {
        return ($this->int_empresa_privada ? 'SI' : 'NO');
    }

    public function getTextoEmpresaPrivadaHtmlAttribute()
    {
        if ($this->int_empresa_privada)
            return ('<span class="label label-success">' . $this->texto_empresa_privada . '</span>');
        return ('<span class="label label-default">' . $this->texto_empresa_privada . '</span>');
    }

    public function getTextoOtroAttribute()
    {
        return ($this->int_otro ? 'SI' : 'NO');
    }

    public function getTextoOtroHtmlAttribute()
    {
        if ($this->int_otro)
            return ('<span class="label label-success">' . $this->texto_otro . '</span>');
        return ('<span class="label label-default">' . $this->texto_otro . '</span>');
    }	

    public function getTextoMagAttribute()
    {
        return ($this->int_mag ? 'SI' : 'NO');
    }

    public function getTextoMagHtmlAttribute()
    {
        if ($this->int_mag)
            return ('<span class="label label-success">' . $this->texto_mag . '</span>');
        return ('<span class="label label-default">' . $this->texto_mag . '</span>');
    }	

    public function getTextoEstadoAttribute()
    {
        return ($this->int_estado ? 'Activo' : 'Inactivo');
    }

    public function getTextoEstadoHtmlAttribute()
    {
        if ($this->int_estado)
            return ('<span class="label label-success">' . $this->texto_estado . '</span>');
        return ('<span class="label label-default">' . $this->texto_estado . '</span>');
    }
}