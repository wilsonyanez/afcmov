

<?php $__env->startSection('title', 'Nuevo Cialco por Oferta Agropecuaria'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Cialco por Oferta Agropecuaria</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo Form::open(['route' => 'cialco.ofertaagropecuaria.store', 'method' => 'post']); ?>


	<div class="box box-primary">
		<?php echo e(Form::hidden('coa_cialco_id',$cialco->cia_cialco_id,['class'=>'form-control'])); ?>

		<div class="box-header with-border">
			<h3 class="box-title">Nueva</h3>
		</div>
		<div class="box-body">
		  <div class="row">
			<div class="col-md-3">
			  <div class="form-group">
				<label for="coa_descripcion_otro">Descripción otro</label>
				<?php echo e(Form::text('coa_descripcion_otro',null,['class'=>'form-control'])); ?>

				<?php echo $__env->make('include.error_form_element',['name'=>'coa_descripcion_otro'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			  </div>
              <div class="form-group">
                 <label for="coa_oferta_agropecuaria_id">Oferta Agropecuaria</label>
                     <?php echo e(Form::select('coa_oferta_agropecuaria_id',$ofertaagropecuarias,null,['class'=>'form-control'])); ?>

              </div>
			  <div class="form-group">
				 <label for="coa_fecha_inicio">Fecha Inicio</label>
				 <?php echo e(Form::date('coa_fecha_inicio', null, array('id' => 'datepicker'))); ?>

			  </div>
			  <div class="form-group">
				 <label for="coa_fecha_fin">Fecha Fin</label></br>
				 <?php echo e(Form::date('coa_fecha_fin', null, array('id' => 'datepicker'))); ?>

			  </div>
			</div>
		  </div>
		  <div class="row">  <!-- ROW 2 -->
			<div class="col-md-3">
			  <div class="form-group">
				<label for="coa_estado">Estado</label>
				<?php echo e(Form::select('coa_estado',['1' => 'Activo', '0' => 'Inactivo'],null,['class'=>'form-control'])); ?>

			  </div>
			</div>
		  </div>
		</div>

		<div class="box-footer">
		  <button type="submit" class="btn btn-primary">Guardar</button>
		</div>
		<?php echo Form::close(); ?>

		<div class="box-footer">
			<a href="<?php echo e(URL::previous()); ?>" class="pull-right btn btn-default">Regresar</a>
		</div>

  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('js'); ?>
  <script> console.log('Hi!'); </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>