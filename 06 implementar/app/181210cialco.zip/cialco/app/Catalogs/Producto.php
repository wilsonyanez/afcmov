<?php

namespace App\Catalogs;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Producto extends Model
{
    protected $table='producto';
    protected $primaryKey = 'prd_producto_id';

    const CREATED_AT = 'prd_fecha_inserta';
    const UPDATED_AT = 'prd_fecha_actualiza';

    use SoftDeletes;
    const DELETED_AT = 'prd_fecha_elimina';

    protected $append = [
        'texto_estado',
        'texto_estado_html'
    ];
    protected $fillable = [
        'prd_codigo_producto',
        'prd_nivel',
        'prd_nombre',
        'prd_padre_producto',
        'prd_fecha_inicio',
        'prd_estado'
    ];
    public function producto()
    {
        return $this->belongsTo('App\Catalogs\Producto', 'prd_producto_id');
    }
    public function getTextoEstadoAttribute()
    {
        return ($this->prd_estado ? 'Activo' : 'Inactivo');
    }

    public function getTextoEstadoHtmlAttribute()
    {
        if ($this->prd_estado)
            return ('<span class="label label-success">' . $this->texto_estado . '</span>');
        return ('<span class="label label-default">' . $this->texto_estado . '</span>');
    }
}