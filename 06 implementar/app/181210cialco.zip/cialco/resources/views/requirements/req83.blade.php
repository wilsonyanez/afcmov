@extends('adminlte::page')



@section('title', 'Dashboard')



@section('content_header')

    <h1>RQ18-MOV-HU083</h1>
    <p>Publicación caracterización de establecimiento</p>

@stop



@section('content')

        <p>Como Técnico de Territorio, quiero publicar los datos de caracterización de los Establecimientos, que me solicita el Administrador AFC para validar si se otorga o no el Sello de la Agricultura Familiar Campesina (Sello AFC).</p>
        <ul>
          <li>Diseño: Cumplir formato detallado en los archivos:RQ14-MOV-HU061-DIS068 Publicación Establecimiento - Caracterización.png</li>
          <li>Usabilidad: Cumplir con el detalle descrito en pestaña funcionalidad con identificación: RQ14-MOV-HU061-FUN</li>
          <li>Objetivo: Publicar Datos de caracterización de Establecimientos donde suministra sus productos un Productor en dispositivo móvil, los atributos a desplegar, se los puede encontrar en: RQ09-MOV-HU038-DIS045</li>
          <li><b>Inquitudes</b></li>
          <li></li>
          </ul>

  <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Caracterización de establecimiento</h3>
            </div>
            <div class="box-body">

                <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                  <label for="exampleInputEmail1">Productos y servicios que ofrece</label>
                                  <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Productos y servicios que ofrece">
                                  <p><span class="label label-info">Dropdown?</span></p>
                            </div>
                        </div>

                         <div class="col-md-4">
                            <div class="form-group">
                                  <label for="exampleInputEmail1">Forma de abastecimiento</label>
                                  <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Forma de abastecimiento">
                                  <p><span class="label label-info">Dropdown?</span></p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                  <label for="exampleInputEmail1">Proveedores desde la AFC</label>
                                  <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Proveedores desde la AFC<">
                                  <p><span class="label label-info">Dropdown?</span></p>
                            </div>
                        </div>


                </div>
                <!-- /.row -->

                <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                  <label for="exampleInputEmail1">Monto de compra a proveedores al AFC (USD)</label>
                                  <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Monto de compra a proveedores al AFC<">
                                  <p><span class="label label-info">Dropdown?</span></p>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                  <label for="exampleInputEmail1">Instalaciones y equipamiento para la recepción de productos</label>
                                  <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Instalaciones y equipamiento">
                                  <p><span class="label label-info">Dropdown?</span></p>
                            </div>
                        </div>
                        </div>

                </div>
                <!-- /.row -->
                <div class="row">
                <div class="col-md-12">
                <h1>Requerimiento de abastecimiento</h1>
                </div>
                </div>

                <div class="row">
                <div class="col-md-12">
                            <table class="table table-bordered">
                                            <tr>
                                              <th style="width: 10px">#</th>
                                              <th>Producto</th>
                                              <th>Presentación</th>
                                              <th>Cantidad</th>
                                              <th>Frecuencia</th>
                                            </tr>
                                            @for ($i=0;$i<5;$i++)
                                            <tr>
                                                  <td>{{$i}}</td>
                                                  <td>nombre</td>
                                                  <td>10</td>
                                                  <td>10</td>
                                                  <td>ejemplo</td>
                                                  <td>ejemplo</td>

                                                </tr>
                                            @endfor

                                          </table>
                            </div>
                </div>






            <div class="box-footer">
                <button type="submit" class="btn btn-primary">Almacenar</button>
              </div>
    </div>


@stop



@section('css')

    <link rel="stylesheet" href="/css/admin_custom.css">

@stop



@section('js')

    <script> console.log('Hi!'); </script>

@stop