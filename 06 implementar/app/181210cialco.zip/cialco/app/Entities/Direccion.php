<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Direccion extends Model
{
    protected $table = 'direccion';
    protected $primaryKey = 'dir_direccion_id';
    const CREATED_AT = 'dir_fecha_inserta';
    const UPDATED_AT = 'dir_fecha_actualiza';

    use SoftDeletes;
    const DELETED_AT = 'dir_fecha_elimina';

    protected $fillable = [
        'dir_cialco_id',
        'dir_sector',
        'dir_calle_principal',
        'dir_numero',
        'dir_calle_secundaria',
        'dir_referencia',
        'dir_consumidores',
        'dir_fecha_inicio',
        'dir_fecha_fin',
    ];

    protected $append = [
        'texto_estado',
        'texto_estado_html'
    ];

    public function cialco()
    {
        return $this->belongsTo('App\Entities\Cialco', 'dir_cialco_id');
    }

    public function getTextoEstadoAttribute()
    {
        return ($this->rep_estado ? 'Activo' : 'Inactivo');
    }

    public function getTextoEstadoHtmlAttribute()
    {
        if ($this->rep_estado)
            return ('<span class="label label-success">' . $this->texto_estado . '</span>');
        return ('<span class="label label-default">' . $this->texto_estado . '</span>');
    }
}