<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUbicacionGeograficaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ubicacion_geografica', function (Blueprint $table) {
            $table->increments('uge_ubicacion_geografica_id');
            $table->text('uge_codigo_ubicacion');
            $table->text('uge_nivel');
            $table->text('uge_nombre');
            $table->text('uge_padre_ubicacion');
			
			// COLUMNAS DE CONTROL
            $table->boolean('uge_estado')->default(true);

            $table->date('uge_fecha_inicio')->nullable();
            $table->date('uge_fecha_fin')->nullable();

            $table->integer('uge_usuario_inserta')->unsigned()->nullable();
            $table->timestamp('uge_fecha_inserta')->nullable();

            $table->integer('uge_usuario_actualiza')->unsigned()->nullable();
            $table->timestamp('uge_fecha_actualiza')->nullable();

            $table->integer('uge_usuario_elimina')->unsigned()->nullable();
            $table->timestamp('uge_fecha_elimina')->nullable();

            // FOREINGS

            // TODO definir columna de relación API
		
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ubicacion_geografica');
    }
}