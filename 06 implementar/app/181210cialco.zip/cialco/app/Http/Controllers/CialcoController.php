<?php

namespace App\Http\Controllers;

use App\Catalogs\AccionFortalecimiento;
use App\Catalogs\ApoyoInstitucional;
use App\Catalogs\Frecuencia;
use App\Catalogs\Modalidad;
use App\Catalogs\ofertaAgropecuaria;
use App\Catalogs\Permanencia;
use App\Catalogs\Producto;
use App\Catalogs\UbicacionGeografica;
use App\Catalogs\Utm;
use App\Entities\Cialco;
use App\Entities\CialcoFrecuencia;
use App\Entities\CialcoInterinstitucional;
use App\Entities\CialcoMontoVenta;
use App\Entities\CialcoOfertaAgropecuaria;
use App\Entities\CialcoProducto;
use App\Entities\Coordenada;
use App\Entities\Direccion;
use App\Entities\Organizacion;
use App\Entities\Representante;
use App\Entities\Productor;

use App\Http\Requests\StoreCialcoDireccionRequest;
use App\Http\Requests\StoreCialcoFrecuenciaRequest;
use App\Http\Requests\StoreCialcoInterinstitucionalRequest;
use App\Http\Requests\StoreCialcoMontoVentaRequest;
use App\Http\Requests\StoreCialcoOfertaAgropecuariaRequest;
use App\Http\Requests\StoreCialcoProductoRequest;
use App\Http\Requests\StoreCialcoRepresentanteRequest;
use App\Http\Requests\StoreCialcoRequest;
use App\Http\Requests\StoreCoordenadaRequest;
use App\Http\Requests\StoreFrecuencia;
use App\Http\Requests\StoreOfertaAgropecuariaRequest;
use App\Http\Requests\StoreOrganizacionRequest;
use App\Http\Requests\StoreProductoRequest;
use App\Http\Requests\StoreProductorRequest;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;

class CialcoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $grid = \DataGrid::source(Cialco::with('modalidad','permanencia'));
        $grid->add('cia_cialco_id','ID', true)->style("width:100px");
        $grid->add('cia_nombre','Nombre',true);
        $grid->add('cia_contacto','Contacto',true);
        $grid->add('{{$modalidad->mod_descripcion}}','Modalidad');
        $grid->add('{{$permanencia->per_descripcion}}','Permanencia');
        $grid->add('cia_fecha_inicio','Fecha Inicio',true);
        $grid->add('cia_fecha_fin','Fecha fin',true);
        $grid->add('texto_estado','Estado',true);
        $grid->add('<a href="/cialco/{{ $cia_cialco_id}}"><span class="glyphicon glyphicon-eye-open"> </span></span></a>','');
        $grid->link('/cialco/create',"Nuevo", "TR");
        $grid->paginate(20);

        $results = Cialco::get();
        return view('cialco.index', ['results' => $results,'grid'=>$grid]);
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'cia_nombre' => 'required|string|max:255',
            'cia_correo_electronico' => 'required|string|email|max:255|unique:cialco',
            'cia_contacto' => 'required|string|min:6|max:15|confirmed',
            'cia_fecha_inicio' => 'required|date|min:2010-01-01|max:2030-12-31|confirmed',
            'cia_fecha_fin' => 'date|min:2010-01-01|max:2030-12-31',
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $modalidades = Modalidad::pluck('mod_descripcion', 'mod_modalidad_id');
        $permanencias = Permanencia::pluck('per_descripcion', 'per_permanencia_id');

        return view('cialco.create', ['modalidades' => $modalidades, 'permanencias' => $permanencias]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreCialcoRequest $request)
    {
        try {
            $cialco = Cialco::create($request->all());
            Session::flash('flash_message', Config::get('session.create'));
        } catch (\Exception $e) {
            Session::flash('error', Config::get('session.error'));
            return back()->withInput();
        }

        return redirect()->route('cialco.show', ['id' => $cialco->cia_cialco_id]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $result = Cialco::find($id);
        return view('cialco.view', ['result' => $result]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /**
     *  Create Representante with Cialco ID
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function createRepresentante($id)
    {
        $cialco = Cialco::find($id);
        return view('cialco.create_representante', ['cialco' => $cialco]);

    }

    /**
     * @param StoreCialcoRepresentanteRequest $request
     * @return $this|\Illuminate\Http\RedirectResponse
     */
    public function storeRepresentante(StoreCialcoRepresentanteRequest $request)
    {
        try {
            $representante = new Representante($request->all());
/*            $representante->rep_fecha_inicio = date_create('now UTC');
            $representante->rep_fecha_fin = date_create('now UTC'); */

            // CONTROL COLUMNS
            $representante->rep_fecha_inserta = date_create('now UTC');
            $representante->rep_usuario_inserta = Auth::id();

            $representante->save();

        } catch (\Exception $e) {
            return back()->withInput();
        }
        Session::flash('flash_message', 'El registro fue creado éxitosamente');
        return redirect()->route('cialco.show', ['id' => $request->rep_cialco_id]);

    }

    public function createDireccion($id)
    {
        $cialco = Cialco::find($id);
        return view('cialco.create_direccion', ['cialco' => $cialco]);

    }

    public function storeDireccion(StoreCialcoDireccionRequest $request)
    {

        try {
            $direccion = new Direccion($request->all());
/*            $direccion->dir_fecha_inicio = date_create('now UTC');
            $direccion->dir_fecha_fin = date_create('now UTC'); */

            // CONTROL COLUMNS
            $direccion->dir_fecha_inserta = date_create('now UTC');
            $direccion->dir_usuario_inserta = Auth::id();

            $direccion->save();

        } catch (\Exception $e) {
            dd($e->getMessage());
            return back()->withInput();
        }

        Session::flash('flash_message', 'El registro fue creado éxitosamente');
        return redirect()->route('cialco.show', ['id' => $request->dir_cialco_id]);

    }

    public function createCoordenada($id)
    {
        $utms = Utm::where('utm_estado', true)->pluck('utm_descripcion', 'utm_utm_id');

        $cialco = Cialco::find($id);
        return view('cialco.create_coordenada', ['cialco' => $cialco, 'utms' => $utms]);

    }

    public function storeCoordenada(StoreCoordenadaRequest $request)
    {

        try {

            $coordenada = new Coordenada;
            $coordenada->fill($request->all());

/*            $coordenada->coo_fecha_inicio = date_create('now UTC');
            $coordenada->coo_fecha_fin = date_create('now UTC'); */

            $coordenada->coo_usuario_inserta = Auth::id();
            $coordenada->save();

        } catch (\Exception $e) {

            return back()->withInput();
        }

        Session::flash('flash_message', 'El registro fue creado éxitosamente');
        return redirect()->route('cialco.show', ['id' => $request->coo_cialco_id]);

    }

    public function createFrecuencia($id)
    {
        $cialco = Cialco::find($id);
        $frecuencias = Frecuencia::where('fre_estado', true)->pluck('fre_descripcion', 'fre_frecuencia_id');
        return view('cialco.create_frecuencia', ['cialco' => $cialco, 'frecuencias' => $frecuencias]);
    }

    /**
     * Store CialcoFrecuendia Record
     * @param StoreCialcoFrecuenciaRequest $request
     * @return $this|\Illuminate\Http\RedirectResponse
     */
    public function storeFrecuencia(StoreCialcoFrecuenciaRequest $request)
    {
        $days=[
            1=>'L',
            2=>'M',
            3=>'Mi',
            4=>'J',
            5=>'V',
            6=>'S',
            7=>'D',
        ];
        try {
            $result = new CialcoFrecuencia;
            $result->fill($request->all());
            $result->cfr_dias=json_encode($days);
            $result->cfr_usuario_inserta = Auth::id();
            $result->save();
        } catch (\Exception $e) {

            return back()->withInput();
        }

        Session::flash('flash_message', 'El registro fue creado éxitosamente');
        return redirect()->route('cialco.show', ['id' => $request->cfr_cialco_id]);
    }

    public function createOfertaAgropecuaria($id)
    {
        $cialco = Cialco::find($id);
		$ofertaagropecuarias = OfertaAgropecuaria::where('ofa_estado', true)->pluck('ofa_descripcion', 'ofa_oferta_agropecuaria_id'); 
        return view('cialco.create_ofertaagropecuaria', ['cialco' => $cialco, 'ofertaagropecuarias' => $ofertaagropecuarias]);
    }

    public function storeOfertaAgropecuaria(StoreCialcoOfertaAgropecuariaRequest $request)
    {
        try {
            $cialcoofertaagropecuaria = new CialcoOfertaAgropecuaria($request->all());
/*            $cialcoofertaagropecuaria->coa_fecha_inicio = date_create('now UTC');
            $cialcoofertaagropecuaria->coa_fecha_fin = date_create('now UTC'); */

            // CONTROL COLUMNS
            $cialcoofertaagropecuaria->coa_fecha_inserta = date_create('now UTC');
            $cialcoofertaagropecuaria->coa_usuario_inserta = Auth::id();

            $cialcoofertaagropecuaria->save();

        } catch (\Exception $e) {
            dd($e->getMessage());
            return back()->withInput();
        }

        Session::flash('flash_message', 'El registro fue creado éxitosamente');
        return redirect()->route('cialco.show', ['id' => $request->coa_cialco_id]);

    }

    public function createOrganizacion($id)
    {
        $cialco = Cialco::find($id);
		$ubicacionesgeograficas = ubicaciongeografica::where('uge_estado', true)->pluck('uge_nombre', 'uge_ubicacion_geografica_id'); 
        return view('cialco.create_organizacion', ['cialco' => $cialco, 'ubicacionesgeograficas' => $ubicacionesgeograficas]);
    }

    public function storeOrganizacion(StoreOrganizacionRequest $request)
    {
        try {
            $organizacion = new Organizacion($request->all());
/*            $cialcoorganizacion->org_fecha_inicio = date_create('now UTC');
            $cialcoorganizacion->org_fecha_fin = date_create('now UTC'); */

            // CONTROL COLUMNS
            $organizacion->org_fecha_inserta = date_create('now UTC');
            $organizacion->org_usuario_inserta = Auth::id();

            $organizacion->save();

        } catch (\Exception $e) {
            dd($e->getMessage());
            return back()->withInput();
        }

        Session::flash('flash_message', 'El registro fue creado éxitosamente');
        return redirect()->route('cialco.show', ['id' => $request->org_cialco_id]);

    }
	
	public function createProductor($id)
    {
        $cialco = Cialco::find($id);
/*		$ubicacionesgeograficas = ubicaciongeografica::where('uge_estado', true)->pluck('uge_nombre', 'uge_ubicacion_geografica_id'); */
        return view('cialco.create_productor', ['cialco' => $cialco]);
    }

    public function storeProductor(StoreProductorRequest $request)
    {
        try {
            $productor = new Productor($request->all());
/*            $cialcoproductor->pro_fecha_inicio = date_create('now UTC');
            $cialcoproductor->pro_fecha_fin = date_create('now UTC'); */

            // CONTROL COLUMNS
            $productor->pro_fecha_inserta = date_create('now UTC');
            $productor->pro_usuario_inserta = Auth::id();

            $productor->save();

        } catch (\Exception $e) {
            dd($e->getMessage());
            return back()->withInput();
        }

        Session::flash('flash_message', 'El registro fue creado éxitosamente');
        return redirect()->route('cialco.show', ['id' => $request->pro_cialco_id]);

    }


	public function createCialcoInterinstitucional($id)
    {
        $cialco = Cialco::find($id);
/*		$ubicacionesgeograficas = ubicaciongeografica::where('uge_estado', true)->pluck('uge_nombre', 'uge_ubicacion_geografica_id'); */

/*		$cialcos = Cialco::pluck('cia_nombre', 'cia_cialco_id'); */
        $accionfortalecimientos = AccionFortalecimiento::pluck('afr_descripcion', 'afr_accion_fortalecimiento_id');
        $apoyoinstitucionals = ApoyoInstitucional::pluck('ain_descripcion', 'ain_apoyo_institucional_id');
        $ubicacionprovincials = UbicacionGeografica::pluck('uge_nombre', 'uge_ubicacion_geografica_id');
        $ubicacioncantonals = UbicacionGeografica::pluck('uge_nombre', 'uge_ubicacion_geografica_id');
        $ubicacionparroquials = UbicacionGeografica::pluck('uge_nombre', 'uge_ubicacion_geografica_id');
/*        return view('cialcointerinstitucional.create', ['cialcos' => $cialcos, 'accionfortalecimientos' => $accionfortalecimientos, 'apoyoinstitucionals' => $apoyoinstitucionals, 'ubicacionprovincials' => $ubicacionprovincials, 'ubicacioncantonals' => $ubicacioncantonals, 'ubicacionparroquials' => $ubicacionparroquials]); */
        return view('cialco.create_interinstitucional', ['cialco' => $cialco, 'accionfortalecimientos' => $accionfortalecimientos, 'apoyoinstitucionals' => $apoyoinstitucionals, 'ubicacionprovincials' => $ubicacionprovincials, 'ubicacioncantonals' => $ubicacioncantonals, 'ubicacionparroquials' => $ubicacionparroquials]);
/*        return view('cialco.create_interinstitucional', ['cialco' => $cialco, 'ubicacionesgeograficas' => $ubicacionesgeograficas]); */
    }

    public function storeCialcoInterinstitucional(StoreCialcoInterinstitucionalRequest $request)
    {
        try {
            $cialcointerinstitucional = new CialcoInterinstitucional($request->all());
/*            $cialcoInterinstitucional->int_fecha_inicio = date_create('now UTC');
            $cialcoInterinstitucional->int_fecha_fin = date_create('now UTC'); */

            // CONTROL COLUMNS
            $cialcointerinstitucional->int_fecha_inserta = date_create('now UTC');
            $cialcointerinstitucional->int_usuario_inserta = Auth::id();

            $cialcointerinstitucional->save();

        } catch (\Exception $e) {
            dd($e->getMessage());
            return back()->withInput();
        }

        Session::flash('flash_message', 'El registro fue creado éxitosamente');
        return redirect()->route('cialco.show', ['id' => $request->int_cialco_id]);

    }

    public function createCialcoProducto($id)
    {
        $cialco = Cialco::find($id);
		$productos = Producto::where('prd_estado', true)->pluck('prd_nombre', 'prd_producto_id');
        return view('cialco.create_producto', ['cialco' => $cialco, 'productos' => $productos]);
    }

    public function storeCialcoProducto(StoreCialcoProductoRequest $request)
    {
        try {
            $cialcoproducto = new CialcoProducto($request->all());
/*            $cialcoproducto->cpr_fecha_inicio = date_create('now UTC');
            $cialcoproducto->cpr_fecha_fin = date_create('now UTC'); */

            // CONTROL COLUMNS
            $cialcoproducto->cpr_fecha_inserta = date_create('now UTC');
            $cialcoproducto->cpr_usuario_inserta = Auth::id();

            $cialcoproducto->save();

        } catch (\Exception $e) {
            dd($e->getMessage());
            return back()->withInput();
        }

        Session::flash('flash_message', 'El registro fue creado éxitosamente');
        return redirect()->route('cialco.show', ['id' => $request->cpr_cialco_id]);

    }

    public function createCialcoMontoVenta($id)
    {
        $cialco = Cialco::find($id);
        return view('cialco.create_montoventa', ['cialco' => $cialco]);
    }

    public function storeCialcoMontoVenta(StoreCialcoMontoVentaRequest $request)
    {
        try {
            $cialcomontoventa = new CialcoMontoVenta($request->all());
/*            $cialcomontoventa->cmv_fecha_inicio = date_create('now UTC');
            $cialcomontoventa->cmv_fecha_fin = date_create('now UTC'); */

            // CONTROL COLUMNS
            $cialcomontoventa->cmv_fecha_inserta = date_create('now UTC');
            $cialcomontoventa->cmv_usuario_inserta = Auth::id();

            $cialcomontoventa->save();

        } catch (\Exception $e) {
            dd($e->getMessage());
            return back()->withInput();
        }

        Session::flash('flash_message', 'El registro fue creado éxitosamente');
        return redirect()->route('cialco.show', ['id' => $request->cmv_cialco_id]);

    }

    public function destroyMontoVenta($id)
    {

        $result = MontoVenta::find($id);
        $result->cmv_fecha_elimina = date_create('NOW UTC');
        $result->cmv_usuario_elimina = Auth::id();
        $result->save();
        $result->delete();

        Session::flash('flash_message', 'Registro eliminado');
        return back();
    }

    public function destroyProducto($id)
    {

        $result = Producto::find($id);
        $result->cpr_fecha_elimina = date_create('NOW UTC');
        $result->cpr_usuario_elimina = Auth::id();
        $result->save();
        $result->delete();

        Session::flash('flash_message', 'Registro eliminado');
        return back();
    }

	
    public function destroyInterinstitucional($id)
    {

        $result = Interinstitucional::find($id);
        $result->int_fecha_elimina = date_create('NOW UTC');
        $result->int_usuario_elimina = Auth::id();
        $result->save();
        $result->delete();

        Session::flash('flash_message', 'Registro eliminado');
        return back();
    }
	
    public function destroyProductor($id)
    {

        $result = Productor::find($id);
        $result->pro_fecha_elimina = date_create('NOW UTC');
        $result->pro_usuario_elimina = Auth::id();
        $result->save();
        $result->delete();

        Session::flash('flash_message', 'Registro eliminado');
        return back();
    }
	
	
    public function destroyRepresentante($id)
    {

        $result = Representante::find($id);
        $result->rep_fecha_elimina = date_create('NOW UTC');
        $result->rep_usuario_elimina = Auth::id();
        $result->save();
        $result->delete();

        Session::flash('flash_message', 'Registro eliminado');
        return back();
    }

    public function destroyDireccion($id)
    {

        $result = Direccion::find($id);
        $result->dir_fecha_elimina = date_create('NOW UTC');
        $result->dir_usuario_elimina = Auth::id();
        $result->save();
        $result->delete();

        Session::flash('flash_message', 'Registro eliminado');
        return back();
    }

    public function destroyCoordenada($id)
    {

        $result = Coordenada::find($id);
        $result->coo_usuario_elimina = Auth::id();
        $result->update();
        $result->delete();

        Session::flash('flash_message', 'Registro eliminado');
        return back();
    }

    public function destroyFrecuencia($id)
    {
        $result = CialcoFrecuencia::find($id);
        $result->cfr_usuario_elimina = Auth::id();
        $result->update();
        $result->delete();

        Session::flash('flash_message', 'Registro eliminado');
        return back();
    }

    public function destroyOfertaAgropecuaria($id)
    {

        $result = CialcoOfertaAgropecuaria::find($id);
        $result->coa_fecha_elimina = date_create('NOW UTC');
        $result->coa_usuario_elimina = Auth::id();
        $result->save();
        $result->delete();

        Session::flash('flash_message', 'Registro eliminado');
        return back();
    }
	
    public function destroyOrganizacion($id)
    {

        $result = Organizacion::find($id);
        $result->org_fecha_elimina = date_create('NOW UTC');
        $result->org_usuario_elimina = Auth::id();
        $result->save();
        $result->delete();

        Session::flash('flash_message', 'Registro eliminado');
        return back();
    }
	
}