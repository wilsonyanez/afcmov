@extends('adminlte::page')
@section('title', 'Nuevo Apoyo Interinstitucional')
@section('content_header')
    <h1>Apoyo Interinstitucional</h1>
@stop
@section('content')
    @include('include.alert')
    {!! Form::open(['route' => 'cialco.cialcointerinstitucional.store','method'=> 'post']) !!}

    <div class="box box-primary">
        {{ Form::hidden('int_cialco_id',$cialco->cia_cialco_id,['class'=>'form-control'])}}
        <div class="box-header with-border">
            <h3 class="box-title">Nuevo Apoyo Interinstitucional</h3>
        </div>
        <div class="box-body">
            <div class="row"> <!-- ROW 1 -->
                <div class="col-md-3">
                    <div class="form-group">
						<label for="int_accion_fortalecimiento_id">Accion Fortalecimiento</label>
							{{ Form::select('int_accion_fortalecimiento_id', $accionfortalecimientos, null, ['class'=>'form-control','placeholder' => 'Seleccione...']) }}
							@include('include.error_form_element',['name'=>'int_accion_fortalecimiento_id'])
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
						<label for="int_apoyo_institucional_id">Apoyo Institucional</label>
							{{ Form::select('int_apoyo_institucional_id', $apoyoinstitucionals, null, ['class'=>'form-control','placeholder' => 'Seleccione...']) }}
							@include('include.error_form_element',['name'=>'int_apoyo_institucional_id'])
						<p>
							@include('include.ok_element')
							<span class="label label-default">TODO: Trait after "OTRO" selection</span>
						</p>
                    </div>
                </div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="int_descripcion">Descripción</label>
						{{ Form::text('int_descripcion',null,['class'=>'form-control', 'required' => 'required|alpha'])}}
                        @include('include.error_form_element',['name'=>'int_descripcion'])
					</div>
				</div>
            </div>
            <div class="row">  <!-- ROW 2 -->
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="int_provincial">Provincial</label>
                        {{ Form::select('int_provincial',['1' => 'SI', '0' => 'NO'],null,['class'=>'form-control'])}}
                        @include('include.error_form_element',['name'=>'int_provincial'])
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
						<label for="int_gad_provincial_id">Gad Provincial</label>
							{{ Form::select('int_gad_provincial_id', $ubicacionprovincials, null, ['class'=>'form-control','placeholder' => 'Seleccione...']) }}
							@include('include.error_form_element',['name'=>'int_gad_provincial_id'])
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="int_cantonal">Cantonal</label>
                        {{ Form::select('int_cantonal',['1' => 'SI', '0' => 'NO'],null,['class'=>'form-control'])}}
                        @include('include.error_form_element',['name'=>'int_cantonal'])
                    </div>
                </div>
            </div>
            <div class="row">  <!-- ROW 3 -->
                <div class="col-md-3">
					<div class="form-group">
                        <label for="int_gad_cantonal_id">Gad Cantonal</label>
						{{ Form::select('int_gad_cantonal_id', $ubicacioncantonals, null, ['class'=>'form-control','placeholder' => 'Seleccione...']) }}
                        @include('include.error_form_element',['name'=>'int_gad_cantonal_id'])
					</div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="int_parroquial">Parroquial</label>
                        {{ Form::select('int_parroquial',['1' => 'SI', '0' => 'NO'],null,['class'=>'form-control'])}}
                        @include('include.error_form_element',['name'=>'int_parroquial'])
                    </div>
				</div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="int_gad_parroquial_id">Gad Parroquial</label>
						{{ Form::select('int_gad_parroquial_id', $ubicacionparroquials, null, ['class'=>'form-control','placeholder' => 'Seleccione...']) }}
                        @include('include.error_form_element',['name'=>'int_gad_parroquial_id'])
                    </div>
                </div>
            </div>
            <div class="row">  <!-- ROW 4 -->
                <div class="col-md-3">
					<div class="form-group">
						<label for="int_otro">Otro</label>
                        {{ Form::select('int_otro',['1' => 'SI', '0' => 'NO'],null,['class'=>'form-control'])}}
                        @include('include.error_form_element',['name'=>'int_otro'])
					</div>
                </div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="int_fecha_inicio">Fecha Inicio</label>
						{{ Form::date('int_fecha_inicio', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
                        @include('include.error_form_element',['name'=>'int_fecha_inicio'])
					</div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="int_fecha_fin">Fecha Fin</label>
						{{ Form::date('int_fecha_fin', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
                        @include('include.error_form_element',['name'=>'int_fecha_fin'])
                    </div>
                </div>
            </div>
            <div class="row">  <!-- ROW 5 -->
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="int_estado">Estado</label>
                        {{ Form::select('int_estado',['1' => 'Activo', '0' => 'Inactivo'],null,['class'=>'form-control'])}}
                    </div>
				</div>
            </div>
        </div>

	<div class="box-footer">
		<button type="submit" class="btn btn-primary">Crear</button>
	</div>
	{!! Form::close() !!}
	<div class="box-footer">
		<a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
	</div>
	@stop
	@section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
	@stop
	@section('js')
@stop