<?php

use Illuminate\Database\Seeder;

class CialcoOfertaAgropecuariaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('cialco_oferta_agropecuaria')->delete();
        $faker = Faker\Factory::create();

        for ($i = 0; $i < 200; $i++) {
            \DB::table('cialco_oferta_agropecuaria')->insert([

                'coa_descripcion_otro' => $faker->word,

                'coa_fecha_inicio' => date_create('now UTC'),
                'coa_fecha_fin' => date_create('now UTC'),

                'coa_fecha_inserta' => date_create('now UTC'),
                'coa_fecha_actualiza' => date_create('now UTC'),

                /*                'coa_oferta_agropecuaria_id' => OfertaAgropecuaria::inRandomOrder()->get()->first()->ofa_oferta_agropecuaria_id, */
                'coa_oferta_agropecuaria_id' => $faker->numberBetween(1, 11),
                /*                'coa_cialco_id' => Cialco::inRandomOrder()->get()->first()->cia_cialco_id,    */
                'coa_cialco_id' => $faker->numberBetween(1, 100),

            ]);
        }

    }
}