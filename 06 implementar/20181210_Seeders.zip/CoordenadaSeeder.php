<?php

use Illuminate\Database\Seeder;

class CoordenadaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create();
        for($i=0 ; $i<200; $i++){
            \DB::table('coordenada')->insert([
                'coo_posicion_x'=>$faker->randomFloat(4,1,1000),
                'coo_posicion_y'=>$faker->randomFloat(4,1,1000),
                'coo_posicion_z'=>$faker->randomFloat(4,1,1000),

                'coo_cialco_id'=>$faker->numberBetween(1,100),
                'coo_utm_id'=>$faker->numberBetween(1,5),

                'coo_estado'=>$faker->numberBetween(0,1),
                'coo_fecha_inicio'=>date_create('now UTC'),
                'coo_fecha_fin'=>date_create('now UTC'),
                'coo_fecha_inserta'=>date_create('now UTC'),
                'coo_fecha_actualiza'=>date_create('now UTC'),

            ]);
        }
    }
}
