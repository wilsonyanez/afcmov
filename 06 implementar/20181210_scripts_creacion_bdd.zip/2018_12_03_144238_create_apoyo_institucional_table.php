<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateApoyoInstitucionalTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('apoyo_institucional', function (Blueprint $table) {
            $table->increments('ain_apoyo_institucional_id');
            $table->integer('ain_orden')->unsigned()->nullable();
            $table->text('ain_descripcion');

            $table->date('ain_fecha_inicio')->nullable();
            $table->date('ain_fecha_fin')->nullable();

            // TODO Verificar si es necesario agregar integridad referencial para usuario
            $table->boolean('ain_estado')->default(true);

            $table->integer('ain_usuario_inserta')->unsigned()->nullable();
            $table->timestamp('ain_fecha_inserta')->nullable();

            $table->integer('ain_usuario_actualiza')->unsigned()->nullable();
            $table->timestamp('ain_fecha_actualiza')->nullable();

            $table->integer('ain_usuario_elimina')->unsigned()->nullable();
            $table->timestamp('ain_fecha_elimina')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('apoyo_institucional');
    }
}