
<?php $__env->startSection('title', 'Nuevo Productor por CIALCO'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Productores</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::open(['route' => 'cialco.productor.store','method'=> 'post']); ?>

	
    <div class="box box-primary">
        <?php echo e(Form::hidden('pro_cialco_id',$cialco->cia_cialco_id,['class'=>'form-control'])); ?>

        <div class="box-header with-border">
            <h3 class="box-title">Nuevo Productor</h3>
        </div>
        <div class="box-body">
            <div class="row"> <!-- ROW 1 -->
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="pro_dispone_sello_afc">Dispone Sello Afc?</label>
                        <?php echo e(Form::select('pro_dispone_sello_afc',['1' => 'SI', '0' => 'NO'],null,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'pro_dispone_sello_afc'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="pro_identificacion_sello_afc">Identificacion sello AFC</label>
						<?php echo e(Form::text('pro_identificacion_sello_afc',null,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'pro_identificacion_sello_afc'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="pro_numero_cedula">Número cédula</label>
						<?php echo e(Form::text('pro_numero_cedula',null,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'pro_numero_cedula'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
            <div class="row">  <!-- ROW 2 -->
                <div class="col-md-3">
					<div class="form-group">
						<label for="pro_nombres">Nombres</label>
						<?php echo e(Form::text('pro_nombres',null,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'pro_nombres'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="pro_apellidos">Apellidos</label>
                        <?php echo e(Form::text('pro_apellidos',null,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'pro_apellidos'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="pro_genero">Género</label>
                        <?php echo e(Form::select('pro_genero',['1' => 'Masculino', '0' => 'Femenino'],null,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'pro_genero'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>

            <div class="row">  <!-- ROW 3 -->
                <div class="col-md-3">
					<div class="form-group">
						<label for="pro_fecha_nacimiento">Fecha Nacimiento</label>
						<?php echo e(Form::date('pro_fecha_nacimiento', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});'))); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'pro_fecha_nacimiento'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="pro_nacionalidad">Nacionalidad</label>
						<?php echo e(Form::text('pro_nacionalidad',null,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'pro_nacionalidad'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="pro_fecha_inicio">Fecha Inicio</label>
						<?php echo e(Form::date('pro_fecha_inicio', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});'))); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'pro_fecha_inicio'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
            </div>
            <div class="row">  <!-- ROW 4 -->
				<div class="col-md-3">
                    <div class="form-group">
						<label for="pro_fecha_fin">Fecha Fin</label></br>
						<?php echo e(Form::date('pro_fecha_fin', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});'))); ?>

						<?php echo $__env->make('include.error_form_element',['name'=>'pro_fecha_fin'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="pro_estado">Estado</label>
                        <?php echo e(Form::select('pro_estado',['1' => 'Activo', '0' => 'Inactivo'],null,['class'=>'form-control'])); ?>

                    </div>
                </div>
            </div>
        </div>

        <div class="box-footer">
            <button type="submit" class="btn btn-primary">Crear</button>
        </div>
        <?php echo Form::close(); ?>

        <div class="box-footer">
            <a href="<?php echo e(URL::previous()); ?>" class="pull-right btn btn-default">Regresar</a>
        </div>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('css'); ?>
            <link rel="stylesheet" href="/css/admin_custom.css">
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>