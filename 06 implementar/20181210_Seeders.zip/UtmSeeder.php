<?php

use Illuminate\Database\Seeder;

class UtmSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('utm')->insert([
            'utm_descripcion' => '15n',
            'utm_orden' => 1,
            'utm_fecha_inserta' => date_create('now UTC'),
            'utm_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('utm')->insert([
            'utm_descripcion' => '16n',
            'utm_orden' => 2,
            'utm_fecha_inserta' => date_create('now UTC'),
            'utm_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('utm')->insert([
            'utm_descripcion' => '17n',
            'utm_orden' => 3,
            'utm_fecha_inserta' => date_create('now UTC'),
            'utm_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('utm')->insert([
            'utm_descripcion' => '18n',
            'utm_orden' => 4,
            'utm_fecha_inserta' => date_create('now UTC'),
            'utm_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('utm')->insert([
            'utm_descripcion' => '15s',
            'utm_orden' => 5,
            'utm_fecha_inserta' => date_create('now UTC'),
            'utm_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('utm')->insert([
            'utm_descripcion' => '16s',
            'utm_orden' => 6,
            'utm_fecha_inserta' => date_create('now UTC'),
            'utm_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('utm')->insert([
            'utm_descripcion' => '17s',
            'utm_orden' => 7,
            'utm_fecha_inserta' => date_create('now UTC'),
            'utm_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('utm')->insert([
            'utm_descripcion' => '18s',
            'utm_orden' => 8,
            'utm_fecha_inserta' => date_create('now UTC'),
            'utm_fecha_actualiza' => date_create('now UTC')
        ]);

    }
}
