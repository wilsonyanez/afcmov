<?php

namespace App\Catalogs;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ofertaAgropecuaria extends Model
{
    protected $table='oferta_agropecuaria';
    protected $primaryKey = 'ofa_oferta_agropecuaria_id';

    const CREATED_AT = 'ofa_fecha_inserta';
    const UPDATED_AT = 'ofa_fecha_actualiza';

    use SoftDeletes;
    const DELETED_AT = 'ofa_fecha_elimina';

    protected $append = [
        'texto_estado',
        'texto_estado_html'
    ];

    protected $fillable = [
        'ofa_descripcion',
        'ofa_estado',
        'ofa_orden'
    ];

/*
    public function ofertaAgropecuaria()
    {
        return $this->belongsTo('App\Catalogs\ofertaAgropecuaria', 'ofa_oferta_agropecuaria_id');
    }
*/
    public function getTextoEstadoAttribute()
    {
        return ($this->ofa_estado ? 'Activo' : 'Inactivo');
    }

    public function getTextoEstadoHtmlAttribute()
    {
        if ($this->ofa_estado)
            return ('<span class="label label-success">' . $this->texto_estado . '</span>');
        return ('<span class="label label-default">' . $this->texto_estado . '</span>');
    }
}