@extends('adminlte::page')



@section('title', 'Dashboard')



@section('content_header')

    <h1>RQ24-WEB-HU090</h1>
    <p>Como Técnico de Territorio, quiero Registrar Datos de Montos de Venta de los CIALCO, que me solicita el Administrador AFC para validar la participación en el Mercado de los Circuitos Alternativos de Comercialización de la AFC.</p>
"Diseño: Cumplir formato detallado en los archivos:
RQ24-WEB-HU090-DIS075 Montos de Venta de los CIALCO.png
"
"Usabilidad: Cumplir con el detalle descrito en pestaña funcionalidad con identificación: RQ24-WEB-HU090-FUN
"
"Rendimiento: Tiempo de respuesta inferior a 5 segundos
"
"Satisfacción: Cumplimiento de Pruebas funcionales
"
@stop



@section('content')

    <p>Welcome to this beautiful admin panel - HDTuto.com.</p>
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Montos de Ventas de Cialco</h3>
            <div class="row">

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Código</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Código">
                    </div>
                    <p>
                        <span class="label label-info">Búsqueda?</span>
                        <span class="label label-info">Dropdown?</span>
                    </p>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Nombre</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Nombre">
                        <p>
                            <span class="label label-info">Búsqueda?</span>
                            <span class="label label-info">Dropdown?</span>
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Año</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Fecha">
                    </div>
                    <p>
                        <span class="label label-info">Dropdown?</span>
                        <span class="label label-info">Año  Automático</span>
                    </p>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Mes</label>
                        <select class="form-control">
                            <option>Enero</option>
                            <option>Febrero</option>
                            <option>Marzo</option>
                            <option>Abril</option>
                        </select>
                        <p>
                            <span class="label label-info">Dropdown?</span>
                        </p>
                    </div>
                </div>

            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Monto</label>
                        <input type="number" class="form-control" id="exampleInputEmail1" placeholder="Fecha">
                    </div>
                    <p>
                        <span class="label label-info">Modificar Meses Anteriores</span>
                        <span class="label label-info">Decimales</span>
                    </p>
                </div>

            </div>


        </div>


        <div class="box-footer">
            <button type="submit" class="btn btn-primary">Agregar</button>
        </div>
        <div class="box-footer" align="center">
            <button type="submit" class="btn btn-primary">Anterior</button>
            <button type="submit" class="btn btn-primary">Siguiente</button>
        </div>

    </div>

@stop



@section('css')

    <link rel="stylesheet" href="/css/admin_custom.css">

@stop



@section('js')

    <script> console.log('Hi!'); </script>

@stop