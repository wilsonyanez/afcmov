@extends('adminlte::page')
@section('title', 'Productos')
@section('content_header')
    <h1>Productos</h1>
@stop
@section('content')
    {!! Form::model($result, ['method' => 'PATCH','route' => ['producto.update', 'id'=>$result->prd_producto_id]]) !!}
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Catálogo de Productos</h3>
        </div>
        <div class="box-body">
            <div class="row"> <!-- ROW 1 -->
                <div class="col-md-3">
					<div class="form-group">
						<label for="prd_codigo_producto">Código producto</label>
						{{ Form::text('prd_codigo_producto',$result->prd_codigo_producto,['class'=>'form-control'])}}
                        @include('include.error_form_element',['name'=>'prd_codigo_producto'])
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="prd_nivel">Nivel</label>
						{{ Form::text('prd_nivel',$result->prd_nivel,['class'=>'form-control', 'required' => 'required|integer'])}}
                        @include('include.error_form_element',['name'=>'prd_nivel'])
					</div>
				</div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="prd_nombre">Nombre</label>
                        {{ Form::text('prd_nombre',$result->prd_nombre,['class'=>'form-control', 'required' => 'required|alpha'])}}
                        @include('include.error_form_element',['name'=>'prd_nombre'])
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3">
					<div class="form-group">
						<label for="prd_padre_producto">Padre Código producto</label>
						{{ Form::text('prd_padre_producto',$result->prd_padre_producto,['class'=>'form-control'])}}
                        @include('include.error_form_element',['name'=>'prd_padre_producto'])
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="prd_fecha_inicio">Fecha Inicio</label>
						{{ Form::date('prd_fecha_inicio', $result->prd_fecha_inicio, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
                        @include('include.error_form_element',['name'=>'prd_fecha_inicio'])
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="prd_fecha_fin">Fecha Fin</label>
						{{ Form::date('prd_fecha_fin', $result->prd_fecha_fin, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
                        @include('include.error_form_element',['name'=>'prd_fecha_fin'])
					</div>
				</div>
            </div>
            <div class="row">				
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="prd_estado">Estado</label>
                        {{ Form::select('prd_estado',['1' => 'Activo', '0' => 'Inactivo'],$result->prd_estado,['class'=>'form-control'])}}
                    </div>
                </div>
            </div>
        </div>
	<div class="box-footer">
		<button type="submit" class="btn btn-primary">Editar</button>
	</div>
	{!! Form::close() !!}
	<div class="box-footer">
		<a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
	</div>
    @stop
    @section('css')
       <link rel="stylesheet" href="/css/admin_custom.css">
    @stop
    @section('js')
@stop