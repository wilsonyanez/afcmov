
<?php $__env->startSection('title', 'Productos'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Productos</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo Form::model($result, ['method' => 'PATCH','route' => ['producto.update', 'id'=>$result->prd_producto_id]]); ?>

    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Catálogo de Productos</h3>
        </div>
        <div class="box-body">
            <div class="row"> <!-- ROW 1 -->
                <div class="col-md-3">
					<div class="form-group">
						<label for="prd_codigo_producto">Código producto</label>
						<?php echo e(Form::text('prd_codigo_producto',$result->prd_codigo_producto,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'prd_codigo_producto'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="prd_nivel">Nivel</label>
						<?php echo e(Form::text('prd_nivel',$result->prd_nivel,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'prd_nivel'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="prd_nombre">Nombre</label>
                        <?php echo e(Form::text('prd_nombre',$result->prd_nombre,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'prd_nombre'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3">
					<div class="form-group">
						<label for="prd_padre_producto">Padre Código producto</label>
						<?php echo e(Form::text('prd_padre_producto',$result->prd_padre_producto,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'prd_padre_producto'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="prd_fecha_inicio">Fecha Inicio</label>
						<?php echo e(Form::text('prd_fecha_inicio',$result->prd_fecha_inicio,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'prd_fecha_inicio'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="prd_fecha_fin">Fecha Fin</label>
						<?php echo e(Form::text('prd_fecha_fin',$result->prd_fecha_fin,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'prd_fecha_fin'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
            </div>
            <div class="row">				
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="prd_estado">Estado</label>
                        <?php echo e(Form::select('prd_estado',['1' => 'Activo', '0' => 'Inactivo'],$result->prd_estado,['class'=>'form-control'])); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="box-footer">
            <button type="submit" class="btn btn-primary">Editar</button>
        </div>
        <?php echo Form::close(); ?>

        <div class="box-footer">
            <a href="<?php echo e(URL::previous()); ?>" class="pull-right btn btn-default">Regresar</a>
        </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('css'); ?>
       <link rel="stylesheet" href="/css/admin_custom.css">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>