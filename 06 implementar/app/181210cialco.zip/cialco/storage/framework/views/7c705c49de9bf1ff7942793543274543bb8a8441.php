
<?php $__env->startSection('title', 'Cialco Frecuencia'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Cialco Frecuencia</h1>
<?php $__env->stopSection(); ?>
  <?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="box box-primary">
        <div class="box-header">
            <h2 class="page-header">
                <i class="fa fa-globe"></i> Cialco Frecuencia
            </h2>
        </div>
        <div class="box-body">
              <?php echo $grid; ?>

        </div>
        <div class="box-footer">
        </div>
	  <?php $__env->stopSection(); ?>
	  <?php $__env->startSection('css'); ?>
		<link rel="stylesheet" href="/css/admin_custom.css">
		<?php $__env->stopSection(); ?>
	  <?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>