<?php

use Illuminate\Database\Seeder;

class CialcoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {   $faker = Faker\Factory::create();
        for($i=0 ; $i<100; $i++) {
            \DB::table('cialco')->insert([
                'cia_permanencia_id' => $faker->numberBetween(1,2),
                'cia_modalidad_id' => $faker->numberBetween(1,7),
                'cia_nombre' => $faker->name,
                'cia_contacto' => $faker->name,
                'cia_correo_electronico' => $faker->email,
                'cia_sitio_web' => $faker->freeEmailDomain,
                'cia_fecha_inicio' => date_create('now UTC'),
                'cia_fecha_fin' => date_create('now UTC'),
                'cia_usuario_inserta' => 1,
                'cia_fecha_inserta' => date_create('now UTC'),
                'cia_usuario_inserta' => 1,
                'cia_fecha_inserta' => date_create('now UTC'),
                'cia_usuario_actualiza' => 1,
                'cia_fecha_actualiza' => date_create('now UTC')
            ]);
        }
    }
}
