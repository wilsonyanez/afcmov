<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePermanenciaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('permanencia', function (Blueprint $table) {
            $table->increments('per_permanencia_id');
            $table->text('per_descripcion');

            $table->date('per_fecha_inicio')->nullable();
            $table->date('per_fecha_fin')->nullable();

            $table->boolean('per_estado')->default(true);

            $table->integer('per_usuario_inserta')->unsigned()->nullable();
            $table->timestamp('per_fecha_inserta')->nullable();

            $table->integer('per_usuario_actualiza')->unsigned()->nullable();
            $table->timestamp('per_fecha_actualiza')->nullable();

            // Soft-delete
            $table->integer('per_usuario_elimina')->unsigned()->nullable();
            $table->timestamp('per_fecha_elimina')->nullable();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('permanencia');
    }
}
