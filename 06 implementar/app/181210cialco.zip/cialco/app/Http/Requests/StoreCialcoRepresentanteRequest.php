<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreCialcoRepresentanteRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'rep_identificacion' => 'integer|digits:10|required',
            'rep_contacto' => 'alpha|required',
            'rep_correo_electronico' => 'email|required',

        ];
    }
    public function messages()
    {

        return [
            'rep_identificacion.required' => 'Identificación es requerida',
            'rep_contacto.required' => 'Nombre es requerido',
            'rep_correo_electronico.required' => 'Correo electrónico es requerido',
            'rep_correo_electronico.email' => 'Formato incorrecto',
        ];
    }
}