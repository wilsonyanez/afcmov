/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author david
 */
@Entity
@Table(name = "organizacion_detv")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "OrganizacionDetv.findAll", query = "SELECT o FROM OrganizacionDetv o")
    , @NamedQuery(name = "OrganizacionDetv.findByIdOdetv", query = "SELECT o FROM OrganizacionDetv o WHERE o.idOdetv = :idOdetv")
    , @NamedQuery(name = "OrganizacionDetv.findByCodMod", query = "SELECT o FROM OrganizacionDetv o WHERE o.codMod = :codMod")
    , @NamedQuery(name = "OrganizacionDetv.findByOrden", query = "SELECT o FROM OrganizacionDetv o WHERE o.orden = :orden")
    , @NamedQuery(name = "OrganizacionDetv.findByCodPreg", query = "SELECT o FROM OrganizacionDetv o WHERE o.codPreg = :codPreg")
    , @NamedQuery(name = "OrganizacionDetv.findByValor", query = "SELECT o FROM OrganizacionDetv o WHERE o.valor = :valor")
    , @NamedQuery(name = "OrganizacionDetv.findByClave", query = "SELECT o FROM OrganizacionDetv o WHERE o.clave = :clave")})
public class OrganizacionDetv implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_odetv")
    private Integer idOdetv;
    @Size(max = 10)
    @Column(name = "cod_mod")
    private String codMod;
    @Column(name = "orden")
    private Integer orden;
    @Size(max = 20)
    @Column(name = "cod_preg")
    private String codPreg;
    @Size(max = 2147483647)
    @Column(name = "valor")
    private String valor;
    @Size(max = 30)
    @Column(name = "clave")
    private String clave;
    @JoinColumn(name = "cod_orga", referencedColumnName = "id_organizacion")
    @ManyToOne
    private Organizacion codOrga;

    public OrganizacionDetv() {
    }

    public OrganizacionDetv(Integer idOdetv) {
        this.idOdetv = idOdetv;
    }

    public Integer getIdOdetv() {
        return idOdetv;
    }

    public void setIdOdetv(Integer idOdetv) {
        this.idOdetv = idOdetv;
    }

    public String getCodMod() {
        return codMod;
    }

    public void setCodMod(String codMod) {
        this.codMod = codMod;
    }

    public Integer getOrden() {
        return orden;
    }

    public void setOrden(Integer orden) {
        this.orden = orden;
    }

    public String getCodPreg() {
        return codPreg;
    }

    public void setCodPreg(String codPreg) {
        this.codPreg = codPreg;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public Organizacion getCodOrga() {
        return codOrga;
    }

    public void setCodOrga(Organizacion codOrga) {
        this.codOrga = codOrga;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idOdetv != null ? idOdetv.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof OrganizacionDetv)) {
            return false;
        }
        OrganizacionDetv other = (OrganizacionDetv) object;
        if ((this.idOdetv == null && other.idOdetv != null) || (this.idOdetv != null && !this.idOdetv.equals(other.idOdetv))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.OrganizacionDetv[ idOdetv=" + idOdetv + " ]";
    }
    
}
