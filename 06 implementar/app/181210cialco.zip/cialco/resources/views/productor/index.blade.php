@extends('adminlte::page')
@section('title', 'Productores')
@section('content_header')
    <h1>Productores</h1>
@stop
@section('content')
    @include('include.alert')
    <div class="box box-primary">
        <div class="box-header with-border">
            <h2 class="page-header">
                <i class="fa fa-globe"></i> Listado
            </h2>
        </div>
        <div class="row">
            <div class="col-xs-14 table-responsive">
                <table class="table table-striped">
                <tr>
                  <th>ID</th>
                  <th>Dispone Sello AFC</th>
                  <th>Identificacion Sello AFC</th>
                  <th>Número Cédula</th>
                  <th>Nombres</th>
                  <th>Apellidos</th>
                  <th>Género</th>
                  <th>Fecha Nacimiento</th>
                  <th>Nacionalidad</th>
                  <th>Fecha Inicio</th>
                  <th>Fecha Fin</th>
                  <th>Estado</th>
                  <th>Fecha Creación</th>
				  <th>Acciones</th>
				</tr>
                @foreach($results as $key=>$item)
                <tr>
                  <td>{{$key+1}}</td>
                  <td>{!!$item->texto_dispone_sello_afc_html!!}</td>
                  <td>{{$item->pro_identificacion_sello_afc}}</td>
                  <td>{{$item->pro_numero_cedula}}</td>
                  <td>{{$item->pro_nombres}}</td>
                  <td>{{$item->pro_apellidos}}</td>
                  <td>{!!$item->texto_genero_html!!}</td>
                  <td>{{$item->pro_fecha_nacimiento}}</td>
                  <td>{{$item->pro_nacionalidad}}</td>
                  <td>{{$item->pro_fecha_inicio}}</td>
                  <td>{{$item->pro_fecha_fin}}</td>
                  <td>{!!$item->texto_estado_html!!}</td>
                  <td>{{$item->pro_fecha_inserta}}</td>
                  <td>
                     <a href="{{route('productor.show',['id'=>$item->pro_productor_id])}} "class="label label-primary">Ver</a>
                     <a href="{{route('productor.edit',['id'=>$item->pro_productor_id])}}" class="label label-primary">Editar</a>
                  </td>
                </tr>
                @endforeach
              </table>
            </div>
        </div>
	<div class="box-footer">
	{{--<a class="btn btn-sm btn-default pull-right" href="{{route('cialco.create')}}">Nuevo</a>--}}
	</div>
	@stop
	@section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
	@stop
	@section('js')
@stop