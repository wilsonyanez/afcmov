<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreCoordenadaRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'coo_cialco_id'=>'required',
            'coo_posicion_x'=>'numeric|required',
            'coo_posicion_y'=>'numeric|required',
            'coo_posicion_z'=>'numeric|required',
            'coo_estado'=>'required',
            'coo_utm_id'=>'required',
        ];
    }

    public function messages(){
        return [
            'coo_cialco_id.required' => 'Cialco es requerido',
            'coo_posicion_x.required' => 'Posición en X es requerido',
            'coo_posicion_y.required' => 'Posición en Y es requerido',
            'coo_posicion_z.required' => 'Posición en Z es requerido',
            'coo_estado.required' => 'Estado en Z es requerido',
            'coo_utm_id.required' => 'Utm es requerido',
        ];
    }
}