@extends('adminlte::page')
@section('title', 'Nuevo Cialco por Productos')
@section('content_header')
    <h1>Cialco por Productos</h1>
@stop
@section('content')
  @include('include.alert')
    {!! Form::model($result, ['method' => 'PATCH','route' => ['cialcoproducto.update', 'id'=>$result->cpr_cialco_producto_id]]) !!}
	<div class="box box-primary">
		<div class="box-header with-border">
			<h3 class="box-title">Editar</h3>
		</div>
		<div class="box-body">
		  <div class="row"> <!-- ROW 1 -->
			<div class="col-md-3">
				<div class="form-group">
					<label for="cpr_cialco_id">Cialco</label>
						{{ Form::select('cpr_cialco_id', $cialcos, $result->cpr_cialco_id, ['class'=>'form-control','placeholder' => 'Seleccione...']) }}
						@include('include.error_form_element',['name'=>'cpr_cialco_id'])
				</div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
					<label for="cpr_producto_id">Productos</label>
						{{ Form::select('cpr_producto_id', $productos, $result->cpr_producto_id, ['class'=>'form-control','placeholder' => 'Seleccione...']) }}
						@include('include.error_form_element',['name'=>'cpr_producto_id'])
				</div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
					<label for="cpr_ejercicio">Año</label>
						{{ Form::number('cpr_ejercicio',$result->cpr_ejercicio,['class'=>'form-control', 'required' => 'required|integer'])}}
						@include('include.error_form_element',['name'=>'cpr_ejercicio'])
				</div>
			</div>
		</div>
		<div class="row"> <!-- ROW 2 -->
			<div class="col-md-3">
				<div class="form-group">
					<label for="cpr_periodo">Mes</label>
						{{ Form::number('cpr_periodo',$result->cpr_periodo,['class'=>'form-control'])}}
						@include('include.error_form_element',['name'=>'cpr_periodo'])
				</div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
					<label for="cpr_precio">Precio</label>
						{{ Form::number('cpr_precio',number_format($result->cpr_precio, 2, '.', ','),['class'=>'form-control', 'required' => 'required|numeric'])}}
						@include('include.error_form_element',['name'=>'cpr_precio'])
				</div>
			</div>
			<div class="col-md-3">		
				<div class="form-group">
					<label for="cpr_unidad">Unidad (Kg)</label>
						{{ Form::select('cpr_unidad',['3' => 'Unidades', '2' => 'Litros', '1' => 'Kilos'],$result->cpr_unidad,['class'=>'form-control'])}}
						@include('include.error_form_element',['name'=>'cpr_unidad'])
			  </div>
			</div>
		</div>
		<div class="row"> <!-- ROW 3 -->
			<div class="col-md-3">
			<div class="form-group">
				<label for="cpr_fecha_inicio">Fecha Inicio</label></br>
					{{ Form::date('cpr_fecha_inicio', $result->cpr_fecha_inicio, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
					@include('include.error_form_element',['name'=>'cpr_fecha_inicio'])
			</div>
			</div>
			<div class="col-md-3">
			<div class="form-group">
				<label for="cpr_fecha_fin">Fecha Fin</label></br>
					{{ Form::date('cpr_fecha_fin', $result->cpr_fecha_fin, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
					@include('include.error_form_element',['name'=>'cpr_fecha_fin'])
			</div>
			</div>
			<div class="col-md-3">
			  <div class="form-group">
				<label for="cpr_estado">Estado</label>
					{{ Form::select('cpr_estado',['1' => 'Activo', '0' => 'Inactivo'],$result->cpr_estado,['class'=>'form-control'])}}
				</div>
			</div>
		  </div>
		</div>
		<div class="box-footer">
		  <button type="submit" class="btn btn-primary">Editar</button>
		</div>
		{!! Form::close() !!}
		<div class="box-footer">
			<a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
		</div>
	@stop
	@section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
	@stop
	@section('js')
@stop