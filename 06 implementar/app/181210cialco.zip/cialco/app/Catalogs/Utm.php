<?php

namespace App\Catalogs;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Utm extends Model
{
    protected $table='utm';
    protected $primaryKey = 'utm_utm_id';

    const CREATED_AT = 'utm_fecha_inserta';
    const UPDATED_AT = 'utm_fecha_actualiza';

    use SoftDeletes;
    const DELETED_AT = 'utm_fecha_elimina';

    protected $append = [
        'texto_estado',
        'texto_estado_html'
    ];

    protected $fillable = [
        'utm_descripcion',
        'utm_orden',
        'utm_estado'
    ];
    public function utm()
    {
        return $this->belongsTo('App\Catalogs\Utm', 'utm_utm_id');
    }
    public function getTextoEstadoAttribute()
    {
        return ($this->utm_estado ? 'Activo' : 'Inactivo');
    }

    public function getTextoEstadoHtmlAttribute()
    {
        if ($this->utm_estado)
            return ('<span class="label label-success">' . $this->texto_estado . '</span>');
        return ('<span class="label label-default">' . $this->texto_estado . '</span>');
    }
}