<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreProductoRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'prd_codigo_producto' =>'required',
            'prd_nivel' =>'integer|required',
            'prd_nombre' =>'alpha|max:256|required',
            'prd_fecha_inicio' =>'date|required',
            'prd_estado' =>'required',
        ];
    }
    public function messages()
    {
        return [
            'prd_codigo_producto.required' => 'Código de Producto es requerido',
            'prd_nivel.required' => 'Nivel es requerido',
            'prd_fecha_inicio.required' => 'Fecha de Inicio es requerido',
            'prd_nivel.required' => 'Nivel es requerido',
            'afr_estado.required' => 'Estado es requerido',
        ];
    }
}