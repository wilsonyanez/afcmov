<?php

namespace App\Http\Controllers\Catalogs;

use App\Catalogs\Utm;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class UtmController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $results = Utm::orderBy('utm_orden', 'ASC')->get();
        return view('utm.index', ['results' => $results]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $order = [
            1 => 1,
            2 => 2,
            3 => 3,
            4 => 4,
            5 => 5,
            6 => 6,
            7 => 7,
            8 => 8,
            9 => 9,
            10 => 10,
        ];
        return view('utm.create', ['order' => $order]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            // INSERT
            $result = new  Utm;
            $result->utm_usuario_inserta = Auth::id();
            $result->fill($request->all())->save();

            Session::flash('flash_message', config('content.session.create'));
        } catch (\Exception $e) {
            Session::flash('error', config('content.session.error'));
            return back()->withInput();
        }
        return redirect()->route('utm.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $result = Utm::find($id);
        return view('utm.view', ['result' => $result]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $order = [
            1 => 1,
            2 => 2,
            3 => 3,
            4 => 4,
            5 => 5,
            6 => 6,
            7 => 7,
            8 => 8,
            9 => 9,
            10 => 10,
        ];
        $result = Utm::find($id);
        return view('utm.edit', ['result' => $result, 'order' => $order]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try {

            request()->validate([
                'utm_descripcion' => 'required',
                'utm_orden' => 'required',
                'utm_estado',
            ]);

            // UPDATE
            $result = Utm::find($id);
            $result->utm_usuario_actualiza = Auth::id();
            $result->fill($request->all())->update();

            Session::flash('flash_message', config('content.session.update'));
        } catch (\Exception $e) {
            Session::flash('error', content('content.session.error'));
            return back()->withInput();
        }

        return redirect()->route('utm.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // NOT REQUIRED
        /*
        $result=Utm::find($id);
        $result->utm_usuario_elimina=Auth::id();
        $result->delete();
        return redirect()->route('utm.index')->with('success');*/
    }
}