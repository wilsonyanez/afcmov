<?php

namespace App\Catalogs;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Frecuencia extends Model
{
    protected $table='frecuencia';
    protected $primaryKey = 'fre_frecuencia_id';

    const CREATED_AT = 'fre_fecha_inserta';
    const UPDATED_AT = 'fre_fecha_actualiza';

    use SoftDeletes;
    const DELETED_AT = 'fre_fecha_elimina';

    protected $append = [
        'texto_estado',
        'texto_estado_html'
    ];

    protected $fillable = [
        'fre_descripcion',
        'fre_estado',
        'fre_orden'
    ];
    public function frecuencia()
    {
        return $this->belongsTo('App\Catalogs\Frecuencia', 'fre_frecuencia_id');
    }
    public function getTextoEstadoAttribute()
    {
        return ($this->fre_estado ? 'Activo' : 'Inactivo');
    }

    public function getTextoEstadoHtmlAttribute()
    {
        if ($this->fre_estado)
            return ('<span class="label label-success">' . $this->texto_estado . '</span>');
        return ('<span class="label label-default">' . $this->texto_estado . '</span>');
    }
}