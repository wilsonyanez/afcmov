
<?php $__env->startSection('title', 'Cialco Productos'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Cialco Productos</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::open(['route' => 'cialco.cialcoproducto.store','method'=> 'post']); ?>

    <div class="box box-primary">
        <?php echo e(Form::hidden('cpr_cialco_id',$cialco->cia_cialco_id,['class'=>'form-control'])); ?>

        <div class="box-header with-border">
            <h3 class="box-title">Cialco Productos</h3>
        </div>
        <div class="box-body">
            <div class="row"> <!-- ROW 1 -->
                <div class="col-md-3">
					<div class="form-group">
						<label for="cpr_producto_id">Productos</label>
							<?php echo e(Form::select('cpr_producto_id', $productos, null, ['class'=>'form-control','placeholder' => 'Seleccione...'])); ?>

							<?php echo $__env->make('include.error_form_element',['name'=>'cpr_producto_id'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="cpr_ejercicio">Año</label>
							<?php echo e(Form::number('cpr_ejercicio',null,['class'=>'form-control', 'required' => 'required|number'])); ?>

							<?php echo $__env->make('include.error_form_element',['name'=>'cpr_ejercicio'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="cpr_periodo">Mes</label>
							<?php echo e(Form::number('cpr_periodo',null,['class'=>'form-control'])); ?>

							<?php echo $__env->make('include.error_form_element',['name'=>'cpr_periodo'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
            </div>
            <div class="row">  <!-- ROW 2 -->
                <div class="col-md-3">
					<div class="form-group">
						<label for="cpr_precio">Precio</label>
							<?php echo e(Form::number('cpr_precio',null,['class'=>'form-control'])); ?>

							<?php echo $__env->make('include.error_form_element',['name'=>'cpr_precio'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="cpr_unidad">Unidad (Kg)</label>
							<?php echo e(Form::text('cpr_unidad',null,['class'=>'form-control'])); ?>

							<?php echo $__env->make('include.error_form_element',['name'=>'cpr_unidad'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="cpr_fecha_inicio">Fecha Inicio</label></br>
							<?php echo e(Form::date('cpr_fecha_inicio', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yy-mm-dd", firstDay: 1});'))); ?>

							<?php echo $__env->make('include.error_form_element',['name'=>'cpr_fecha_inicio'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
            </div>
            <div class="row">  <!-- ROW 3 -->
                <div class="col-md-3">
					<div class="form-group">
						<label for="cpr_fecha_fin">Fecha Fin</label></br>
							<?php echo e(Form::date('cpr_fecha_fin', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yy-mm-dd", firstDay: 1});'))); ?>

							<?php echo $__env->make('include.error_form_element',['name'=>'cpr_fecha_fin'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="cpr_estado">Estado</label>
							<?php echo e(Form::select('cpr_estado',['1' => 'Activo', '0' => 'Inactivo'],null,['class'=>'form-control'])); ?>

					</div>
				</div>
            </div>
        </div>

        <div class="box-footer">
            <button type="submit" class="btn btn-primary">Crear</button>
        </div>
        <?php echo Form::close(); ?>

        <div class="box-footer">
            <a href="<?php echo e(URL::previous()); ?>" class="pull-right btn btn-default">Regresar</a>
        </div>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('css'); ?>
            <link rel="stylesheet" href="/css/admin_custom.css">
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>