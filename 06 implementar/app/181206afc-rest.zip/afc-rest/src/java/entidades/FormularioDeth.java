/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author david
 */
@Entity
@Table(name = "formulario_deth")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "FormularioDeth.findAll", query = "SELECT f FROM FormularioDeth f")
    , @NamedQuery(name = "FormularioDeth.findByIdFdeth", query = "SELECT f FROM FormularioDeth f WHERE f.idFdeth = :idFdeth")
    , @NamedQuery(name = "FormularioDeth.findByCodVar", query = "SELECT f FROM FormularioDeth f WHERE f.codVar = :codVar")
    , @NamedQuery(name = "FormularioDeth.findByOrden", query = "SELECT f FROM FormularioDeth f WHERE f.orden = :orden")
    , @NamedQuery(name = "FormularioDeth.findByVal01", query = "SELECT f FROM FormularioDeth f WHERE f.val01 = :val01")
    , @NamedQuery(name = "FormularioDeth.findByVal02", query = "SELECT f FROM FormularioDeth f WHERE f.val02 = :val02")
    , @NamedQuery(name = "FormularioDeth.findByVal03", query = "SELECT f FROM FormularioDeth f WHERE f.val03 = :val03")
    , @NamedQuery(name = "FormularioDeth.findByVal04", query = "SELECT f FROM FormularioDeth f WHERE f.val04 = :val04")
    , @NamedQuery(name = "FormularioDeth.findByVal05", query = "SELECT f FROM FormularioDeth f WHERE f.val05 = :val05")
    , @NamedQuery(name = "FormularioDeth.findByVal06", query = "SELECT f FROM FormularioDeth f WHERE f.val06 = :val06")
    , @NamedQuery(name = "FormularioDeth.findByVal07", query = "SELECT f FROM FormularioDeth f WHERE f.val07 = :val07")
    , @NamedQuery(name = "FormularioDeth.findByVal08", query = "SELECT f FROM FormularioDeth f WHERE f.val08 = :val08")
    , @NamedQuery(name = "FormularioDeth.findByVal09", query = "SELECT f FROM FormularioDeth f WHERE f.val09 = :val09")
    , @NamedQuery(name = "FormularioDeth.findByVal10", query = "SELECT f FROM FormularioDeth f WHERE f.val10 = :val10")
    , @NamedQuery(name = "FormularioDeth.findByVal11", query = "SELECT f FROM FormularioDeth f WHERE f.val11 = :val11")
    , @NamedQuery(name = "FormularioDeth.findByVal12", query = "SELECT f FROM FormularioDeth f WHERE f.val12 = :val12")
    , @NamedQuery(name = "FormularioDeth.findByVal13", query = "SELECT f FROM FormularioDeth f WHERE f.val13 = :val13")
    , @NamedQuery(name = "FormularioDeth.findByVal14", query = "SELECT f FROM FormularioDeth f WHERE f.val14 = :val14")
    , @NamedQuery(name = "FormularioDeth.findByVal15", query = "SELECT f FROM FormularioDeth f WHERE f.val15 = :val15")
    , @NamedQuery(name = "FormularioDeth.findByVal16", query = "SELECT f FROM FormularioDeth f WHERE f.val16 = :val16")
    , @NamedQuery(name = "FormularioDeth.findByClave", query = "SELECT f FROM FormularioDeth f WHERE f.clave = :clave")})
public class FormularioDeth implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_fdeth")
    private Integer idFdeth;
    @Size(max = 20)
    @Column(name = "cod_var")
    private String codVar;
    @Column(name = "orden")
    private Integer orden;
    @Size(max = 2147483647)
    @Column(name = "val01")
    private String val01;
    @Size(max = 2147483647)
    @Column(name = "val02")
    private String val02;
    @Size(max = 2147483647)
    @Column(name = "val03")
    private String val03;
    @Size(max = 2147483647)
    @Column(name = "val04")
    private String val04;
    @Size(max = 2147483647)
    @Column(name = "val05")
    private String val05;
    @Size(max = 2147483647)
    @Column(name = "val06")
    private String val06;
    @Size(max = 2147483647)
    @Column(name = "val07")
    private String val07;
    @Size(max = 2147483647)
    @Column(name = "val08")
    private String val08;
    @Size(max = 2147483647)
    @Column(name = "val09")
    private String val09;
    @Size(max = 2147483647)
    @Column(name = "val10")
    private String val10;
    @Size(max = 2147483647)
    @Column(name = "val11")
    private String val11;
    @Size(max = 2147483647)
    @Column(name = "val12")
    private String val12;
    @Size(max = 2147483647)
    @Column(name = "val13")
    private String val13;
    @Size(max = 2147483647)
    @Column(name = "val14")
    private String val14;
    @Size(max = 2147483647)
    @Column(name = "val15")
    private String val15;
    @Size(max = 2147483647)
    @Column(name = "val16")
    private String val16;
    @Size(max = 30)
    @Column(name = "clave")
    private String clave;
    @JoinColumn(name = "cod_form", referencedColumnName = "id_formulario")
    @ManyToOne
    private Formulario codForm;

    public FormularioDeth() {
    }

    public FormularioDeth(Integer idFdeth) {
        this.idFdeth = idFdeth;
    }

    public Integer getIdFdeth() {
        return idFdeth;
    }

    public void setIdFdeth(Integer idFdeth) {
        this.idFdeth = idFdeth;
    }

    public String getCodVar() {
        return codVar;
    }

    public void setCodVar(String codVar) {
        this.codVar = codVar;
    }

    public Integer getOrden() {
        return orden;
    }

    public void setOrden(Integer orden) {
        this.orden = orden;
    }

    public String getVal01() {
        return val01;
    }

    public void setVal01(String val01) {
        this.val01 = val01;
    }

    public String getVal02() {
        return val02;
    }

    public void setVal02(String val02) {
        this.val02 = val02;
    }

    public String getVal03() {
        return val03;
    }

    public void setVal03(String val03) {
        this.val03 = val03;
    }

    public String getVal04() {
        return val04;
    }

    public void setVal04(String val04) {
        this.val04 = val04;
    }

    public String getVal05() {
        return val05;
    }

    public void setVal05(String val05) {
        this.val05 = val05;
    }

    public String getVal06() {
        return val06;
    }

    public void setVal06(String val06) {
        this.val06 = val06;
    }

    public String getVal07() {
        return val07;
    }

    public void setVal07(String val07) {
        this.val07 = val07;
    }

    public String getVal08() {
        return val08;
    }

    public void setVal08(String val08) {
        this.val08 = val08;
    }

    public String getVal09() {
        return val09;
    }

    public void setVal09(String val09) {
        this.val09 = val09;
    }

    public String getVal10() {
        return val10;
    }

    public void setVal10(String val10) {
        this.val10 = val10;
    }

    public String getVal11() {
        return val11;
    }

    public void setVal11(String val11) {
        this.val11 = val11;
    }

    public String getVal12() {
        return val12;
    }

    public void setVal12(String val12) {
        this.val12 = val12;
    }

    public String getVal13() {
        return val13;
    }

    public void setVal13(String val13) {
        this.val13 = val13;
    }

    public String getVal14() {
        return val14;
    }

    public void setVal14(String val14) {
        this.val14 = val14;
    }

    public String getVal15() {
        return val15;
    }

    public void setVal15(String val15) {
        this.val15 = val15;
    }

    public String getVal16() {
        return val16;
    }

    public void setVal16(String val16) {
        this.val16 = val16;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public Formulario getCodForm() {
        return codForm;
    }

    public void setCodForm(Formulario codForm) {
        this.codForm = codForm;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idFdeth != null ? idFdeth.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof FormularioDeth)) {
            return false;
        }
        FormularioDeth other = (FormularioDeth) object;
        if ((this.idFdeth == null && other.idFdeth != null) || (this.idFdeth != null && !this.idFdeth.equals(other.idFdeth))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.FormularioDeth[ idFdeth=" + idFdeth + " ]";
    }
    
}
