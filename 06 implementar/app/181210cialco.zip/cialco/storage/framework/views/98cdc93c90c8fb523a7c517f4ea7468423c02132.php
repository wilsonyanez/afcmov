
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content_header'); ?>
   <h1>RQ19-WEB-HU085</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo Form::open(['route' => 'cialco.store', 'method' => 'post']); ?>

<div class="box box-primary">
  <div class="box-header with-border">
    <h1 class="box-title"><b>Registro de CIALCO</b></h1>
  </div>

  <div class="box-body">
    <div class="row"> <!-- ROW 1 -->
      <div class="col-md-4">
        <div class="form-group">
          <label for="cia_modalidad_id">Modalidad de Circuito</label>
          <?php echo e(Form::select('cia_modalidad_id', $modalidades, null, ['class'=>'form-control','placeholder' => 'Seleccione...'])); ?>

          <?php echo $__env->make('include.error_form_element',['name'=>'cia_modalidad_id'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <p>
            <?php echo $__env->make('include.ok_element', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <span class="label label-default">TODO: Trait after "OTRO" selection</span>
          </p>
        </div>
      </div>

      <div class="col-md-4">
        <div class="form-group">
          <label for="cia_permanencia_id">Datos del circuito</label>
          <?php echo e(Form::select('cia_permanencia_id', $permanencias, null, ['class'=>'form-control','placeholder' => 'Seleccione...'])); ?>

          <?php echo $__env->make('include.error_form_element',['name'=>'cia_permanencia_id'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <p>
            <?php echo $__env->make('include.ok_element', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <span class="label label-default">Tiene algun comportamiento dependiendo de la selección?</span>
          </p>
        </div>
      </div>

    </div> <!-- CLOSE ROW 1 -->

    <div class="row">
      <div class="col-md-12">
        <h4><b>Información CIALCO</b></h4>
        <hr/>
      </div>
    </div>

    <div class="row"><!--  ROW 2 -->
      <div class="col-md-6">
        <div class="form-group">
          <label for="cia_nombre">Nombre</label>
          <?php echo e(Form::text('cia_nombre',null,['class'=>'form-control', 'required' => 'required|alpha'])); ?>

          <?php echo $__env->make('include.error_form_element',['name'=>'cia_nombre'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <p><?php echo $__env->make('include.ok_element', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></p>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="cia_contacto">Contacto</label>
          <?php echo e(Form::text('cia_contacto',null,['class'=>'form-control'])); ?>

          <p><?php echo $__env->make('include.ok_element', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></p>
        </div>
      </div>
    </div>

    <div class="row"><!--  ROW 2 -->
      <div class="col-md-6">
        <div class="form-group">
          <label for="cia_correo_electronico">Correo electrónico</label>
          <?php echo e(Form::email('cia_correo_electronico',null,['class'=>'form-control', 'required' => 'required|email|unique:cialco'])); ?>

          <p><?php echo $__env->make('include.ok_element', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></p>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="cia_sitio_web">Sitio web</label>
          <?php echo e(Form::text('cia_sitio_web',null,['class'=>'form-control', 'required' => 'required|web|unique:cialco'])); ?>

          <p><?php echo $__env->make('include.ok_element', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></p>
        </div>
      </div>
    </div>

   

    <div class="row"><!--  ROW 3 -->
		<div class="col-md-6">
		<label for="cia_fecha_inicio">Fecha Inicio</label>
			<?php echo e(Form::text('cia_fecha_inicio', null, array('id' => 'datepicker'))); ?>

			<?php echo $__env->make('include.error_form_element',['name'=>'cia_fecha_inicio'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
		<div class="col-md-6">
		<label for="cia_fecha_fin">Fecha Fin</label>
			<?php echo e(Form::text('cia_fecha_fin', null, array('id' => 'datepicker'))); ?>

			<?php echo $__env->make('include.error_form_element',['name'=>'cia_fecha_fin'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
		<div class="col-md-6">
		<label for="cia_estado">Estado</label>
			<?php echo e(Form::select('cia_estado',['1' => 'Activo', '0' => 'Inactivo'],null,['class'=>'form-control'])); ?>

		</div>
    </div>

<div class="box-footer">
  <button type="submit" class="btn btn-primary">Almacenar</button>
</div>

</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>

<link rel="stylesheet" href="/css/admin_custom.css">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>