<?php

use Illuminate\Database\Seeder;

class DireccionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create();
        for($i=0 ; $i<200; $i++){
            \DB::table('direccion')->insert([
                'dir_sector'=>$faker->word,
                'dir_calle_principal'=>$faker->address,
                'dir_numero'=>$faker->numberBetween(500,1500),
                'dir_calle_secundaria'=>$faker->address,
                'dir_referencia'=>$faker->city,
                'dir_estado'=>$faker->numberBetween(0,1),
                'dir_consumidores'=>$faker->numberBetween(1,100),
                'dir_fecha_inicio'=>date_create('now UTC'),
                'dir_fecha_fin'=>date_create('now UTC'),
                'dir_fecha_inserta'=>date_create('now UTC'),
                'dir_fecha_actualiza'=>date_create('now UTC'),
                'dir_cialco_id' => $faker->numberBetween(1,100),
            ]);
        }
    }
}
