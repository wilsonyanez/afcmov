<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCialcoOfertaAgropecuariaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cialco_oferta_agropecuaria', function (Blueprint $table) {
            $table->increments('coa_cialco_oferta_agro_id');
            $table->text('coa_descripcion_otro')->nullable();

            // COLUMNAS DE CONTROL
            $table->boolean('coa_estado')->default(true);

            $table->date('coa_fecha_inicio')->nullable();
            $table->date('coa_fecha_fin')->nullable();

            $table->integer('coa_usuario_inserta')->unsigned()->nullable();
            $table->timestamp('coa_fecha_inserta')->nullable();

            $table->integer('coa_usuario_actualiza')->unsigned()->nullable();
            $table->timestamp('coa_fecha_actualiza')->nullable();

            $table->integer('coa_usuario_elimina')->unsigned()->nullable();
            $table->timestamp('coa_fecha_elimina')->nullable();

            // FOREINGS
            $table->unsignedInteger('coa_cialco_id');
            $table->foreign('coa_cialco_id')->references('cia_cialco_id')->on('cialco');

            // FOREINGS
            $table->unsignedInteger('coa_oferta_agropecuaria_id');
            $table->foreign('coa_oferta_agropecuaria_id')->references('ofa_oferta_agropecuaria_id')->on('oferta_agropecuaria');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cialco_oferta_agropecuaria');
    }
}
