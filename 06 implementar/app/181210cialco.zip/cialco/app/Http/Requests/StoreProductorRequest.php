<?php

namespace App\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;

class StoreProductorRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
          'pro_dispone_sello_afc' =>'required',
          'pro_identificacion_sello_afc',
          'pro_numero_cedula' =>'integer|digits:10|required',
          'pro_nombres' =>'alpha|max:256|required',
          'pro_apellidos' =>'alpha|max:256|required',
          'pro_genero' =>'required',
          'pro_fecha_nacimiento' =>'date|required',
          'pro_nacionalidad' =>'alpha|max:256|required',
          'pro_estado' =>'required',
        ];
    }
    public function messages()
    {
        return [
          'pro_dispone_sello_afc.required' =>'Dispone Sello Afc es requerido',
          'pro_identificacion_sello_afc.required' =>'Identificacion Sello Afc es requerido',
          'pro_numero_cedula.required' =>'Número Cédula es requerido',
          'pro_nombres.required' =>'Nombres es requerido',
          'pro_apellidos.required' =>'Apellidos es requerido',
          'pro_genero.required' =>'Genero es requerido',
          'pro_fecha_nacimiento' =>'Fecha Nacimiento required',
          'pro_nacionalidad' =>'Nacionalidad required',
          'pro_estado.required' => 'Estado es requerido',
        ];
    }
}