<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductorTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('productor', function (Blueprint $table) {
            $table->increments('pro_id');

            // Catalogos
            $table->integer('mod_id')->unsigned()->nullable();
            $table->foreign('mod_id')->references('mod_id')->on('modalidad');

            $table->integer('per_id')->unsigned()->nullable();
            $table->foreign('per_id')->references('per_id')->on('permanencia');
            // Ubicación catalogos

            $table->text('pro_nombre');
            $table->text('pro_localidad')->nullable();
            $table->text('pro_calle_principal')->nullable();
            $table->text('pro_calle_principal_numero')->nullable();
            $table->text('pro_calle_secundaria')->nullable();
            $table->text('pro_referencia')->nullable();

            $table->integer('pro_vinculado_hombres')->default(0);
            $table->integer('pro_vinculado_mujeres')->default(0);
            $table->integer('pro_vinculado_total')->default(0);
            $table->integer('pro_organizaciones')->default(0);

            $table->boolean('pro_estado')->default(true);
            $table->time('pro_horario_inicio')->nullable();
            $table->time('pro_horario_inicio')->nullable();

            $table->text('pro_dia')->nullable();
            $table->enum('pro_frecuencia',['diaria','semanal','quincenal','mensual']);

            $table->mediumText('pro_x_grados')->nullable();
            $table->mediumText('pro_x_minutos')->nullable();
            $table->mediumText('pro_x_segundos')->nullable();

            $table->mediumText('pro_y_grados')->nullable();
            $table->mediumText('pro_y_minutos')->nullable();
            $table->mediumText('pro_y_segundos')->nullable();

            $table->mediumText('pro_utm_norte')->nullable();
            $table->mediumText('pro_utm_sur')->nullable();

            $table->integer('pro_consumidores')->default(0);

            $table->timestamp('pro_fecha_creacion');
            $table->timestamp('pro_fecha_actualizacion');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('productor');
    }
}
