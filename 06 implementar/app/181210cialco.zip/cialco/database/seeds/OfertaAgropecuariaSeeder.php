<?php

use Illuminate\Database\Seeder;

class OfertaAgropecuariaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('oferta_agropecuaria')->insert([
            'ofa_descripcion' => 'Frutas',
            'ofa_orden' => 1,
            'ofa_fecha_inserta' => date_create('now UTC'),
            'ofa_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('oferta_agropecuaria')->insert([
            'ofa_descripcion' => 'Hortalizas',
            'ofa_orden' => 2,
            'ofa_fecha_inserta' => date_create('now UTC'),
            'ofa_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('oferta_agropecuaria')->insert([
            'ofa_descripcion' => 'Granos Frescos',
            'ofa_orden' => 3,
            'ofa_fecha_inserta' => date_create('now UTC'),
            'ofa_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('oferta_agropecuaria')->insert([
            'ofa_descripcion' => 'Granos Secos',
            'ofa_orden' => 4,
            'ofa_fecha_inserta' => date_create('now UTC'),
            'ofa_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('oferta_agropecuaria')->insert([
            'ofa_descripcion' => 'Cereales',
            'ofa_orden' => 5,
            'ofa_fecha_inserta' => date_create('now UTC'),
            'ofa_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('oferta_agropecuaria')->insert([
            'ofa_descripcion' => 'Lácteos',
            'ofa_orden' => 6,
            'ofa_fecha_inserta' => date_create('now UTC'),
            'ofa_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('oferta_agropecuaria')->insert([
            'ofa_descripcion' => 'Cárnicos',
            'ofa_orden' => 7,
            'ofa_fecha_inserta' => date_create('now UTC'),
            'ofa_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('oferta_agropecuaria')->insert([
            'ofa_descripcion' => 'Miel',
            'ofa_orden' => 8,
            'ofa_fecha_inserta' => date_create('now UTC'),
            'ofa_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('oferta_agropecuaria')->insert([
            'ofa_descripcion' => 'Elaborados',
            'ofa_orden' => 9,
            'ofa_fecha_inserta' => date_create('now UTC'),
            'ofa_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('oferta_agropecuaria')->insert([
            'ofa_descripcion' => 'Alimentos procesados de manera artesanal',
            'ofa_orden' => 10,
            'ofa_fecha_inserta' => date_create('now UTC'),
            'ofa_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('oferta_agropecuaria')->insert([
            'ofa_descripcion' => 'Pescados y mariscos',
            'ofa_orden' => 11,
            'ofa_fecha_inserta' => date_create('now UTC'),
            'ofa_fecha_actualiza' => date_create('now UTC')
        ]);
    }
}