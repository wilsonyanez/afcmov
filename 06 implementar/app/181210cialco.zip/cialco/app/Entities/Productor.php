<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Productor extends Model
{
    protected $table = 'productor';
    protected $primaryKey = 'pro_productor_id';
    const CREATED_AT = 'pro_fecha_inserta';
    const UPDATED_AT = 'pro_fecha_actualiza';

    use SoftDeletes;
    const DELETED_AT = 'pro_fecha_elimina';

    protected $append = [
	    'texto_dispone_sello_afc',
        'texto_dispone_sello_afc_html',
	    'texto_genero',
        'texto_genero_html',
        'texto_estado',
        'texto_estado_html'
    ];

    public function cialco()
    {
        return $this->belongsTo('App\Entities\Cialco', 'pro_cialco_id');
    }

    public function getTextoDisponeSelloAfcAttribute()
    {
        return ($this->pro_dispone_sello_afc ? 'SI' : 'NO');
    }

    public function getTextoDisponeSelloAfcHtmlAttribute()
    {
        if ($this->pro_dispone_sello_afc)
            return ('<span class="label label-success">' . $this->texto_dispone_sello_afc . '</span>');
        return ('<span class="label label-default">' . $this->texto_dispone_sello_afc . '</span>');
    }

    public function getTextoGeneroAttribute()
    {
        return ($this->pro_genero ? 'Masculino' : 'Femenino');
    }

    public function getTextoGeneroHtmlAttribute()
    {
        if ($this->pro_genero)
            return ('<span class="label label-success">' . $this->texto_genero . '</span>');
        return ('<span class="label label-default">' . $this->texto_genero . '</span>');
    }

    public function getTextoEstadoAttribute()
    {
        return ($this->pro_estado ? 'Activo' : 'Inactivo');
    }

    public function getTextoEstadoHtmlAttribute()
    {
        if ($this->pro_estado)
            return ('<span class="label label-success">' . $this->texto_estado . '</span>');
        return ('<span class="label label-default">' . $this->texto_estado . '</span>');
    }

    protected $fillable = [
        'pro_productor_id',
        'pro_cialco_id',
        'pro_dispone_sello_afc',
        'pro_identificacion_sello_afc',
        'pro_numero_cedula',
        'pro_nombres',
        'pro_apellidos',
        'pro_genero',
        'pro_fecha_nacimiento',
        'pro_nacionalidad',
        'pro_fecha_inicio',
        'pro_fecha_fin',
        'pro_estado',
    ];
}
