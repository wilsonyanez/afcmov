<?php

namespace App\Http\Controllers\Catalogs;

use App\Catalogs\Producto;
use App\Http\Requests\StoreProductoRequest;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;

class ProductoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $results = Producto::orderBy('prd_codigo_producto','ASC')->get();
        return view('producto.index', ['results' => $results]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $order = Producto::orderBy('prd_codigo_producto','ASC')->get();
        return view('producto.create', ['order' => $order]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreProductoRequest $request)
    {
        try {
            // INSERT
            $result = new Producto;
            $result->prd_usuario_inserta = Auth::id();
            $result->fill($request->all())->save();

            Session::flash('flash_message', config('content.session.create'));
        } catch (\Exception $e) {
            Session::flash('error', config('content.session.error'));
            return back()->withInput();
        }
        return redirect()->route('producto.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $result = Producto::find($id);
        return view('producto.show', ['result' => $result]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $order = Producto::orderBy('prd_codigo_producto','ASC')->get();
        $result = Producto::find($id);
        return view('producto.edit', ['result' => $result, 'order' => $order]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try {
            request()->validate([
              'prd_codigo_producto' => 'required',
              'prd_nivel' => 'required',
              'prd_nombre' => 'required',
              'prd_fecha_inicio' => 'required',
            ]);
			
            // UPDATE
            $result = Producto::find($id);
            $result->prd_usuario_actualiza = Auth::id();
            $result->fill($request->all())->update();

            Session::flash('flash_message', config('content.session.update'));
        } catch (\Exception $e) {
            Session::flash('error', content('content.session.error'));
            return back()->withInput();
        }
        return redirect()->route('producto.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // NOT REQUIRED
        /*$result=Producto::find($id);
        $result->prd_usuario_elimina=Auth::id();
        $result->delete();
         return redirect()->route('producto.index')->with('success'); */
    }
}