
<?php $__env->startSection('title', 'Cialco'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Cialco</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="box box-primary"> <!-- Ini Clase BOX -->
        <div class="box-header with-border">
            <h2 class="page-header">
                Información
                    <a href="<?php echo e(URL::previous()); ?>" class="pull-right btn btn-default">Regresar</a>
            </h2>

            <div class="row invoice-info">
                <div class="col-md-2">
                    <address>
                        <strong>Modalidad</strong><br>
                        <?php echo e($result->modalidad->mod_descripcion); ?><br>
                        <br/>
                        <strong>Permanencia</strong><br>
                        <?php echo e($result->permanencia->per_descripcion); ?><br>
                    </address>
                </div>
                <div class="col-md-3">
                    <address>
                        <strong><?php echo e($result->cia_nombre); ?></strong><br>
                        <?php echo e($result->cia_contacto); ?><br>
                        <?php echo e($result->cia_correo_electronico); ?><br>
                        <?php echo e($result->cia_sitio_web); ?><br>
                    </address>
                </div>
                <div class="col-md-2">
                    <address>
					    <strong>Vigencia</strong><br>
                        <strong>Fecha de inicio:</strong><br>
						<?php echo e($result->fecha_inicio); ?><br>
                        <strong>Fecha de fin:</strong><br>
						<?php echo e($result->fecha_fin); ?><br>
						<strong>Estado:</strong><br>
                        <?php echo $result->texto_estado_html; ?><br>
                    </address>
                </div>
                <div class="col-md-2">
                    <address>
                        <strong>Localización</strong><br>
                        PICHINCHA<br>
                        QUITO<br>
                        Eloy Alfaro<br>
                    </address>
                </div>
                <div class="col-md-3">
                    <address>
                         <strong>Productores vinculados</strong><br>
                         Hombres #<br>
                         Mujeres #<br>
                         Total #<br>
                         Org. Participantes #<br>
                         <br/>
                          <strong>Consumidores vinculados</strong><br>
                          Número #<br>
                         <span class="label label-primary">En desarrollo</span>
                    </address>
                </div>
            </div>

            <div class="row">
                <div class="col-md-8 table-responsive">
                    <h2 class="page-header">Representantes</h2>
                    <table class="table table-striped">
                        <tr>
							<th>ID</th>
							<th>Identificación</th>
							<th>Contacto</th>
							<th>Correo electrónico</th>
							<th>Fecha Incio</th>
							<th>Fecha Fin</th>
							<th>Estado</th>
							<th>Acciones</th>
                        </tr>
                        <?php $__currentLoopData = $result->representantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
								<td><?php echo e($key+1); ?></td>
								<td><?php echo e($item->rep_identificacion); ?></td>
								<td><?php echo e($item->rep_contacto); ?></td>
								<td><?php echo e($item->rep_correo_electronico); ?></td>
								<td><?php echo e($item->rep_fecha_inicio); ?></td>
								<td><?php echo e($item->rep_fecha_fin); ?></td>
								<td><?php echo $item->texto_estado_html; ?></td>
                                <td>
                                   <a  class="btn btn-block btn-danger btn-xs" href="<?php echo e(route('cialco.representante.destroy',['id'=>$item->rep_representante_id])); ?>">Eliminar</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <p><span class="label label-primary">Viene de tabla REPRESENTANTES</span></p>
                    <a class="btn btn-default pull-right" href="<?php echo e(route('cialco.representante.create',['id'=>$result->cia_cialco_id])); ?>">Nuevo Representante</a>
                </div>
             </div>

             <div class="row">
                <div class="col-md-12 table-responsive">
                    <h2 class="page-header">Direcciones</h2>
                    <table class="table table-striped">
						<tr>
							<th>ID</th>
							<th>Sector</th>
							<th>Principal</th>
							<th>Número</th>
							<th>Secundaria</th>
							<th>Referencia</th>
							<th>Estimado Consumidores</th>
							<th>Fecha Incio</th>
							<th>Fecha Fin</th>
							<th>Estado</th>
							<th>Acciones</th>
						</tr>
						<?php $__currentLoopData = $result->direcciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($key+1); ?></td>
								<td><?php echo e($item->dir_sector); ?></td>
								<td><?php echo e($item->dir_calle_principal); ?></td>
								<td><?php echo e($item->dir_numero); ?></td>
								<td><?php echo e($item->dir_calle_secundaria); ?></td>
								<td><?php echo e($item->dir_referencia); ?></td>
								<td><?php echo e($item->dir_consumidores); ?></td>
								<td><?php echo e($item->dir_fecha_inicio); ?></td>
								<td><?php echo e($item->dir_fecha_fin); ?></td>
								<td><?php echo $item->texto_estado_html; ?></td>
								<td>
								<a  class="btn btn-block btn-danger btn-xs" href="<?php echo e(route('cialco.direccion.destroy',['id'=>$item->dir_direccion_id])); ?>">Eliminar</a>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <p><span class="label label-primary">Viene de tabla DIRECCIONES</span></p>
                    <a class="btn btn-default pull-right " href="<?php echo e(route('cialco.direccion.create',['id'=>$result->cia_cialco_id])); ?>">Nueva Dirección</a>
                </div>
             </div>

             <div class="row">
				<div class="col-md-12 table-responsive">
					<h2 class="page-header">Coordenadas Geográficas</h2>
					 <table class="table table-striped">
						<tr>
							<th>ID</th>
							<th>Posición X</th>
							<th>Posición Y</th>
							<th>Posición Z</th>
							<th>UTM</th>
							<th>Fecha Incio</th>
							<th>Fecha Fin</th>
							<th>Estado</th>
							<th>Acciones</th>
						</tr>
						<?php $__currentLoopData = $result->coordenadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($item->coo_coordenada_id); ?></td>
								<td><?php echo e($item->coo_posicion_x); ?></td>
								<td><?php echo e($item->coo_posicion_y); ?></td>
								<td><?php echo e($item->coo_posicion_z); ?></td>
								<td><?php echo e($item->utm->utm_descripcion); ?></td>
								<td><?php echo e($item->coo_fecha_inicio); ?></td>
								<td><?php echo e($item->coo_fecha_fin); ?></td>
								<td><?php echo $item->texto_estado_html; ?></td>
								<td>
								<a  class="btn btn-block btn-danger btn-xs" href="<?php echo e(route('cialco.coordenada.destroy',['id'=>$item->coo_coordenada_id])); ?>">Eliminar</a>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table>
					<p><span class="label label-primary">Viene de tabla COORDENADAS</span></p>
					<a class="btn btn-default pull-right " href="<?php echo e(route('cialco.coordenada.create',['id'=>$result->cia_cialco_id])); ?>">Nueva Coordenada</a>
				</div>
             </div>

             <div class="row">
				<div class="col-md-12 table-responsive">
					<h2 class="page-header">Frecuencias</h2>
					 <table class="table table-striped">
						<tr>
							<th>ID</th>
							<th>Hora Inicio</th>
							<th>Hora Fin</th>
							<th>Días</th>
						    <th>Descripción</th>
							<th>Frecuencia</th>
							<th>Fecha Incio</th>
							<th>Fecha Fin</th>
							<th>Estado</th>
							<th>Acciones</th>
						</tr>
						<?php $__currentLoopData = $result->frecuencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($item->cfr_cialco_frecuencia_id); ?></td>
								<td><?php echo e($item->cfr_hora_inicio); ?></td>
								<td><?php echo e($item->cfr_hora_fin); ?></td>
								<td><?php echo e($item->cfr_dias); ?></td>
								<td><?php echo e($item->cfr_descripcion); ?></td>
								<td><?php echo e($item->frecuencia->fre_descripcion); ?></td>
								<td><?php echo e($item->cfr_fecha_inicio); ?></td>
								<td><?php echo e($item->cfr_fecha_fin); ?></td>
								<td><?php echo $item->texto_estado_html; ?></td>

								<td>
									<a  class="btn btn-block btn-danger btn-xs" href="<?php echo e(route('cialco.frecuencia.destroy',['id'=>$item->cfr_cialco_frecuencia_id])); ?>">Eliminar</a>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table>
					<p><span class="label label-primary">Viene de tabla FRECUENCIAS</span></p>
					<a class="btn btn-default pull-right " href="<?php echo e(route('cialco.frecuencia.create',['id'=>$result->cia_cialco_id])); ?>">Nueva Frecuencia</a>
				</div>
             </div>

             <div class="row">
				<div class="col-md-12 table-responsive">
					<h2 class="page-header">Ofertas Agropecuarias</h2>
					<table class="table table-striped">
						<tr>
						  <th>ID</th>
						  <th>Descripción</th>
						  <th>Oferta Agropecuaria</th>
						  <th>Fecha Inicio</th>
						  <th>Fecha Fin</th>
						  <th>Estado</th>
						  <th>Acciones</th>
						</tr>
						<?php $__currentLoopData = $result->ofertasagropecuarias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($item->coa_cialco_oferta_agro_id); ?></td>
							<td><?php echo e($item->coa_descripcion_otro); ?></td>
							<td><?php echo e($item->ofertaagropecuaria->ofa_descripcion); ?></td>
							<td><?php echo e($item->coa_fecha_inicio); ?></td>
							<td><?php echo e($item->coa_fecha_fin); ?></td>
							<td><?php echo $item->texto_estado_html; ?></td>
							<td>
								<a class="btn btn-block btn-danger btn-xs" href="<?php echo e(route('cialco.ofertaagropecuaria.destroy',['id'=>$item->coa_cialco_oferta_agro_id])); ?>">Eliminar</a>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 					</table>
					<p><span class="label label-primary">Viene de tabla OFERTAS AGROPECUARIAS</span></p>
					<a class="btn btn-default pull-right " href="<?php echo e(route('cialco.ofertaagropecuaria.create',['id'=>$result->cia_cialco_id])); ?>">Nueva Oferta Agropecuaria</a>
				</div>
             </div>

             <div class="row">
				<div class="col-md-12 table-responsive">
					<h2 class="page-header">Organizaciones</h2>
					<table class="table table-striped">
						<tr>
						  <th>ID</th>
						  <th>Hecho Derecho</th>
						  <th>RUC</th>
						  <th>Razón Social</th>
						  <th>Registro SEPS</th>
						  <th>Acreditado MAG</th>
						  <th>Nro Productores Total</th>
						  <th>Nro Productores Hombres</th>
						  <th>Nro Productores Mujeres</th>
						  <th>Fecha Inicio</th>
						  <th>Fecha Fin</th>
						  <th>Estado</th>
						  <th>Fecha Creación</th>
						  <th>Acciones</th>
						</tr>
						<?php $__currentLoopData = $result->organizaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($item->org_organizacion_id); ?></td>
							<td><?php echo $item->texto_hecho_derecho_html; ?></td>
							<td><?php echo e($item->org_ruc); ?></td>
							<td><?php echo e($item->org_razon_social); ?></td>
							<td><?php echo $item->texto_registro_seps_html; ?></td>
							<td><?php echo $item->texto_acreditado_mag_html; ?></td>
							<td><?php echo e($item->org_nro_productores_total); ?></td>
							<td><?php echo e($item->org_nro_productores_hombres); ?></td>
							<td><?php echo e($item->org_nro_productores_mujeres); ?></td>
							<td><?php echo e($item->org_fecha_inicio); ?></td>
							<td><?php echo e($item->org_fecha_fin); ?></td>
							<td><?php echo $item->texto_estado_html; ?></td>
                            <td><?php echo e($item->org_fecha_inserta); ?></td>
							<td>
								<a class="btn btn-block btn-danger btn-xs" href="<?php echo e(route('cialco.organizacion.destroy',['id'=>$item->org_cialco_id])); ?>">Eliminar</a>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 					</table>
					<p><span class="label label-primary">Viene de tabla ORGANIZACIONES</span></p>
					<a class="btn btn-default pull-right " href="<?php echo e(route('cialco.organizacion.create',['id'=>$result->cia_cialco_id])); ?>">Nueva Organización</a>
				</div>
             </div>

             <div class="row">
				<div class="col-md-12 table-responsive">
					<h2 class="page-header">Productores</h2>
					<table class="table table-striped">
						<tr>
						  <th>ID</th>
						  <th>Dispone Sello AFC</th>
						  <th>Identificacion Sello AFC</th>
						  <th>Número Cédula</th>
						  <th>Nombres</th>
						  <th>Apellidos</th>
						  <th>Género</th>
						  <th>Fecha Nacimiento</th>
						  <th>Nacionalidad</th>
						  <th>Fecha Inicio</th>
						  <th>Fecha Fin</th>
						  <th>Estado</th>
						  <th>Fecha Creación</th>
						  <th>Acciones</th>
						</tr>
						<?php $__currentLoopData = $result->productores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
						  <td><?php echo e($item->pro_productor_id); ?></td>
						  <td><?php echo $item->texto_dispone_sello_afc_html; ?></td>
						  <td><?php echo e($item->pro_identificacion_sello_afc); ?></td>
						  <td><?php echo e($item->pro_numero_cedula); ?></td>
						  <td><?php echo e($item->pro_nombres); ?></td>
						  <td><?php echo e($item->pro_apellidos); ?></td>
						  <td><?php echo $item->texto_genero_html; ?></td>
						  <td><?php echo e($item->pro_fecha_nacimiento); ?></td>
						  <td><?php echo e($item->pro_nacionalidad); ?></td>
						  <td><?php echo e($item->pro_fecha_inicio); ?></td>
						  <td><?php echo e($item->pro_fecha_fin); ?></td>
						  <td><?php echo $item->texto_estado_html; ?></td>
						  <td><?php echo e($item->pro_fecha_inserta); ?></td>
							<td>
								<a class="btn btn-block btn-danger btn-xs" href="<?php echo e(route('cialco.productor.destroy',['id'=>$item->pro_cialco_id])); ?>">Eliminar</a>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 					</table>
					<p><span class="label label-primary">Viene de tabla PRODUCTORES</span></p>
					<a class="btn btn-default pull-right " href="<?php echo e(route('cialco.productor.create',['id'=>$result->cia_cialco_id])); ?>">Nuevo Productor</a>
				</div>
             </div>

             <div class="row">
				<div class="col-md-12 table-responsive">
					<h2 class="page-header">Interinstitucional</h2>
					<table class="table table-striped">
						<tr>
						  <th>ID</th>
						  <th>Accion Fortalecimiento</th>
						  <th>Apoyo Institucional</th>
						  <th>Provincial</th>
						  <th>Cantonal</th>
						  <th>Parroquial</th>
						  <th>Otro</th>
						  <th>Descripción</th>
						  <th>Fecha Inicio</th>
						  <th>Fecha Fin</th>
						  <th>Estado</th>
						  <th>Fecha Creación</th>
						  <th>Acciones</th>
						</tr>
						<?php $__currentLoopData = $result->interinstitucionales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
						  <td><?php echo e($item->int_cialco_interins_id); ?></td>
						  <td><?php echo e($item->accionfortalecimiento->afr_descripcion); ?></td>
						  <td><?php echo e($item->apoyoinstitucional->ain_descripcion); ?></td>
						  <td><?php echo $item->texto_provincial_html; ?>   </td>
						  <td><?php echo $item->texto_cantonal_html; ?>   </td>
						  <td><?php echo $item->texto_parroquial_html; ?>   </td>
						  <td><?php echo $item->texto_otro_html; ?></td>
						  <td><?php echo e($item->int_descripcion); ?></td>
						  <td><?php echo e($item->int_fecha_inicio); ?></td>
						  <td><?php echo e($item->int_fecha_fin); ?></td>
						  <td><?php echo $item->texto_estado_html; ?></td>
						  <td><?php echo e($item->int_fecha_inserta); ?></td>
							<td>
								<a class="btn btn-block btn-danger btn-xs" href="<?php echo e(route('cialco.cialcointerinstitucional.destroy',['id'=>$item->int_cialco_id])); ?>">Eliminar</a>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 					</table>
					<p><span class="label label-primary">Viene de tabla CIALCO INTERINSTITUCIONAL</span></p>
					<a class="btn btn-default pull-right " href="<?php echo e(route('cialco.cialcointerinstitucional.create',['id'=>$result->cia_cialco_id])); ?>">Nuevo apoyo interinstitucional</a>
				</div>
             </div>

             <div class="row">
				<div class="col-md-12 table-responsive">
					<h2 class="page-header">Productos</h2>
					<table class="table table-striped">
						<tr>
						  <th>ID</th>
						  <th>Año</th>
						  <th>Mes</th>
						  <th>Precio</th>
						  <th>Unidad</th>
						  <th>Fecha Inicio</th>
						  <th>Fecha Fin</th>
						  <th>Estado</th>
						  <th>Acciones</th>
						</tr>
						<?php $__currentLoopData = $result->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($item->producto->prd_nombre); ?></td>
							<td><?php echo e($item->cpr_ejercicio); ?></td>
							<td><?php echo e($item->cpr_periodo); ?></td>
							<td><?php echo e($item->cpr_precio); ?></td>
							<td><?php echo $item->texto_unidad_html; ?></td>
							<td><?php echo e($item->cpr_fecha_inicio); ?></td>
							<td><?php echo e($item->cpr_fecha_fin); ?></td>
							<td><?php echo $item->texto_estado_html; ?></td>
							<td>
								<a class="btn btn-block btn-danger btn-xs" href="<?php echo e(route('cialco.cialcoproducto.destroy',['id'=>$item->cpr_producto_id])); ?>">Eliminar</a>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 					</table>
					<p><span class="label label-primary">Viene de tabla PRODUCTOS</span></p>
					<a class="btn btn-default pull-right " href="<?php echo e(route('cialco.cialcoproducto.create',['id'=>$result->cia_cialco_id])); ?>">Nuevo Producto</a>
				</div>
             </div>


             <div class="row">
				<div class="col-md-12 table-responsive">
					<h2 class="page-header">Montos de Ventas</h2>
					<table class="table table-striped">
						<tr>
						  <th>ID</th>
						  <th>Año</th>
						  <th>Mes</th>
						  <th>Monto</th>
						  <th>Fecha Inicio</th>
						  <th>Fecha Fin</th>
						  <th>Estado</th>
						  <th>Acciones</th>
						</tr>
						<?php $__currentLoopData = $result->montosventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($item->cmv_cialco_monto_venta_id); ?></td>
							<td><?php echo e($item->cmv_ejercicio); ?></td>
							<td><?php echo e($item->cmv_periodo); ?></td>
							<td><?php echo e($item->cmv_monto); ?></td>
							<td><?php echo e($item->cmv_fecha_inicio); ?></td>
							<td><?php echo e($item->cmv_fecha_fin); ?></td>
							<td><?php echo $item->texto_estado_html; ?></td>
							<td>
								<a class="btn btn-block btn-danger btn-xs" href="<?php echo e(route('cialco.cialcomontoventa.destroy',['id'=>$item->cmv_cialco_monto_venta_id])); ?>">Eliminar</a>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 					</table>
					<p><span class="label label-primary">Viene de tabla MONTOS DE VENTAS</span></p>
					<a class="btn btn-default pull-right " href="<?php echo e(route('cialco.cialcomontoventa.create',['id'=>$result->cia_cialco_id])); ?>">Nuevo Monto de Venta</a>
				</div>
             </div>

			 
            <div class="row">
                <br/><hr/>
            </div>

            <div class="row no-print">
				<div class="col-xs-12">
					<a href="invoice-print.html" target="_blank" class="btn btn-default"><i class="fa fa-print"></i> Print</a>
				   
				   
				</div>
			</div>
        </div>
	<div class="box-footer">
	</div>  <!-- Fin Clase BOX -->
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('css'); ?>
		<link rel="stylesheet" href="/css/admin_custom.css">
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>