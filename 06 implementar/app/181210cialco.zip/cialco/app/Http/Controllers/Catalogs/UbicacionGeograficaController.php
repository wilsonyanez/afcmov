<?php

namespace App\Http\Controllers\Catalogs;

use App\Catalogs\UbicacionGeografica;
use App\Http\Requests\StoreUbicacionGeograficaRequest;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;

class UbicacionGeograficaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $results = UbicacionGeografica::orderBy('uge_codigo_ubicacion','ASC')->get();
        return view('ubicaciongeografica.index', ['results' => $results]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $order = UbicacionGeografica::orderBy('uge_codigo_ubicacion','ASC')->get();
        return view('ubicaciongeografica.create', ['order' => $order]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreUbicacionGeograficaRequest $request)
    {
        try {
            // INSERT
            $result = new UbicacionGeografica;
            $result->uge_usuario_inserta = Auth::id();
            $result->fill($request->all())->save();

            Session::flash('flash_message', config('content.session.create'));
        } catch (\Exception $e) {
            Session::flash('error', config('content.session.error'));
            return back()->withInput();
        }
        return redirect()->route('ubicaciongeografica.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $result = UbicacionGeografica::find($id);
        return view('ubicaciongeografica.show', ['result' => $result]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $order = UbicacionGeografica::orderBy('uge_codigo_ubicacion','ASC')->get();
        $result = UbicacionGeografica::find($id);
        return view('ubicaciongeografica.edit', ['result' => $result, 'order' => $order]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try {
            request()->validate([
              'uge_codigo_ubicacion' => 'required',
              'uge_nivel' => 'required',
              'uge_nombre' => 'required',
              'uge_padre_ubicacion' => 'required',
            ]);
			
            // UPDATE
            $result = UbicacionGeografica::find($id);
            $result->uge_usuario_actualiza = Auth::id();
            $result->fill($request->all())->update();

            Session::flash('flash_message', config('content.session.update'));
        } catch (\Exception $e) {
            Session::flash('error', content('content.session.error'));
            return back()->withInput();
        }
        return redirect()->route('ubicaciongeografica.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // NOT REQUIRED
        /*$result=UbicacionGeografica::find($id);
        $result->uge_usuario_elimina=Auth::id();
        $result->delete();
         return redirect()->route('ubicaciongeografica.index')->with('success'); */
    }
}