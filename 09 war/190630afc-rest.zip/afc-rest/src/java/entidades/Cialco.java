/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Wilson Yánez
 */
@Entity
@Table(name = "cialco")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Cialco.findAll", query = "SELECT o FROM Cialco o")
    , @NamedQuery(name = "Cialco.findByIdCialco", query = "SELECT o FROM Cialco o WHERE o.idCialco = :idCialco")
    , @NamedQuery(name = "Cialco.findByNumero", query = "SELECT o FROM Cialco o WHERE o.numero = :numero")
    , @NamedQuery(name = "Cialco.findByFecha", query = "SELECT o FROM Cialco o WHERE o.fecha = :fecha")
    , @NamedQuery(name = "Cialco.findByReferencia", query = "SELECT o FROM Cialco o WHERE o.referencia = :referencia")
    , @NamedQuery(name = "Cialco.findByEstadoP", query = "SELECT o FROM Cialco o WHERE o.estadoP = :estadoP")
    , @NamedQuery(name = "Cialco.findByEstadoT", query = "SELECT o FROM Cialco o WHERE o.estadoT = :estadoT")
    , @NamedQuery(name = "Cialco.findByClave", query = "SELECT o FROM Cialco o WHERE o.clave = :clave")
    , @NamedQuery(name = "Cialco.findByLongUsuario", query = "SELECT o FROM Cialco o WHERE o.longUsuario = :longUsuario")
    , @NamedQuery(name = "Cialco.findByLongIdentificador", query = "SELECT o FROM Cialco o WHERE o.longIdentificador = :longIdentificador")
})
public class Cialco implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_cialco")
    private Integer idCialco;
    @Size(max = 50)
    @Column(name = "numero")
    private String numero;
    @Column(name = "fecha")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fecha;
    @Size(max = 200)
    @Column(name = "referencia")
    private String referencia;
    @Size(max = 1)
    @Column(name = "estado_p")
    private String estadoP;
    @Size(max = 1)
    @Column(name = "estado_t")
    private String estadoT;
    @Size(max = 30)
    @Column(name = "clave")
    private String clave;
    @Column(name = "cod_usuario")
    private String codUsuario;
    @Column(name = "long_usuario")
    private Integer longUsuario;
    @Column(name = "long_identificador")
    private Integer longIdentificador;

    public Cialco() {
    }

    public Cialco(Integer idCialco) {
        this.idCialco = idCialco;
    }

    public Integer getIdCialco() {
        return idCialco;
    }

    public void setIdCialco(Integer idCialco) {
        this.idCialco = idCialco;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public String getEstadoP() {
        return estadoP;
    }

    public void setEstadoP(String estadoP) {
        this.estadoP = estadoP;
    }

    public String getEstadoT() {
        return estadoT;
    }

    public void setEstadoT(String estadoT) {
        this.estadoT = estadoT;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(String codUsuario) {
        this.codUsuario = codUsuario;
    }

    public Integer getLongUsuario() {
        return longUsuario;
    }

    public void setLongUsuario(Integer longUsuario) {
        this.longUsuario = longUsuario;
    }

    public Integer getLongIdentificador() {
        return longIdentificador;
    }

    public void setLongIdentificador(Integer longIdentificador) {
        this.longIdentificador = longIdentificador;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idCialco != null ? idCialco.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Cialco)) {
            return false;
        }
        Cialco other = (Cialco) object;
        if ((this.idCialco == null && other.idCialco != null) || (this.idCialco != null && !this.idCialco.equals(other.idCialco))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Cialco[ idCialco=" + idCialco + " ]";
    }
    
}
