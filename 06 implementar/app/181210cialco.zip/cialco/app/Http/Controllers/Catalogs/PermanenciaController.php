<?php

namespace App\Http\Controllers\Catalogs;

use App\Catalogs\Permanencia;

;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class PermanenciaController extends Controller
{
    public function index()
    {
        $results = Permanencia::orderBy('per_orden','ASC')->get();
        return view('permanencia.index', ['results' => $results]);
    }

    public function show($id)
    {

        $result = Permanencia::find($id);
        return view('permanencia.view', ['result' => $result]);
    }

    public function edit($id)
    {
        $order = [
            1 => 1,
            2 => 2,
            3 => 3,
            4 => 4,
            5 => 5,
            6 => 6,
            7 => 7,
            8 => 8,
            9 => 9,
            10 => 10,
        ];
        $result = Permanencia::find($id);
        return view('permanencia.edit', ['result' => $result, 'order' => $order]);
    }

    public function create()
    {
        $order = [
            1 => 1,
            2 => 2,
            3 => 3,
            4 => 4,
            5 => 5,
            6 => 6,
            7 => 7,
            8 => 8,
            9 => 9,
            10 => 10,
        ];
        return view('permanencia.create', ['order' => $order]);

    }

    public function store(Request $request)
    {
        try {
            // INSERT
            $result = new Permanencia;
            $result->per_usuario_inserta = Auth::id();
            $result->fill($request->all())->save();

            Session::flash('flash_message', config('content.session.create'));
        } catch (\Exception $e) {
            Session::flash('error', config('content.session.error'));
            return back()->withInput();
        }

        return redirect()->route('permanencia.index');
    }

    public function update(Request $request, $id)
    {
        try {
            request()->validate([
                'per_descripcion' => 'required',
                'per_estado' => 'required',
                'per_orden' => 'required',
            ]);

            // UPDATE
            $result = Permanencia::find($id);
            $result->per_usuario_actualiza = Auth::id();
            $result->fill($request->all())->update();

            Session::flash('flash_message', config('content.session.update'));
        } catch (\Exception $e) {
            Session::flash('error', content('content.session.error'));
            return back()->withInput();
        }
        return redirect()->route('permanencia.index');
    }

    public function destroy($id)
    {
        // NOT REQUIRED
        /* $result=Permanencia::find($id);
         $result->per_usuario_elimina=Auth::id();
         $result->delete();

         return redirect()->route('permanencia.index')->with('success');*/
    }
}