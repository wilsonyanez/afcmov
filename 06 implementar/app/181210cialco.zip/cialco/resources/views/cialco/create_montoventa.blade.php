@extends('adminlte::page')
@section('title', 'Nuevo Monto de Venta por Cialco')
@section('content_header')
    <h1>Monto de Venta por Cialco</h1>
@stop
@section('content')
  @include('include.alert')
  {!! Form::open(['route' => 'cialco.cialcomontoventa.store', 'method' => 'post']) !!}

<div class="box box-primary">
    {{ Form::hidden('cmv_cialco_id',$cialco->cia_cialco_id,['class'=>'form-control'])}}
    <div class="box-header with-border">
        <h3 class="box-title">Nuevo</h3>
    </div>
    <div class="box-body">
      <div class="row"> <!-- ROW 1 -->
        <div class="col-md-3">
			<div class="form-group">
				<label for="cmv_ejercicio">Año</label>
					{{ Form::number('cmv_ejercicio',null,['class'=>'form-control', 'required' => 'required|integer'])}}
					@include('include.error_form_element',['name'=>'cmv_ejercicio'])
			</div>
        </div>
        <div class="col-md-3">
			<div class="form-group">
				<label for="cmv_periodo">Mes</label>
					{{ Form::text('cmv_periodo',null,['class'=>'form-control'])}}
					@include('include.error_form_element',['name'=>'cmv_periodo'])
			</div>
        </div>
        <div class="col-md-3">
			<div class="form-group">
				<label for="cmv_monto">Monto</label>
					{{ Form::number('cmv_monto',number_format(null, 2, '.', ','),['class'=>'form-control', 'required' => 'required|numeric'])}}
					@include('include.error_form_element',['name'=>'cmv_monto'])
			</div>
        </div>
      </div>
      <div class="row"> <!-- ROW 2 -->
        <div class="col-md-3">
			<div class="form-group">
				<label for="cmv_fecha_inicio">Fecha Inicio</label></br>
					{{ Form::date('cmv_fecha_inicio', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
					@include('include.error_form_element',['name'=>'cmv_fecha_inicio'])
			</div>
        </div>
        <div class="col-md-3">
			<div class="form-group">
				<label for="cmv_fecha_fin">Fecha Fin</label></br>
					{{ Form::date('cmv_fecha_fin', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
					@include('include.error_form_element',['name'=>'cmv_fecha_fin'])
			</div>
        </div>
        <div class="col-md-3">
			<div class="form-group">
				<label for="cmv_estado">Estado</label>
					{{ Form::select('cmv_estado',['1' => 'Activo', '0' => 'Inactivo'],null,['class'=>'form-control'])}}
					@include('include.error_form_element',['name'=>'cmv_estado'])
			</div>
        </div>
      </div>
    </div>
	<div class="box-footer">
	  <button type="submit" class="btn btn-primary">Guardar</button>
	</div>
	{!! Form::close() !!}
	<div class="box-footer">
		<a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
	</div>

	@stop
	@section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
	@stop
	@section('js')
		<script> console.log('cmv_fecha_inicio'); </script>
@stop