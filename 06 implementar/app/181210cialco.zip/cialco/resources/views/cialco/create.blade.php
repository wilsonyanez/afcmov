@extends('adminlte::page')
@section('title', 'Dashboard')
@section('content_header')
   <h1>RQ19-WEB-HU085</h1>
@stop

@section('content')
{!! Form::open(['route' => 'cialco.store', 'method' => 'post']) !!}
<div class="box box-primary">
  <div class="box-header with-border">
    <h1 class="box-title"><b>Registro de CIALCO</b></h1>
  </div>

  <div class="box-body">
    <div class="row"> <!-- ROW 1 -->
      <div class="col-md-4">
        <div class="form-group">
          <label for="cia_modalidad_id">Modalidad de Circuito</label>
          {{ Form::select('cia_modalidad_id', $modalidades, null, ['class'=>'form-control','placeholder' => 'Seleccione...']) }}
          @include('include.error_form_element',['name'=>'cia_modalidad_id'])
          <p>
            @include('include.ok_element')
            <span class="label label-default">TODO: Trait after "OTRO" selection</span>
          </p>
        </div>
      </div>

      <div class="col-md-4">
        <div class="form-group">
          <label for="cia_permanencia_id">Datos del circuito</label>
          {{ Form::select('cia_permanencia_id', $permanencias, null, ['class'=>'form-control','placeholder' => 'Seleccione...']) }}
          @include('include.error_form_element',['name'=>'cia_permanencia_id'])
          <p>
            @include('include.ok_element')
            <span class="label label-default">Tiene algun comportamiento dependiendo de la selección?</span>
          </p>
        </div>
      </div>

    </div> <!-- CLOSE ROW 1 -->

    <div class="row">
      <div class="col-md-12">
        <h4><b>Información CIALCO</b></h4>
        <hr/>
      </div>
    </div>

    <div class="row"><!--  ROW 2 -->
      <div class="col-md-6">
        <div class="form-group">
          <label for="cia_nombre">Nombre</label>
          {{ Form::text('cia_nombre',null,['class'=>'form-control', 'required' => 'required|alpha'])}}
          @include('include.error_form_element',['name'=>'cia_nombre'])
          <p>@include('include.ok_element')</p>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="cia_contacto">Contacto</label>
          {{ Form::text('cia_contacto',null,['class'=>'form-control', 'required' => 'required|alpha'])}}
          <p>@include('include.ok_element')</p>
        </div>
      </div>
    </div>

    <div class="row"><!--  ROW 2 -->
      <div class="col-md-6">
        <div class="form-group">
          <label for="cia_correo_electronico">Correo electrónico</label>
          {{ Form::email('cia_correo_electronico',null,['class'=>'form-control', 'required' => 'required|email|unique:cialco'])}}
          <p>@include('include.ok_element')</p>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="cia_sitio_web">Sitio web</label>
          {{ Form::text('cia_sitio_web',null,['class'=>'form-control', 'required' => 'required|web|unique:cialco'])}}
          <p>@include('include.ok_element')</p>
        </div>
      </div>
    </div>

   {{-- @include('cialco.form_ubicacion')
    @include('cialco.form_representante')--}}

    <div class="row"><!--  ROW 3 -->
		<div class="col-md-6">
		<label for="cia_fecha_inicio">Fecha Inicio</label></br>
			{{ Form::date('cia_fecha_inicio', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
			@include('include.error_form_element',['name'=>'cia_fecha_inicio'])
		</div>
		<div class="col-md-6">
		<label for="cia_fecha_fin">Fecha Fin</label></br>
			{{ Form::date('cia_fecha_fin', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
			@include('include.error_form_element',['name'=>'cia_fecha_fin'])
		</div>
		<div class="col-md-6">
		<label for="cia_estado">Estado</label>
			{{ Form::select('cia_estado',['1' => 'Activo', '0' => 'Inactivo'],null,['class'=>'form-control'])}}
            @include('include.error_form_element',['name'=>'cia_estado'])
		</div>
    </div>

	<div class="box-footer">
	  <button type="submit" class="btn btn-primary">Almacenar</button>
	</div>

	</div>
	{!! Form::close() !!}
	@stop
	@section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
	@stop
	@section('js')
@stop