@extends('adminlte::page')



@section('title', 'Dashboard')



@section('content_header')

    <h1>RQ18-MOV-HU084</h1>
    <p></p>

@stop



@section('content')

    <p>Como Técnico de Territorio, quiero publicar datos de las prácticas de equidad de la operación de los Establecimientos, que me solicita el Administrador AFC para validar si se otorga o no el Sello de la Agricultura Familiar Campesina (Sello AFC).</p>
    <ul>
      <li>Diseño: Cumplir formato detallado en los archivos:RQ14-MOV-HU062-DIS069 Publicación Establecimiento - Prácticas de equidad de la operación.png</li>
      <li>Usabilidad: Cumplir con el detalle descrito en pestaña funcionalidad con identificación: RQ14-MOV-HU062-FUN</li>
      <li>Objetivo: Publicar Datos de prácticas de equidad de la operación de un Establecimientos donde suministra sus productos un Productor en dispositivo móvil, los atributos a desplegar, se los puede encontrar en: RQ09-MOV-HU039-DIS046</li>
      <li><b>Inquitudes</b></li>
      <li></li>
      </ul>

       <div class="box box-primary">
                  <div class="box-header with-border">
                    <h3 class="box-title">Inscripción de establecimiento</h3>
                  </div>
                  <div class="box-body">

                      <div class="row">
                              <div class="col-md-6">
                                  <div class="form-group">
                                        <label for="exampleInputEmail1">Forma de acuerdo con los proveedores</label>
                                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Forma de acuerdo con los proveedores">
                                        <p>
                                        <span class="label label-danger">Requerido?</span>
                                        <span class="label label-info">Dropdown?</span>
                                        </p>
                                  </div>
                              </div>

                               <div class="col-md-6">
                                  <div class="form-group">
                                        <label for="exampleInputEmail1">Forma de pago</label>
                                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Forma de pago">
                                        <p>
                                        <span class="label label-danger">Requerido?</span>
                                        <span class="label label-info">Dropdown? </span></p>
                                  </div>
                              </div>

                      </div>
                      <!-- /.row -->
                      <div class="row">
                              <div class="col-md-6">
                                  <div class="form-group">
                                        <label for="exampleInputEmail1">Plazo de pago</label>
                                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Plazo de pago">
                                        <p>
                                        <span class="label label-danger">Requerido?</span>
                                        <span class="label label-info">Dropdown?</span>
                                        </p>
                                  </div>
                              </div>

                               <div class="col-md-6">
                                  <div class="form-group">
                                        <label for="exampleInputEmail1">Sistema de control de calidad para recepción</label>
                                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Sistema de control de calidad para recepción">
                                        <p>
                                        <span class="label label-danger">Requerido?</span>
                                        <span class="label label-info">Dropdown?</span>
                                        </p>
                                  </div>
                              </div>

                      </div>
                      <!-- /.row -->
                      <div class="row">
                              <div class="col-md-6">
                                  <div class="form-group">
                                        <label for="exampleInputEmail1">Sistema de seguimiento de satisfacción de calidad</label>
                                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Sistema de seguimiento de satisfacción de calidad">
                                        <p>
                                        <span class="label label-danger">Requerido?</span>
                                        <span class="label label-info">Dropdown?</span>
                                        </p>
                                  </div>
                              </div>



                      </div>
                      <!-- /.row -->



                  </div>

                  <div class="box-footer">
                      <button type="submit" class="btn btn-primary">Almacenar</button>
                    </div>
          </div>


@stop



@section('css')

    <link rel="stylesheet" href="/css/admin_custom.css">

@stop



@section('js')

    <script> console.log('Hi!'); </script>

@stop