<?php

namespace App\Catalogs;

use Illuminate\Database\Eloquent\Model;

class Dpa extends Model
{
    protected $table = 'dpa';
    protected $primaryKey = 'id_dpa';

    public function children()
    {
        return $this->hasMany(Dpa::class,'id_dpa','cod_dpa' );
    }
}