<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUtmTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('utm', function (Blueprint $table) {
            $table->increments('utm_utm_id');
            $table->text('utm_descripcion');
            $table->integer('utm_orden')->default(0);

            // COLUMNAS DE CONTROL
            $table->boolean('utm_estado')->default(true);

            $table->date('utm_fecha_inicio')->nullable();
            $table->date('utm_fecha_fin')->nullable();

            $table->integer('utm_usuario_inserta')->unsigned()->nullable();
            $table->timestamp('utm_fecha_inserta')->nullable();

            $table->integer('utm_usuario_actualiza')->unsigned()->nullable();
            $table->timestamp('utm_fecha_actualiza')->nullable();

            $table->integer('utm_usuario_elimina')->unsigned()->nullable();
            $table->timestamp('utm_fecha_elimina')->nullable();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('utm');
    }
}
