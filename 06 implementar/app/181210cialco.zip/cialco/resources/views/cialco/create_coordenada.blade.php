@extends('adminlte::page')
@section('title', 'Coordendas')
@section('content_header')
    <h1>Coordenadas</h1>
@stop

@section('content')
    @include('include.alert')
    {!! Form::open(['route' => 'cialco.coordenada.store', 'method' => 'post']) !!}

    <div class="box box-primary">
        {{ Form::hidden('coo_cialco_id',$cialco->cia_cialco_id,['class'=>'form-control'])}}
        <div class="box-header with-border">
            <h3 class="box-title">Nueva Coordenada</h3>
        </div>
        <div class="box-body">
            <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="dir_sector">Posición X</label>
                            {{ Form::text('coo_posicion_x',null,['class'=>'form-control', 'required' => 'required|numeric'])}}
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="dir_calle_principal">Posición Y</label>
                            {{ Form::text('coo_posicion_y',null,['class'=>'form-control', 'required' => 'required|numeric'])}}
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="dir_numero">Posición Z</label>
                            {{ Form::text('coo_posicion_z',null,['class'=>'form-control', 'required' => 'required|numeric'])}}
                        </div>
                    </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="coo_utm_id">UTM</label>
                        {{ Form::select('coo_utm_id',$utms,null,['class'=>'form-control'])}}
                    </div>
                </div>
				<div class="col-md-4">
					<label for="coo_fecha_inicio">Fecha Inicio</label></br>
						{{ Form::date('coo_fecha_inicio', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
						@include('include.error_form_element',['name'=>'coo_fecha_inicio'])
				</div>
				<div class="col-md-4">
				<label for="coo_fecha_fin">Fecha Fin</label></br>
						{{ Form::date('coo_fecha_fin', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
						@include('include.error_form_element',['name'=>'coo_fecha_fin'])
				</div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="coo_estado">Estado</label>
                        {{ Form::select('coo_estado',['1' => 'Activo', '0' => 'Inactivo'],null,['class'=>'form-control'])}}
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div>

	<div class="box-footer">
		<button type="submit" class="btn btn-primary">Crear</button>
	</div>
	{!! Form::close() !!}
	<div class="box-footer">
		<a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
	</div>
	@stop
	@section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
	@stop
	@section('js')

@stop