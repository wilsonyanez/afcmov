/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Wilson Yánez
 */
public class OrganizacionDesdeMovil {
    private String organizacion;
    private String organizacionDetv;
    private String organizacionDeth;

    public OrganizacionDesdeMovil() {
    }

    public OrganizacionDesdeMovil(String organizacion, String organizacionDetv, String organizacionDeth) {
        this.organizacion = organizacion;
        this.organizacionDetv = organizacionDetv;
        this.organizacionDeth = organizacionDeth;
    }

    public String getOrganizacion() {
        return organizacion;
    }

    public void setOrganizacion(String organizacion) {
        this.organizacion = organizacion;
    }

    public String getOrganizacionDetv() {
        return organizacionDetv;
    }

    public void setOrganizacionDetv(String organizacionDetv) {
        this.organizacionDetv = organizacionDetv;
    }

    public String getOrganizacionDeth() {
        return organizacionDeth;
    }

    public void setOrganizacionDeth(String organizacionDeth) {
        this.organizacionDeth = organizacionDeth;
    }
    
    public void imprimirCial(){
        System.out.println(organizacion+" "+organizacionDetv+" "+organizacionDeth);
    }

}