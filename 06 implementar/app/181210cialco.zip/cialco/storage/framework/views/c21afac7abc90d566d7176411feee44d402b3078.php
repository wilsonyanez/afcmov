

<?php $__env->startSection('title', 'Nueva Dirección'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dirección</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   <?php echo Form::open(['route' => 'cialco.direccion.store', 'method' => 'post']); ?>


    <div class="box box-primary">
        <?php echo e(Form::hidden('dir_cialco_id',$cialco->cia_cialco_id,['class'=>'form-control'])); ?>

        <div class="box-header with-border">
            <h3 class="box-title">Nueva</h3>
        </div>
        <div class="box-body">
			<div class="row">
				<div class="col-md-12">
					<div class="form-group">
						<label for="dir_sector">Sector</label>
						<?php echo e(Form::text('dir_sector',null,['class'=>'form-control'])); ?>

						<?php echo $__env->make('include.error_form_element',['name'=>'dir_sector'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<label for="dir_calle_principal">Calle Principal</label>
						<?php echo e(Form::text('dir_calle_principal',null,['class'=>'form-control'])); ?>

						<?php echo $__env->make('include.error_form_element',['name'=>'dir_calle_principal'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
				<div class="col-md-2">
					<div class="form-group">
						<label for="dir_numero">Número #</label>
						<?php echo e(Form::text('dir_numero',null,['class'=>'form-control'])); ?>

						<?php echo $__env->make('include.error_form_element',['name'=>'dir_numero'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
			</div>

			<div class="row">
			  <div class="col-md-6">
				<div class="form-group">
				  <label for="dir_calle_secundaria">Calle Secundaria</label>
				  <?php echo e(Form::text('dir_calle_secundaria',null,['class'=>'form-control'])); ?>

					<?php echo $__env->make('include.error_form_element',['name'=>'dir_calle_secundaria'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
			  </div>
			  <div class="col-md-6">
				<div class="form-group">
				  <label for="dir_referencia">Referencia</label>
				  <?php echo e(Form::text('dir_referencia',null,['class'=>'form-control'])); ?>

				  <?php echo $__env->make('include.error_form_element',['name'=>'dir_referencia'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			   </div>
			 </div>
			 <div class="col-md-6">
				<div class="form-group">
				  <label for="dir_consumidores">Consumidores</label>
				  <?php echo e(Form::number('dir_consumidores',null,['class'=>'form-control'])); ?>

				  <?php echo $__env->make('include.error_form_element',['name'=>'dir_consumidores'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			   </div>
			 </div>
		   </div>
               <!-- /.row -->

		<div class="row"><!--  ROW 2 -->
				 <div class="col-md-4">
				   <div class="form-group">
					 <label for="exampleInputEmail1">Provincia</label>
					 <select class="form-control">
					   <option>option 1</option>
					   <option>option 2</option>
					   <option>option 3</option>
					   <option>option 4</option>
					   <option>option 5</option>
					 </select>

					 <p>
					   <span class="label label-info">Dropdown? de base actual existe? no nueva?</span>
					 </p>
				   </div>
				 </div>

				 <div class="col-md-4">
				   <div class="form-group">
					 <label for="exampleInputEmail1">Cantón</label>
					 <select class="form-control">
					   <option>option 1</option>
					   <option>option 2</option>
					   <option>option 3</option>
					   <option>option 4</option>
					   <option>option 5</option>
					 </select>
					 <p>
					   <span class="label label-info">Dropdown? de base actual existe? no nueva?</span>
					 </p>
				   </div>
				 </div>

				 <div class="col-md-4">
				   <div class="form-group">
					 <label for="exampleInputEmail1">Parroquia</label>
					 <select class="form-control">
					   <option>option 1</option>
					   <option>option 2</option>
					   <option>option 3</option>
					   <option>option 4</option>
					   <option>option 5</option>
					 </select>
					 <p>
					   <span class="label label-info">Dropdown? de base actual existe? no nueva?</span>
					 </p>
				   </div>
				 </div>
		   </div><!-- CLOSE ROW 2 -->

		  <div class="row"><!--  ROW 3 -->
		    <div class="col-md-6">
		    <label for="dir_fecha_inicio">Fecha Inicio</label>
				<?php echo e(Form::date('dir_fecha_inicio', null, array('id' => 'datepicker'))); ?>

				<?php echo $__env->make('include.error_form_element',['name'=>'dir_fecha_inicio'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		    </div>
		    <div class="col-md-6">
		      <label for="dir_fecha_fin">Fecha Fin</label>
				<?php echo e(Form::date('dir_fecha_fin', null, array('id' => 'datepicker'))); ?>

				<?php echo $__env->make('include.error_form_element',['name'=>'dir_fecha_fin'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		      </div>
		    <div class="col-md-6">
			  <label for="dir_estado">Estado</label>
				<?php echo e(Form::select('dir_estado',['1' => 'Activo', '0' => 'Inactivo'],null,['class'=>'form-control'])); ?>

            </div>
		  </div><!-- CLOSE ROW 3 -->
        </div>


        <div class="box-footer">
            <button type="submit" class="btn btn-primary">Guardar</button>
        </div>
        <?php echo Form::close(); ?>

        <div class="box-footer">
            <a href="<?php echo e(URL::previous()); ?>" class="pull-right btn btn-default">Regresar</a>
        </div>

        <?php $__env->stopSection(); ?>



        <?php $__env->startSection('css'); ?>

            <link rel="stylesheet" href="/css/admin_custom.css">

        <?php $__env->stopSection(); ?>



        <?php $__env->startSection('js'); ?>

            <script> console.log('Hi!'); </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>