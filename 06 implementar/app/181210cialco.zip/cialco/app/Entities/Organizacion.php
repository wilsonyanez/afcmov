<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Organizacion extends Model
{
    protected $table = 'organizacion';
    protected $primaryKey = 'org_organizacion_id';
    const CREATED_AT = 'org_fecha_inserta';
    const UPDATED_AT = 'org_fecha_actualiza';

    use SoftDeletes;
    const DELETED_AT = 'org_fecha_elimina';

    protected $append = [
        'texto_hecho_derecho',
        'texto_hecho_derecho_html',
        'texto_registro_seps',
        'texto_registro_seps_html',
        'texto_acreditado_mag',
        'texto_acreditado_mag_html',
        'texto_estado',
        'texto_estado_html'
    ];

    protected $fillable = [
        'org_ruc',
        'org_razon_social',
        'org_nro_productores_total',
        'org_nro_productores_hombres',
        'org_nro_productores_mujeres',
        'org_hecho_derecho',
        'org_registro_seps',
        'org_acreditado_mag',
        'org_estado',
        'org_fecha_inicio',
        'org_fecha_fin',
        'org_organizacion_id',
		'org_cialco_id',
        'org_ubicacion_geografica_id'
    ];
	
    public function UbicacionGeografica()
    {
        return $this->belongsTo('App\Catalogs\UbicacionGeografica', 'org_ubicacion_geografica_id');
    }

    public function cialco()
    {
        return $this->belongsTo('App\Entities\Cialco', 'org_cialco_id');
    }

    public function getTextoHechoDerechoAttribute()
    {
        return ($this->org_hecho_derecho ? 'Hecho' : 'Derecho');
    }

    public function getTextoHechoDerechoHtmlAttribute()
    {
        if ($this->org_hecho_derecho)
            return ('<span class="label label-success">' . $this->texto_hecho_derecho . '</span>');
        return ('<span class="label label-default">' . $this->texto_hecho_derecho . '</span>');
    }

    public function getTextoRegistroSepsAttribute()
    {
        return ($this->org_registro_seps ? 'SI' : 'NO');
    }

    public function getTextoRegistroSepsHtmlAttribute()
    {
        if ($this->org_registro_seps)
            return ('<span class="label label-success">' . $this->texto_registro_seps . '</span>');
        return ('<span class="label label-default">' . $this->texto_registro_seps . '</span>');
    }

    public function getTextoAcreditadoMagAttribute()
    {
        return ($this->org_acreditado_mag ? 'SI' : 'NO');
    }

    public function getTextoAcreditadoMagHtmlAttribute()
    {
        if ($this->org_acreditado_mag)
            return ('<span class="label label-success">' . $this->texto_acreditado_mag . '</span>');
        return ('<span class="label label-default">' . $this->texto_acreditado_mag . '</span>');
    }
	
    public function getTextoEstadoAttribute()
    {
        return ($this->org_estado ? 'Activo' : 'Inactivo');
    }

    public function getTextoEstadoHtmlAttribute()
    {
        if ($this->org_estado)
            return ('<span class="label label-success">' . $this->texto_estado . '</span>');
        return ('<span class="label label-default">' . $this->texto_estado . '</span>');
    }

}