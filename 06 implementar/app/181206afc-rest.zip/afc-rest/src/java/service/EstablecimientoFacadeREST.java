/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import clases.EstablecimientoDesdeMovil;
import clases.Prueba;
import entidades.Establecimiento;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Wilson Yánez
 */
@Stateless
@Path("entidades.establecimiento")
public class EstablecimientoFacadeREST extends AbstractFacade<Establecimiento> {
    
    private static final Logger LOGGER = Logger.getLogger(EstablecimientoFacadeREST.class.getName());


    @PersistenceContext(unitName = "afc-restPU")
    private EntityManager em;

    public EstablecimientoFacadeREST() {
        super(Establecimiento.class);
    }
    
    public String ejecutarQueryNativo(String sql) throws Exception {
        String s = "";
        try {
            Query q = em.createNativeQuery(sql);
            q.executeUpdate();
            s = "OK";
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, null, ex);
            StringWriter errors = new StringWriter();
            ex.printStackTrace(new PrintWriter(errors));
            s= errors.toString();
        }
        return s;
    }

    public List<Object[]> obtenerQueryNativo(String sql) throws Exception {
        List<Object[]> lst = new ArrayList<Object[]>();
        try {
            Query q = em.createNativeQuery(sql);
            lst = q.getResultList();
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, null, ex);
        }
        return lst;
    }
    

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Establecimiento entity) {
        super.create(entity);
    }
    
    @POST
    @Path("resumen")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Prueba entity) {
        
        Establecimiento f=new Establecimiento();
        f.setCodUsuario("1714576574");
        f.setNumero(entity.getCampo1());
        f.setClave(entity.getCampo1());
        f.setReferencia(entity.getCampo2());
        super.create(f);
    }
    
    @POST
    @Path("postEsta")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(EstablecimientoDesdeMovil objeto) {

        try{
            ejecutarQueryNativo(sqlInsertEstablecimientoCabecera(objeto.getEstablecimiento())+sqlInsertEstablecimientoDetalleV(objeto.getEstablecimientoDetv(),obtenerClaveEstablecimiento(objeto.getEstablecimiento()))+sqlInsertEstablecimientoDetalleH(objeto.getEstablecimientoDeth(),obtenerClaveEstablecimiento(objeto.getEstablecimiento()))+sqlAsignarClaveForanea());
       
        }catch(Exception ex){
            LOGGER.log(Level.SEVERE, null, ex);
        }

        //objeto.imprimirForm();
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, Establecimiento entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Establecimiento find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({ MediaType.APPLICATION_JSON})
    public List<Establecimiento> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Establecimiento> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
     public String[] splitFilas(String trama){
        if(trama.length()>1){
            return trama.split("\\$");
         }else{
             return new String[0];
         }
    }
    public String[] splitColumnas(String row){
        if(row.length()>1){
            return row.split("\\^");
         }else{
             return new String[0];
         }
    }
    public void imprimirRow(String row){
        
        String[] parts=splitColumnas(row);
        if(parts.length>0){
            String res="";
            for(int i=0;i<parts.length;i++){
                res=res+","+parts[i];
            }
            System.out.println(res);
        }
    }
    
    public String sqlInsertEstablecimientoCabecera(String rowEstablecimiento){
        String sql="";
        String[] parts=splitColumnas(rowEstablecimiento);
        sql="insert into establecimiento(cod_usuario, tipo, numero, fecha, "
                + "referencia, estado_p, estado_t, clave, long_usuario, long_identificador) values "+
                "('"+parts[1]+"','"+parts[2]+"','"+parts[3]+"',to_timestamp("+parts[4]+"/1000),'"+
                parts[5]+"','"+parts[6]+"','"+parts[7]+"','"+parts[8]+"',"+parts[9]+","+parts[10]+");";

        return sql;
    }
    
    public String obtenerClaveEstablecimiento(String rowEstablecimiento){
        String clave="";
        String[] parts=splitColumnas(rowEstablecimiento);
        clave=parts[8];
        
        return clave;
    }
    
    public String sqlInsertEstablecimientoDetalleV(String rowsEstablecimientoV,String clave){
        String sql="";
        String[] partsFilas=splitFilas(rowsEstablecimientoV);
        if(partsFilas.length>0){
        sql="INSERT INTO establecimiento_detv(cod_mod, orden, cod_preg, valor, clave) values";
          for(int i=0;i<partsFilas.length;i++){
              String[] partsCols=splitColumnas(partsFilas[i]);
              sql=sql+"('"+partsCols[1]+"',"+partsCols[2]+",'"+partsCols[3]+"','"+partsCols[4]+"','"+clave+"')";
              if(i==(partsFilas.length-1)){
                  sql=sql+";";
              }else{
                  sql=sql+",";
              }
          }
        }
           
        return sql;
    }
    
    public String sqlInsertEstablecimientoDetalleH(String rowsEstablecimientoH,String clave){
        String sql="";
        String[] partsFilas=splitFilas(rowsEstablecimientoH);
        if(partsFilas.length>0){
        sql="INSERT INTO establecimiento_deth(cod_var, orden, val01, val02, val03, val04, val05, val06, val07, val08, val09, val10, val11, val12, val13, val14, val15, val16, clave) values";
          for(int i=0;i<partsFilas.length;i++){
              String[] partsCols=splitColumnas(partsFilas[i]);
              sql=sql+"('"+partsCols[1]+"',"+partsCols[2]+",'"+partsCols[3]+"','"+partsCols[4]+"','"+partsCols[5]+"','"+partsCols[6]+"','"+partsCols[7]+"','"+partsCols[8]+"','"+partsCols[9]+"','"+partsCols[10]+"','"+partsCols[11]+"','"+partsCols[12]+"','"+partsCols[13]+"','"+partsCols[14]+"','"+partsCols[15]+"','"+partsCols[16]+"','"+partsCols[17]+"','"+partsCols[18]+"','"+clave+"')";
              if(i==(partsFilas.length-1)){
                  sql=sql+";";
              }else{
                  sql=sql+",";
              }
          }
        }
           
        return sql;
    }
    
    public String sqlAsignarClaveForanea(){
        return "update establecimiento_detv v set cod_esta =c.id_establecimiento from establecimiento c where c.clave=v.clave;update establecimiento_deth h set cod_esta =c.id_establecimiento from establecimiento c where c.clave=h.clave;";
    }
}
