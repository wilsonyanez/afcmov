<?php

use Illuminate\Database\Seeder;

class FrecuenciaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('frecuencia')->insert([
            'fre_descripcion' => 'Diaria',
            'fre_orden' => 1,
            'fre_fecha_inserta' => date_create('now UTC'),
            'fre_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('frecuencia')->insert([
            'fre_descripcion' => 'Semanal',
            'fre_orden' => 2,
            'fre_fecha_inserta' => date_create('now UTC'),
            'fre_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('frecuencia')->insert([
            'fre_descripcion' => 'Quincenal',
            'fre_orden' => 3,
            'fre_fecha_inserta' => date_create('now UTC'),
            'fre_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('frecuencia')->insert([
            'fre_descripcion' => 'Mensual',
            'fre_orden' => 4,
            'fre_fecha_inserta' => date_create('now UTC'),
            'fre_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('frecuencia')->insert([
            'fre_descripcion' => 'Bimensual',
            'fre_orden' => 5,
            'fre_fecha_inserta' => date_create('now UTC'),
            'fre_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('frecuencia')->insert([
            'fre_descripcion' => 'Trimestral',
            'fre_orden' => 6,
            'fre_fecha_inserta' => date_create('now UTC'),
            'fre_fecha_actualiza' => date_create('now UTC')
        ]);
        \DB::table('frecuencia')->insert([
            'fre_descripcion' => 'Anual',
            'fre_orden' => 7,
            'fre_fecha_inserta' => date_create('now UTC'),
            'fre_fecha_actualiza' => date_create('now UTC')
        ]);
    }
}