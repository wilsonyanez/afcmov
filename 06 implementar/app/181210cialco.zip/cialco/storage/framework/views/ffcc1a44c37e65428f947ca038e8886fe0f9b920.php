
<?php $__env->startSection('title', 'Nuevo Cialco Interinstitucional'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Cialco Interinstitucional</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::model($result, ['method' => 'PATCH','route' => ['cialcointerinstitucional.update', 'id'=>$result->int_cialco_interins_id]]); ?>

    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Editar</h3>
        </div>
        <div class="box-body">
            <div class="row"> <!-- ROW 1 -->
                <div class="col-md-4">
                    <div class="form-group">
						<label for="int_cialco_id">Cialco</label>
							<?php echo e(Form::select('int_cialco_id', $cialcos, $result->int_cialco_id, ['class'=>'form-control','placeholder' => 'Seleccione...'])); ?>

							<?php echo $__env->make('include.error_form_element',['name'=>'int_cialco_id'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                    <div class="form-group">
						<label for="int_accion_fortalecimiento_id">Accion Fortalecimiento</label>
							<?php echo e(Form::select('int_accion_fortalecimiento_id', $accionfortalecimientos, $result->int_accion_fortalecimiento_id, ['class'=>'form-control','placeholder' => 'Seleccione...'])); ?>

							<?php echo $__env->make('include.error_form_element',['name'=>'int_accion_fortalecimiento_id'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                    <div class="form-group">
						<label for="int_apoyo_institucional_id">Apoyo Institucional</label>
							<?php echo e(Form::select('int_apoyo_institucional_id', $apoyoinstitucionals, $result->int_apoyo_institucional_id, ['class'=>'form-control','placeholder' => 'Seleccione...'])); ?>

							<?php echo $__env->make('include.error_form_element',['name'=>'int_apoyo_institucional_id'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<p>
							<?php echo $__env->make('include.ok_element', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
							<span class="label label-default">TODO: Trait after "OTRO" selection</span>
						</p>
                    </div>
                    <div class="form-group">
                        <label for="int_provincial">Provincial</label>
                        <?php echo e(Form::select('int_provincial',['1' => 'SI', '0' => 'NO'],$result->int_provincial,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'int_provincial'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                    <div class="form-group">
						<label for="int_gad_provincial_id">Gad Provincial</label>
							<?php echo e(Form::select('int_gad_provincial_id', $ubicacionprovincials, $result->int_gad_provincial_id, ['class'=>'form-control','placeholder' => 'Seleccione...'])); ?>

							<?php echo $__env->make('include.error_form_element',['name'=>'int_gad_provincial_id'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>

            <div class="row">  <!-- ROW 2 -->
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="int_cantonal">Cantonal</label>
                        <?php echo e(Form::select('int_cantonal',['1' => 'SI', '0' => 'NO'],$result->int_cantonal,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'int_cantonal'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
					<div class="form-group">
                        <label for="int_gad_cantonal_id">Gad Cantonal</label>
						<?php echo e(Form::select('int_gad_cantonal_id', $ubicacioncantonals, $result->int_gad_cantonal_id, ['class'=>'form-control','placeholder' => 'Seleccione...'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'int_gad_cantonal_id'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
                    <div class="form-group">
                        <label for="int_parroquial">Parroquial</label>
                        <?php echo e(Form::select('int_parroquial',['1' => 'SI', '0' => 'NO'],$result->int_parroquial,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'int_parroquial'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
					<div class="form-group">
                        <label for="int_gad_parroquial_id">Gad Parroquial</label>
						<?php echo e(Form::select('int_gad_parroquial_id', $ubicacionparroquials, $result->int_gad_parroquial_id, ['class'=>'form-control','placeholder' => 'Seleccione...'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'int_gad_parroquial_id'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
					<div class="form-group">
						<label for="int_otro">Otro</label>
                        <?php echo e(Form::select('int_otro',['1' => 'SI', '0' => 'NO'],$result->int_otro,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'int_otro'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
            </div>

            <div class="row">  <!-- ROW 3 -->
                <div class="col-md-6">
					<div class="form-group">
						<label for="int_descripcion">Descripción</label>
						<?php echo e(Form::text('int_descripcion',$result->int_descripcion,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'int_descripcion'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
            </div>

            <div class="row">  <!-- ROW 4 -->
                <div class="col-md-3">
					<div class="form-group">
						<label for="int_fecha_inicio">Fecha Inicio</label>
						<?php echo e(Form::text('int_fecha_inicio',$result->int_fecha_inicio,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'int_fecha_inicio'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
                    <div class="form-group">
                        <label for="int_fecha_fin">Fecha Fin</label>
						<?php echo e(Form::text('int_fecha_fin',$result->int_fecha_fin,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'int_fecha_fin'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                    <div class="form-group">
                        <label for="int_estado">Estado</label>
                        <?php echo e(Form::select('int_estado',['1' => 'Activo', '0' => 'Inactivo'],$result->int_estado,['class'=>'form-control'])); ?>

                    </div>
                </div>

            <div class="row">  <!-- ROW 5 -->
                <div class="col-md-3">
					<div class="form-group">
						<label for="int_fecha_actualiza">Fecha Actualización</label>
						<?php echo e(Form::text('int_fecha_actualiza',$result->int_fecha_actualiza,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'int_fecha_actualiza'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
            </div>
        </div>

        <div class="box-footer">
            <button type="submit" class="btn btn-primary">Editar</button>
        </div>
        <?php echo Form::close(); ?>

        <div class="box-footer">
            <a href="<?php echo e(URL::previous()); ?>" class="pull-right btn btn-default">Regresar</a>
        </div>
	<?php $__env->stopSection(); ?>
	<?php $__env->startSection('css'); ?>
			<link rel="stylesheet" href="/css/admin_custom.css">
		<?php $__env->stopSection(); ?>
	<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>