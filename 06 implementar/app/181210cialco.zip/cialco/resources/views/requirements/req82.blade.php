@extends('adminlte::page')



@section('title', 'Dashboard')



@section('content_header')

    <h1>RQ18-MOV-HU082</h1>
    <p>Publicación de establecimiento - Datos generales</p>

@stop



@section('content')

    <p>Como Técnico de Territorio, quiero publicar los datos generales de los Establecimientos, que me solicita el Administrador AFC para validar si se otorga o no el Sello de la Agricultura Familiar Campesina (Sello AFC).</p>
    <ul>
      <li>Diseño: Cumplir formato detallado en los archivos:RQ14-MOV-HU060-DIS067 Publicación Establecimiento - Datos generales.png</li>
      <li>Usabilidad: Cumplir con el detalle descrito en pestaña funcionalidad con identificación: RQ14-MOV-HU060-FUN</li>
      <li>Objetivo: Publicar Datos de Establecimientos a las que Pertenece un Productor en dispositivo móvil, los atributos a desplegar, se los puede encontrar en: RQ09-MOV-HU037-DIS044</li>
      <li><b>Inquitudes</b></li>
      <li>¿Estructura de tabla?</li>
      <li>¿Estructura de campos y columnas?</li>
      <li>¿Que campos son automáticos o vienen de consultas SRI?</li>
      </ul>

     <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Formulario de Registro</h3>
                </div>
                <div class="box-body">

                    <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                      <label for="exampleInputEmail1">Código registro AFC</label>
                                      <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Código registro AFC">
                                      <p>
                                      <span class="label label-danger">requerido?</span>
                                      <span class="label label-info">Como se genera el código</span>
                                      <span class="label label-info">es automático</span>
                                      </p>
                                </div>
                            </div>

                             <div class="col-md-4">
                                <div class="form-group">
                                      <label for="exampleInputEmail1">Fecha de inscripción</label>
                                      <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Fecha de inscripción">
                                      <p>
                                      <span class="label label-danger">requerido?</span>
                                      <span class="label label-info">Automática?</span>
                                      </p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                      <div class="callout callout-success">
                                                      <h4>Cumple</h4>
                                                      <p>
                                                                                            <span class="label label-info">Es una pantalla de visualización?</span>
                                                                                            </p>
                                                    </div>
                                </div>
                            </div>

                    </div>
                    <!-- /.row -->
                    <div class="row">
                    <div class="col-md-12">
                    <h1>Datos generales del establecimiento</h1>
                    </div>
                    </div>
                    <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                      <label for="exampleInputEmail1">RUC/RISE</label>
                                      <input type="email" class="form-control" id="exampleInputEmail1" placeholder="RUC-RISE">
                                      <p>
                                      <span class="label label-danger">requerido?</span>
                                      <span class="label label-info">Validación por longitud?</span>
                                      <span class="label label-info">Consulta SRI ?</span>
                                      </p>
                                </div>
                            </div>

                             <div class="col-md-4">
                                <div class="form-group">
                                      <label for="exampleInputEmail1">Razón Social</label>
                                      <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Razón Social">
                                      <p>
                                      <span class="label label-danger">requerido?</span>
                                      <span class="label label-info">Consulta SRI?</span>
                                      </p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                      <label for="exampleInputEmail1">Nombre Comercial</label>
                                      <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Nombre Comercial">
                                      <p>
                                      <span class="label label-danger">requerido?</span>
                                      <span class="label label-info">Consulta SRI?</span>
                                      </p>
                                </div>
                            </div>

                    </div>
                    <!-- /.row -->
                    <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                      <label for="exampleInputEmail1">Dirección</label>
                                      <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Dirección">
                                      <p>
                                      <span class="label label-danger">requerido?</span>
                                      <span class="label label-info">Consulta SRI ?</span>
                                      </p>
                                </div>
                            </div>

                             <div class="col-md-4">
                                <div class="form-group">
                                      <label for="exampleInputEmail1">Tipo de operación</label>
                                      <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Tipo de operación">
                                      <p>
                                      <span class="label label-danger">requerido?</span>
                                      <span class="label label-info">Consulta SRI?</span>
                                      <span class="label label-info">Catalogo?</span>
                                      </p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                      <label for="exampleInputEmail1">Nombre del Representante Legal</label>
                                      <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Nombre del Representante Legal">
                                      <p>
                                      <span class="label label-danger">requerido?</span>
                                      <span class="label label-info">Consulta SRI?</span>
                                      </p>
                                </div>
                            </div>

                    </div>
                    <!-- /.row -->
                    <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                      <label for="exampleInputEmail1">Contacto Representante Legal</label>
                                      <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Contacto Representante Legal">
                                      <p>
                                      <span class="label label-danger">requerido?</span>
                                      <span class="label label-info">Consulta SRI ?</span>
                                      </p>
                                </div>
                            </div>

                             <div class="col-md-4">
                                <div class="form-group">
                                      <label for="exampleInputEmail1">Correo electrónico</label>
                                      <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Correo electrónico">
                                      <p>
                                      <span class="label label-danger">requerido?</span>
                                      <span class="label label-info">Consulta SRI?</span>
                                      </p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                      <label for="exampleInputEmail1">Sitio web</label>
                                      <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Sitio web">
                                      <p>
                                      <span class="label label-danger">requerido?</span>
                                      <span class="label label-info">Consulta SRI?</span>
                                      </p>
                                </div>
                            </div>

                    </div>
                    <!-- /.row -->

                    <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                      <label for="exampleInputEmail1">Monto de compra mensual</label>
                                      <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Monto de compra mensual">
                                      <p>

                                      <span class="label label-info">numérico ?</span>
                                      </p>
                                </div>
                            </div>



                    </div>
                    <!-- /.row -->



                </div>

                <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Almacenar</button>
                  </div>
        </div>
@stop



@section('css')

    <link rel="stylesheet" href="/css/admin_custom.css">

@stop



@section('js')

    <script> console.log('Hi!'); </script>

@stop