@extends('adminlte::page')



@section('title', 'Dashboard')



@section('content_header')

    <h1>RQ17-MOV-HU081</h1>
    <p>Servicios ofrecidos a los socios</p>
@stop



@section('content')

     <p>Como Técnico de Territorio, quiero publicar los datos de los servicios ofrecidos a los socios de las Organizaciones, que me solicita el Administrador AFC para validar si se otorga o no el Sello de la Agricultura Familiar Campesina (Sello AFC).</p>
     <ul>
       <li>Diseño: Cumplir formato detallado en los archivos:RQ13-MOV-HU059-DIS066 Publicación Organización - Servicios ofrecidos.png</li>
       <li>Usabilidad: Cumplir con el detalle descrito en pestaña funcionalidad con identificación: RQ08-MOV-HU036-FUN</li>
       <li><b>Inquitudes</b></li>
       <li>¿Es un maestro detalle?</li>
       <li>¿En que momento se registra la cabecera?</li>
       <li>¿De donde viene la información de la tabla?</li>
       </ul>

  <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Formulario de Registro</h3>
            </div>
            <div class="box-body">

                <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                  <label for="exampleInputEmail1">Infraestructura</label>
                                  <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Infraestructura">
                                  <p><span class="label label-danger">Dropdown?</span></p>
                            </div>
                        </div>

                         <div class="col-md-4">
                            <div class="form-group">
                                  <label for="exampleInputEmail1">Transporte</label>
                                  <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Transporte">
                                  <p><span class="label label-danger">Dropdown? catalogo de donde viene la información</span></p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                  <label for="exampleInputEmail1">Personal capacitado para el manejo contable y comercial</label>
                                  <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Personal capacitado">
                                  <p><span class="label label-danger">Dropdown? catalogo de donde viene la información</span></p>
                            </div>
                        </div>

                </div>
                <!-- /.row -->

                <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                  <label for="exampleInputEmail1">Equipos</label>
                                  <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Equipos">
                                  <p><span class="label label-danger">Dropdown?</span></p>
                            </div>
                        </div>

                         <div class="col-md-4">
                            <div class="form-group">
                                  <label for="exampleInputEmail1">Certificados grupales</label>
                                  <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Certificados grupales">
                                  <p><span class="label label-danger">Dropdown? catalogo de donde viene la información</span></p>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                  <label for="exampleInputEmail1">Capacitación</label>
                                  <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Capacitación">
                                  <p><span class="label label-danger">Dropdown? catalogo de donde viene la información</span></p>
                            </div>
                        </div>

                        </div>

                </div>
                <!-- /.row -->

                <div class="row">
                <div class="col-md-12">
                            <table class="table table-bordered">
                                            <tr>
                                              <th style="width: 10px">#</th>
                                              <th>Producto</th>
                                              <th>Presentación</th>
                                              <th>Cantidad</th>
                                              <th>Frecuencia</th>
                                              <th>Tipo de mercado</th>

                                            </tr>
                                            @for ($i=0;$i<5;$i++)
                                            <tr>
                                                  <td>{{$i}}</td>
                                                  <td>nombre</td>
                                                  <td>10</td>
                                                  <td>10</td>
                                                  <td>ejemplo</td>
                                                  <td>ejemplo</td>
                                                  <td>ejemplo</td>
                                                </tr>
                                            @endfor

                                          </table>
                            </div>
                </div>




            </div>

            <div class="box-footer">
                <button type="submit" class="btn btn-primary">Almacenar</button>
              </div>
    </div>

@stop
@section('css')

    <link rel="stylesheet" href="/css/admin_custom.css">

@stop



@section('js')

    <script> console.log('Hi!'); </script>

@stop