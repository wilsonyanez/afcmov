/*==============================================================*/
/* DBMS name:      PostgreSQL 8                                 */
/* Created on:     16/10/2018 14:14:40                          */
/*==============================================================*/

/*
drop index ID_DPA_UI_IDX;
drop table public.dpa;
*/


/*==============================================================*/
/* Table: dpa                                                   */
/*==============================================================*/
create table public.dpa (
   id_dpa               VARCHAR (6)          not null,
   nivel                INT2                 not null,
   texto                VARCHAR (100)        null,
   cod_dpa              VARCHAR (6)          null,
   constraint PK_DPA primary key (id_dpa)
);


/*==============================================================*/
/* Index: ID_DPA_UI_IDX                                         */
/*==============================================================*/
create unique index ID_DPA_UI_IDX on dpa (
id_dpa
);

alter table public.dpa
   add constraint DPA_ANCESTRO_DPA_FK foreign key (cod_dpa)
      references dpa (id_dpa)
      on delete restrict on update restrict;
