<?php

namespace App\Http\Controllers\Catalogs;

use App\Catalogs\OfertaAgropecuaria;
use App\Http\Requests\StoreOfertaAgropecuariaRequest;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;

class OfertaAgropecuariaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $results = OfertaAgropecuaria::orderBy('ofa_orden','ASC')->get();
        return view('ofertaagropecuaria.index', ['results' => $results]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $order = [
            1 => 1,
            2 => 2,
            3 => 3,
            4 => 4,
            5 => 5,
            6 => 6,
            7 => 7,
            8 => 8,
            9 => 9,
            10 => 10,
            11 => 11,
        ];
        return view('ofertaagropecuaria.create', ['order' => $order]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreOfertaAgropecuariaRequest $request)
    {
        try {
            // INSERT
            $result = new OfertaAgropecuaria;
            $result->ofa_usuario_inserta = Auth::id();
            $result->fill($request->all())->save();

            Session::flash('flash_message', config('content.session.create'));
        } catch (\Exception $e) {
            Session::flash('error', config('content.session.error'));
            return back()->withInput();
        }
        return redirect()->route('ofertaagropecuaria.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $result = OfertaAgropecuaria::find($id);
        return view('ofertaagropecuaria.view', ['result' => $result]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $order = [
            1 => 1,
            2 => 2,
            3 => 3,
            4 => 4,
            5 => 5,
            6 => 6,
            7 => 7,
            8 => 8,
            9 => 9,
            10 => 10,
            11 => 11,
        ];
        $result = OfertaAgropecuaria::find($id);
        return view('ofertaagropecuaria.edit', ['result' => $result, 'order' => $order]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try {
            request()->validate([
                'ofa_descripcion' => 'required',
                'ofa_estado' => 'required',
                'ofa_orden' => 'required',
            ]);

            // UPDATE
            $result = OfertaAgropecuaria::find($id);
            $result->ofa_usuario_actualiza = Auth::id();
            $result->fill($request->all())->update();

            Session::flash('flash_message', config('content.session.update'));
        } catch (\Exception $e) {
            Session::flash('error', content('content.session.error'));
            return back()->withInput();
        }
        return redirect()->route('ofertaagropecuaria.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // NOT REQUIRED
        /*$result=OfertaAgropecuaria::find($id);
        $result->fre_usuario_elimina=Auth::id();
        $result->delete();
         return redirect()->route('ofertaAgropecuaria.index')->with('success'); */
    }
}