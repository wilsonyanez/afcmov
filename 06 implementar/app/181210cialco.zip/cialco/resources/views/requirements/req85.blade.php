@extends('adminlte::page')



@section('title', 'Dashboard')



@section('content_header')

<h1>RQ19-WEB-HU085</h1>


@stop



@section('content')
<p>Como Técnico de Territorio, quiero Registrar Datos de Productores que suministran productos a CIALCO, que me solicita el Administrador AFC para validar la participación en el Mercado de los Circuitos Alternativos de Comercialización de la AFC.</p>
<ul>
  <li>Diseño: Cumplir formato detallado en los archivos:RQ19-WEB-HU085-DIS070 Registrar Productor - Suministra producto a CIALCO.png</li>
  <li>Usabilidad: Cumplir con el detalle descrito en pestaña funcionalidad con identificación: RQ19-WEB-HU085-FUN</li>
  <li>Objetivo: Registrar Datos de Productores que suministran productos a CIALCO en WEB, los atributos a desplegar, se los puede encontrar en: RQ19-WEB-HU089-DIS070</li>
  <li><b>Inquitudes</b></li>
  <li>Tiene relación con la imagen y el contenido del archivo de excel ?</li>
  <li>¿Que datos se cargarán automaticamente?</li>
</ul>
<div class="box box-primary">
  <div class="box-header with-border">
    <h1 class="box-title"><b>Registro de Productores</b></h1>
  </div>

  <div class="box-body">


    <div class="row"> <!-- ROW 1 -->
      <div class="col-md-4">
        <div class="form-group">
          <label for="exampleInputEmail1">Modalidad de Circuito</label>
          {{ Form::select('size', $modalidades, null, ['class'=>'form-control','placeholder' => 'Seleccione...']) }}
          <p>
            <span class="label label-default">Es necesario que el catálogo venga de una tabla?</span>
            <br>
            <span class="label label-primary">INTEGER</span>
          </p>
        </div>
      </div>


      <div class="col-md-4">
        <div class="form-group">
          <label for="exampleInputEmail1">Datos del circuito</label>
          {{ Form::select('size', $circuitos, null, ['class'=>'form-control','placeholder' => 'Seleccione...']) }}
          <p>
            <span class="label label-default">Es necesario que el catálogo venga de una tabla?</span>
            <br>
            <span class="label label-default">Tiene algun comportamiento dependiendo de la selección?</span>
            <br>
            <span class="label label-primary">INTEGER</span>
          </p>
        </div>
      </div>

      <div class="col-md-4">
        <div class="form-group">
          <label for="exampleInputEmail1">Fecha de creación</label>
          {{ Form::text('fecha_creacion',null,['class'=>'form-control'])}}
          <p>

            <span class="label label-primary">DATE</span>            
            <span class="label label-warning">Validación: año 1930 - 2030</span>
          </p>
        </div>
      </div>

    </div> <!-- CLOSE ROW 1 -->


       <div class="row">
    <div class="col-md-12">
      <h4><b>Información CIALCO</b></h4>
      <hr/>
    </div>
  </div>

    <div class="row"><!--  ROW 2 -->
    
      <div class="col-md-12">
        <div class="form-group">
          <label for="exampleInputEmail1">Nombre</label>
          {{ Form::text('fecha_creacion',null,['class'=>'form-control'])}}
          <p>
            <span class="label label-primary">STRING</span>            
          </p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="form-group">
          <label for="exampleInputEmail1">Provincia</label>
          <select class="form-control">
            <option>option 1</option>
            <option>option 2</option>
            <option>option 3</option>
            <option>option 4</option>
            <option>option 5</option>
          </select>

          <p>
            <span class="label label-info">Dropdown? de base actual existe? no nueva?</span>
          </p>
        </div>
      </div>

      <div class="col-md-4">
        <div class="form-group">
          <label for="exampleInputEmail1">Cantón</label>
          <select class="form-control">
            <option>option 1</option>
            <option>option 2</option>
            <option>option 3</option>
            <option>option 4</option>
            <option>option 5</option>
          </select>
          <p>
            <span class="label label-info">Dropdown? de base actual existe? no nueva?</span>
          </p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="form-group">
          <label for="exampleInputEmail1">Parroquia</label>
          <select class="form-control">
            <option>option 1</option>
            <option>option 2</option>
            <option>option 3</option>
            <option>option 4</option>
            <option>option 5</option>
          </select>
          <p>
            <span class="label label-info">Dropdown? de base actual existe? no nueva?</span>
          </p>
        </div>
      </div>


    </div><!-- CLOSE ROW 2 -->

    
           <div class="row">
    <div class="col-md-12">
      <h4><b>Ubicación</b></h4>
      <hr/>
    </div>
  </div>

    <div class="row">
      <div class="col-md-12">
        <div class="form-group">
          <label for="exampleInputEmail1">Sector</label>
          {{ Form::text('fecha_creacion',null,['class'=>'form-control'])}}
          <p>

            <span class="label label-primary">STRING</span>            
            <span class="label label-danger">Falta descripción del campo catalogo? texto ?</span>
          </p>
        </div>
      </div>
    </div>


    <div class="row">

      <div class="col-md-6">
        <div class="form-group">
          <label for="exampleInputEmail1">Calle Principal</label>
          <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Calle Principal">
          <p>
            <span class="label label-primary">STRING</span>  
          </p>
        </div>
      </div>
      <div class="col-md-2">
        <div class="form-group">
          <label for="exampleInputEmail1">Número #</label>
          <input type="email" class="form-control" id="exampleInputEmail1" placeholder="#">
          <p>
            <span class="label label-primary">STRING</span>  
            
          </p>
        </div>
      </div>
    </div>
    <!-- /.row -->

    <div class="row">
      <div class="col-md-6">
        <div class="form-group">
          <label for="exampleInputEmail1">Calle Secundaria</label>
          <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Calle Secundaria">
          <p>
            <span class="label label-primary">STRING</span>  
            
          </p>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="exampleInputEmail1">Referencia</label>
          <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Referencia">
          <p>
           <span class="label label-primary">STRING</span>  
         </p>
       </div>
     </div>
   </div>
   <!-- /.row -->


   <div class="row">
        <div class="col-md-12">
          <h4><b>Representante CIALCO</b></h4>
          <ul>
            <li>El formulario aparece al presionar el boton NUEVO</li>
            <li>El formulario aparece cuanso se selecciona la opción Editar de la tabla</li>
            <li>Los registros se almacenarán en una tabla hija llamada <b>contacto_representante</b></li>
            </ul>
           <p>


                       </p>
          <hr/>
        </div>
  </div>
  
  <div class="row">

        <div class="col-md-6">
          <label for="exampleInputEmail1">Identificación representante</label>
          <div class="input-group">

            <input type="text" class="form-control" placeholder="CI">
            <span class="input-group-btn">
              <button type="button" class="btn btn-info btn-flat">Buscar</button>
            </span>
          </div>
           <p>
               <span class="label label-primary">STRING</span>
               <span class="label label-warning">Consulta a SRI para carga de información</span>
             </p>
        </div>
    
   <div class="col-md-6">
        <div class="form-group">
          <label for="exampleInputEmail1">Nombre representante</label>
          <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Nombre representante">
          <p>
            <span class="label label-primary">STRING</span>
            <span class="label label-warning">Automático luego de consulta</span>   
            
          </p>
        </div>
      </div>
     </div>
     <div class="row">
        <br>
         <div class="col-md-6">
        <div class="form-group">
          <label for="exampleInputEmail1">Fecha de inicio</label>
          <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Fecha de inicio">
          <p>
            <span class="label label-primary">FECHA</span>  
            <span class="label label-warning">Validación: año 1930 - 2030</span>
            
          </p>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="exampleInputEmail1">Fecha Finalización</label>
          <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Fecha Finalización">
          <p>
           <span class="label label-primary">FECHA</span>  
           <span class="label label-warning">Validación: año 1930 - 2030</span>
         </p>
       </div>
     </div>
     </div>
      

 <div class="row">
    <div class="col-md-6">
      <div class="form-group">
        <label for="exampleInputEmail1">Teléfono de contacto</label>
        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Teléfono de contacto">
        <p>
          <span class="label label-defaul">STRING</span>
        </p>
      </div>
    </div>

  </div>

  <div class="row">
  <div class="col-md-12">
    <button type="submit" class="btn btn-success">Guardar información Representante</button>
  </div>
  <hr/>
  </div>

  <div class="row">
  <div class="col-md-12">
  <table class="table table-bordered">
                  <tr>
                    <th style="width: 10px">Identificación</th>
                    <th>Nombre de Representante</th>
                    <th>Telefono de contacto</th>
                    <th>Fecha Inicio</th>
                    <th>Fecha Fin</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                  </tr>
                  @for($i=0; $i<5;$i++)
                                    <tr>
                                      <td>1234567890</td>
                                      <td>Contacto {{$i+1}}</td>
                                      <td>593123123</td>
                                      <td>01/01/2018</td>
                                      <td>01/01/2018</td>
                                      <td>
                                      @if($i==0)
                                      <span class="badge bg-green">ACTIVO</span>
                                      @else
                                      <span class="badge bg-default">INACTIVO</span>
                                      @endif
                                      </td>
                                      <td>
                                      <a href="#">Editar</a>
                                      </td>
                                    </tr>
                  @endfor

                </table>
    <button type="submit" class="btn btn-primary">Nuevo Representante</button>
  </div>
  </div>
      
 <div class="row ">
    <div class="col-md-12">
      <h4><b>Productores vinculados</b></h4>
      <hr/>
    </div>
  </div>
  
  <div class="row">
      <div class="col-md-4">
        <div class="form-group">
          <label for="exampleInputEmail1">Hombres</label>
          <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Hombres">
          <p>
            <span class="label label-primary">NUMBER</span>  
              <span class="label label-warning">4 digitos </span>  
            
          </p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="form-group">
          <label for="exampleInputEmail1">Mujeres</label>
          <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Mujeres">
          <p>
           <span class="label label-primary">Number</span>
             <span class="label label-warning">4 digitos</span>    
         </p>
       </div>
     </div>      
       <div class="col-md-4">
        <div class="form-group">
          <label for="exampleInputEmail1">Total</label>
          <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Total">
          <p>
           <span class="label label-warning">Auto-calculado ?</span>  
           <span class="label label-warning">4 digitos / 5 digitos por suma</span>  
           <span class="label label-primary">Number</span>  
         </p>
       </div>
     </div>
   </div>
   <!-- /.row -->
  

  
 <div class="row">
    <div class="col-md-6">
      <div class="form-group">
        <label for="exampleInputEmail1">Número de organizaciónes participantes</label>
        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Número de organizaciónes participantes">
        <p>
                  <span class="label label-warning">4 digitos</span>  
           <span class="label label-primary">Number</span>  
        </p>
      </div>
    </div>
  </div>
  
      
      
      
       <div class="row">
    <div class="col-md-12">
      <h4><b>Funcionamiento</b></h4>
      <hr/>
    </div>
  </div>
  
  
  <div class="row">
      
      
            <div class="col-md-4">
        <div class="form-group">
          <label for="exampleInputEmail1">Estado</label>
          <select class="form-control">
            <option>ACTIVO</option>
            <option>PASIVO</option>
          </select>
          <p>
            <span class="label label-primary">Boolean</span>
          </p>
        </div>
      </div>
  </div>
  


  <div class="row">
    <div class="col-md-6">
      <div class="form-group">
        <label for="exampleInputEmail1">Horario inicio</label>
        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Horario inicio">
        <p>

          <span class="label label-info">fecha ?</span>
        </p>
      </div>
    </div>

    <div class="col-md-6">
      <div class="form-group">
        <label for="exampleInputEmail1">Horario Fin</label>
        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Horario Fin">
        <p>
          <span class="label label-info">fecha ?</span>
        </p>
      </div>
    </div>

  </div>
  <!-- /.row -->

  <div class="row">
    <div class="col-md-6">
      <div class="form-group">
        <label for="exampleInputEmail1">Día :</label>
        <div>
          <input type="checkbox"> L
          <input type="checkbox"> M
          <input type="checkbox"> Mi
          <input type="checkbox"> J
          <input type="checkbox"> V
          <input type="checkbox"> S
          <input type="checkbox"> D
        </div>

        <p>
          <span class="label label-info">numérico ?</span>
          <span class="label label-warning">formato de entrada ? : </span>
        </p>
      </div>
    </div>
    <div class="col-md-4">
      <div class="form-group">
        <label for="exampleInputEmail1">Frecuencia</label>
        <select class="form-control">
          <option>Diaria</option>
          <option>Semanal</option>
          <option>Quincenal</option>
          <option>Mensual</option>

        </select>
        <p>
          <span class="label label-info">Dropdown? de base actual existe? no nueva?</span>
        </p>
      </div>
    </div>


  </div>
  <!-- /.row -->
  
<div class="row">
    <div class="col-md-12">
      <h4><b>Coordenadas Geográficas del CIALCO</b></h4>
      <hr/>
    </div>
</div>
    <div class="row">
      <div class="col-md-12">
      <b>Coordenadas en X</b>
      </div>

      <div class="col-md-4">
        <div class="form-group">
          <label for="exampleInputEmail1">Grados</label>
          <input type="email" class="form-control" id="exampleInputEmail1" placeholder="">
          <p>
            <span class="label label-primary">STRING</span>
          </p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="form-group">
          <label for="exampleInputEmail1">Minutos</label>
          <input type="email" class="form-control" id="exampleInputEmail1" placeholder="">
          <p>
                       <span class="label label-primary">STRING</span>
         </p>
       </div>
     </div>      
       <div class="col-md-4">
        <div class="form-group">
          <label for="exampleInputEmail1">Segundos</label>
          <input type="email" class="form-control" id="exampleInputEmail1" placeholder="">
          <p>
                       <span class="label label-primary">STRING</span>
         </p>
       </div>
     </div>
   </div>
   <!-- /.row -->
       <div class="row">
         <div class="col-md-12">
         <b>Coordenadas en Y</b>
         </div>

         <div class="col-md-4">
           <div class="form-group">
             <label for="exampleInputEmail1">Grados</label>
             <input type="email" class="form-control" id="exampleInputEmail1" placeholder="">
             <p>
               <span class="label label-primary">STRING</span>
             </p>
           </div>
         </div>
         <div class="col-md-4">
           <div class="form-group">
             <label for="exampleInputEmail1">Minutos</label>
             <input type="email" class="form-control" id="exampleInputEmail1" placeholder="">
             <p>
                          <span class="label label-primary">STRING</span>
            </p>
          </div>
        </div>
          <div class="col-md-4">
           <div class="form-group">
             <label for="exampleInputEmail1">Segundos</label>
             <input type="email" class="form-control" id="exampleInputEmail1" placeholder="">
             <p>
                          <span class="label label-primary">STRING</span>
            </p>
          </div>
        </div>
      </div>
      <!-- /.row -->
   
<div class="row">
    <div class="col-md-12">
      <h4><b>Zona UTM</b></h4>
      <hr/>
    </div>
</div>
    <div class="row"><!--  ROW 2 -->

      <div class="col-md-4">
        <div class="form-group">
          <label for="exampleInputEmail1">Norte</label>
          <select class="form-control">
            <option>15N</option>
            <option>16N</option>
            <option>17N</option>
            <option>18N</option>

          </select>
        </div>
      </div>

      <div class="col-md-4">
        <div class="form-group">
          <label for="exampleInputEmail1">Sur</label>
          <select class="form-control">
            <option>15S</option>
            <option>16S</option>
            <option>17S</option>
            <option>18S</option>
          </select>

        </div>
      </div>



    </div><!-- CLOSE ROW 2 -->

<div class="row">
    <div class="col-md-12">
      <h4><b>Consumidores Vinculados</b></h4>
      <hr/>
    </div>
</div>
  
 <div class="row">
    <div class="col-md-6">
      <div class="form-group">
        <label for="exampleInputEmail1">Número de consumidores vinculados</label>
        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Número de consumidores vinculados">
        <p>
                  <span class="label label-warning">8 digitos</span>  
           <span class="label label-primary">NUMBER</span>  
        </p>
      </div>
    </div>
  </div>

</div>

<div class="box-footer">
  <button type="submit" class="btn btn-primary">Almacenar</button>
</div>
</div>

@stop



@section('css')

<link rel="stylesheet" href="/css/admin_custom.css">

@stop



@section('js')

<script> console.log('Hi!'); </script>

@stop