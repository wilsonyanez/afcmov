@extends('adminlte::page')



@section('title', 'Dashboard')



@section('content_header')

    <h1>RQ21-WEB-HU087</h1>
    <p>Como Técnico de Territorio, quiero Registrar Datos de Productores y Organizaciones vinculadas al CIALCO, que me solicita el Administrador AFC para validar la participación en el Mercado de los Circuitos Alternativos de Comercialización de la AFC.</p>
    "Diseño: Cumplir formato detallado en los archivos:
    RQ21-WEB-HU087-DIS072 Organizaciones vinculadas al CIALCO.png
    "
    "Usabilidad: Cumplir con el detalle descrito en pestaña funcionalidad con identificación: RQ21-WEB-HU087-FUN
    "
    "Rendimiento: Tiempo de respuesta inferior a 5 segundos
    "
    "Satisfacción: Cumplimiento de Pruebas funcionales
    "
@stop



@section('content')

    <p>Welcome to this beautiful admin panel - HDTuto.com.</p>

    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Participantes</h3>
            <p>Organizaciones Vinculadas de Circuito</p>


        </div>
        <div class="box-body" class="col-md-12">
            <p>Identificacion Hecho / Derecho</p>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">

                        <div class="checkbox">
                            <label>
                                <input type="checkbox">
                                Hecho
                            </label>
                        </div>

                        <div class="checkbox">
                            <label>
                                <input type="checkbox" >
                                Derecho
                            </label>
                        </div>
                    </div>


                </div>
            </div>
            <!-- /.row -->
            <div class="row">

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">RUC #</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="RUC">

                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Razón Social</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Razón Social">
                        <p>
                            <span class="label label-info">Búsqueda?</span>
                            <span class="label label-info">Dropdown?</span>
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Provincia</label>
                        <select class="form-control">
                            <option>option 1</option>
                            <option>option 2</option>
                            <option>option 3</option>
                            <option>option 4</option>
                            <option>option 5</option>
                        </select>

                        <p>
                            <span class="label label-info">Dropdown? de base actual existe? no nueva?</span>
                        </p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Cantón</label>
                        <select class="form-control">
                            <option>option 1</option>
                            <option>option 2</option>
                            <option>option 3</option>
                            <option>option 4</option>
                            <option>option 5</option>
                        </select>
                        <p>
                            <span class="label label-info">Dropdown? de base actual existe? no nueva?</span>
                        </p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Parroquia</label>
                        <select class="form-control">
                            <option>option 1</option>
                            <option>option 2</option>
                            <option>option 3</option>
                            <option>option 4</option>
                            <option>option 5</option>
                        </select>
                        <p>
                            <span class="label label-info">Dropdown? de base actual existe? no nueva?</span>
                        </p>
                    </div>
                </div>

            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Provincia</label>
                        <select class="form-control">
                            <option>Si</option>
                            <option>No</option>
                        </select>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Acreditado al Mag</label>
                        <select class="form-control">
                            <option>Si</option>
                            <option>No</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="row">

                <div class="col-md-8">
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">Nombre de Representante</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Nombre">
                        <p>
                            <span class="label label-info">Búsqueda?</span>
                            <span class="label label-info">Dropdown?</span>
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">

                <div class="col-md-8">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Contacto de Representante</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Contacto">
                    </div>
                </div>
            </div>
            <div class="row">

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Teléfono del Representante</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Teléfono">
                    </div>
                </div>
            </div>
            <div class="row">

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Email del Representante</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Email">
                    </div>
                </div>
            </div>
            <div class="row">

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Número Total de Productores de la Organización</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="# Total de Productores de la Organización">

                    </div>
                </div>
            </div>
            <div class="row">

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Número de Productores que participan en el Circuito</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="# Hombres"><br>
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="# Mujeres">

                    </div>
                </div>
            </div>
        </div>

        <div class="box-footer">
            <button type="submit" class="btn btn-primary">Adicionar</button>
        </div>
        <div class="box-footer" align="center">
            <button type="submit" class="btn btn-primary">Anterior</button>
            <button type="submit" class="btn btn-primary">Siguiente</button>
        </div>
    </div>

@stop



@section('css')

    <link rel="stylesheet" href="/css/admin_custom.css">

@stop



@section('js')

    <script> console.log('Hi!'); </script>

@stop