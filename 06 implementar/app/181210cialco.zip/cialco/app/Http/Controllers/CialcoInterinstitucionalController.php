<?php

namespace App\Http\Controllers;

use App\Catalogs\AccionFortalecimiento;
use App\Catalogs\ApoyoInstitucional;
use App\Catalogs\UbicacionGeografica;
use App\Entities\Cialco;
use App\Entities\CialcoInterinstitucional;
use App\Http\Requests\StoreCialcoRequest;
use App\Http\Requests\StoreProductorRequest;
use App\Http\Requests\StoreAccionFortalecimientoRequest;
use App\Http\Requests\StoreApoyoInstitucionalRequest;
use App\Http\Requests\StoreUbicacionGeograficaRequest;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;


class CialcoInterinstitucionalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $grid = \DataGrid::source(CialcoInterinstitucional::with('cialco', 'accionfortalecimiento','apoyoinstitucional', 'ubicacionprovincial', 'ubicacioncantonal', 'ubicacionparroquial'));
        $grid->add('int_cialco_interins_id','ID', true)->style("width:100px");
        $grid->add('int_descripcion','Descripción',true);
        $grid->add('{{$cialco->cia_nombre}}','Cialco');
        $grid->add('{{$accionfortalecimiento->afr_descripcion}}','Accion Fortalecimiento');
        $grid->add('{{$apoyoinstitucional->ain_descripcion}}','Apoyo Institucional');
        $grid->add('texto_provincial','provincial',true);
        $grid->add('{{$ubicacionprovincial->uge_nombre}}','Ubicación Provincial');
        $grid->add('texto_cantonal','Cantonal',true);
        $grid->add('{{$ubicacioncantonal->uge_nombre}}','Ubicación Cantonal');
        $grid->add('texto_parroquial','Parroquial',true);
        $grid->add('{{$ubicacionparroquial->uge_nombre}}','Ubicación Parroquial');
        $grid->add('texto_otro','Otro',true);
        $grid->add('int_fecha_inicio','Fecha Inicio',true);
        $grid->add('int_fecha_fin','Fecha Fin',true);
        $grid->add('texto_estado','Estado',true);
        $grid->add('<a href="/cialcointerinstitucional/{{$int_cialco_interins_id}}"><span class="glyphicon glyphicon-eye-open"> </span></span></a>','');
        $grid->link('/cialcointerinstitucional/create',"Nuevo", "TR");
        $grid->add('<a href="/cialcointerinstitucional/{{$int_cialco_interins_id}}/edit"><span class="glyphicon glyphicon-pencil"> </span></span></a>','');
        $grid->paginate(20);

        $results = CialcoInterinstitucional::get();
        return view('cialcointerinstitucional.index', ['results' => $results,'grid'=>$grid]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
	public function cialco()
    {
		$cialco = Cialco::with('cialco')->get();
        return view('cialco.show', compact('$cialco'));
    }

    public function accionfortalecimiento()
    {
		$accion = Accion::with('accionfortalecimiento')->get();
        return view('cialcointerinstitucional.show', compact('$accion'));
    }

    public function apoyoinstitucional()
    {
		$apoyo = Apoyo::with('apoyoinstitucional')->get();
        return view('cialcointerinstitucional.show', compact('$apoyo'));
    }

    public function ubicacionprovincial()
    {
		$provincial = Provincial::with('ubicacionprovincial')->get(); 
        return view('cialcointerinstitucional.show', compact('$provincial'));
    }

    public function ubicacioncantonal()
    {
		$cantonal = Cantonal::with('ubicacioncantonal')->get(); 
        return view('cialcointerinstitucional.show', compact('$cantonal'));
    }

    public function ubicacionparroquial()
    {
		$parroquial = Parroquial::with('ubicacionparroquial')->get(); 
        return view('cialcointerinstitucional.show', compact('$parroquial'));
    }

    public function create()
    {
		$cialcos = Cialco::pluck('cia_nombre', 'cia_cialco_id');
        $accionfortalecimientos = AccionFortalecimiento::pluck('afr_descripcion', 'afr_accion_fortalecimiento_id');
        $apoyoinstitucionals = ApoyoInstitucional::pluck('ain_descripcion', 'ain_apoyo_institucional_id');
        $ubicacionprovincials = UbicacionGeografica::pluck('uge_nombre', 'uge_ubicacion_geografica_id');
        $ubicacioncantonals = UbicacionGeografica::pluck('uge_nombre', 'uge_ubicacion_geografica_id');
        $ubicacionparroquials = UbicacionGeografica::pluck('uge_nombre', 'uge_ubicacion_geografica_id');
        return view('cialcointerinstitucional.create', ['cialcos' => $cialcos, 'accionfortalecimientos' => $accionfortalecimientos, 'apoyoinstitucionals' => $apoyoinstitucionals, 'ubicacionprovincials' => $ubicacionprovincials, 'ubicacioncantonals' => $ubicacioncantonals, 'ubicacionparroquials' => $ubicacionparroquials]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreCialcoInterinstitucionalRequest $request)
    {
        try {
            CialcoInterinstitucional::create($request->all());
            Session::flash('flash_message', Config::get('session.create'));
        } catch (\Exception $e) {
            Session::flash('error', Config::get('session.error'));
            return back()->withInput();
        }

        return redirect()->route('cialcointerinstitucional.show', ['id' => $cialcointerinstitucional->int_cialco_interins_id]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $result= CialcoInterinstitucional::find($id);
        return view('cialcointerinstitucional.show',['result' =>$result]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $result = CialcoInterinstitucional::find($id);

		$cialcos = Cialco::pluck('cia_nombre', 'cia_cialco_id');
        $accionfortalecimientos = AccionFortalecimiento::pluck('afr_descripcion', 'afr_accion_fortalecimiento_id');
        $apoyoinstitucionals = ApoyoInstitucional::pluck('ain_descripcion', 'ain_apoyo_institucional_id');
        $ubicacionprovincials = UbicacionGeografica::pluck('uge_nombre', 'uge_ubicacion_geografica_id');
        $ubicacioncantonals = UbicacionGeografica::pluck('uge_nombre', 'uge_ubicacion_geografica_id');
        $ubicacionparroquials = UbicacionGeografica::pluck('uge_nombre', 'uge_ubicacion_geografica_id');

        return view('cialcointerinstitucional.edit', ['result'=>$result, 'cialcos'=>$cialcos, 'accionfortalecimientos' => $accionfortalecimientos, 'apoyoinstitucionals' => $apoyoinstitucionals, 'ubicacionprovincials' => $ubicacionprovincials, 'ubicacioncantonals' => $ubicacioncantonals, 'ubicacionparroquials' => $ubicacionparroquials]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $result = CialcoInterinstitucional::find($id);

        request()->validate([
          'int_cialco_id' => 'required',
          'int_accion_fortalecimiento_id' => 'required',
          'int_apoyo_institucional_id' => 'required',
          'int_descripcion' => 'required',
          'int_provincial',
          'int_gad_provincial_id',
          'int_cantonal',
          'int_gad_cantonal_id',
          'int_parroquial',
          'int_gad_parroquial_id',
          'int_otro',
          'int_fecha_inicio' => 'required',
          'int_estado' => 'required',
        ]);

        $input = $request->all();
        $result->fill($input)->save();
        Session::flash('flash_message','El registro fue actualizado exitosamente');

        return redirect()->route('cialcointerinstitucional.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}