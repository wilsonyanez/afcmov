<?php

namespace App\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;

class StoreCialcoInterinstitucionalRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
          'int_cialco_id' =>'required',
          'int_accion_fortalecimiento_id' =>'required',
          'int_apoyo_institucional_id' =>'required',
          'int_descripcion' =>'alpha|max:256|required',
          'int_fecha_inicio' =>'required|date',			
          'int_estado' =>'required',
        ];
    }
    public function messages(){
        return [
          'int_cialco_id.required' => 'Cialco es requerido',
          'int_accion_fortalecimiento_id.required' => 'Acción de fortalecimiento es requerida',
          'int_apoyo_institucional_id.required' => 'Apoyo Institucional es requerido',
          'int_descripcion.required' => 'Descripción es requerido',
          'int_fecha_inicio.required' => 'Fecha Inicio es requerida',
          'int_estado.required' => 'Estado es requerido',
        ];
    }
}
