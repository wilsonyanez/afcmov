<?php

use Illuminate\Database\Seeder;

class UsuariosFakeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create();
        for($i=0 ; $i<100; $i++){
            \DB::table('usuarios')->insert([
                'usu_nombre'=>$faker->name,
                'username'=>$faker->userName,
                'email'=>$faker->email,
                'password'=>bcrypt('1234567890'),
                'usu_fecha_creacion'=>date_create('now UTC'),
                'usu_fecha_actualizacion'=>date_create('now UTC')
            ]);
        }
    }
}
