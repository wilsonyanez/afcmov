

<?php $__env->startSection('title', 'Panel de Control'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Panel de Control</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Panel</h3>
        </div>




        <?php $__env->stopSection(); ?>



<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>