<?php

use Illuminate\Database\Seeder;

class CialcoMontoVentaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('cialco_monto_venta')->delete();
        $faker = Faker\Factory::create();

        for ($i = 0; $i < 200; $i++) {
            \DB::table('cialco_monto_venta')->insert([
                'cmv_ejercicio' => $faker->numberBetween(2010, 2030),
                'cmv_periodo' => $faker->numberBetween(1, 12),
                'cmv_monto' => $faker->numberBetween(0.01, 10000.00),
                'cmv_estado' => $faker->numberBetween(0, 1),
                'cmv_fecha_inicio' => date_create('now UTC'),
                'cmv_fecha_fin' => date_create('now UTC'),
                'cmv_fecha_inserta' => date_create('now UTC'),
                'cmv_fecha_actualiza' => date_create('now UTC'),

                /*                'coa_cialco_id' => Cialco::inRandomOrder()->get()->first()->cia_cialco_id,    */
                'cmv_cialco_id' => $faker->numberBetween(1, 100),
            ]);
        }
    }
}