# Instalación componente rapyd
- https://github.com/zofe/rapyd-laravel
```
composer require zofe/rapyd
php artisan vendor:publish
```
# Comandos PHP Artisan
Para validaciones
```
php artisan make:request StoreCialcoRequest
```
https://laracasts.com/discuss/channels/requests/laravel-5-validation-request-how-to-handle-validation-on-update

#Carga de datos
luego de ejecutar php artisan migrate
php artisan db:seed --class=UsuariosSeeder
php artisan db:seed --class=UsuariosFakeSeeder
php artisan db:seed --class=PermanenciaSeeder
php artisan db:seed --class=ModalidadSeeder



#Instalación Laravel Collective
composer require "laravelcollective/html":"^5.4.0"

#Instalación Faker para datos de prueba
composer require fzaninotto/faker

## Actividades
https://hdtuto.com/article/laravel-56-adminlte-bootstrap-theme-installation-example
- Instalación de template AdminLTE
    composer require jeroennoten/laravel-adminlte
- Generación de rutas de AUTH
    php artisan make:auth
    
    
https://stackoverflow.com/questions/39374472/laravel-how-can-i-change-the-default-auth-password-field-name
https://stackoverflow.com/questions/51168363/changing-email-column-name-in-laravel-5-6-in-default-users-table
https://laravel.io/forum/how-to-change-password-field-name
https://tutsforweb.com/laravel-auth-login-email-username-one-field/
