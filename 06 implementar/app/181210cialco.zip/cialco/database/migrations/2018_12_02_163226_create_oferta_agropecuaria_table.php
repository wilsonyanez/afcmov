<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOfertaAgropecuariaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('oferta_agropecuaria', function (Blueprint $table) {
            $table->increments('ofa_oferta_agropecuaria_id');
            $table->integer('ofa_orden')->default(0);
            $table->text('ofa_descripcion');
            // COLUMNAS DE CONTROL
            $table->boolean('ofa_estado')->default(true);

            $table->date('ofa_fecha_inicio')->nullable();
            $table->date('ofa_fecha_fin')->nullable();

            $table->integer('ofa_usuario_inserta')->unsigned()->nullable();
            $table->timestamp('ofa_fecha_inserta')->nullable();

            $table->integer('ofa_usuario_actualiza')->unsigned()->nullable();
            $table->timestamp('ofa_fecha_actualiza')->nullable();

            $table->integer('ofa_usuario_elimina')->unsigned()->nullable();
            $table->timestamp('ofa_fecha_elimina')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('oferta_agropecuaria');
    }
}
