<?php

namespace App\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;

class StoreCialcoFrecuenciaRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'cfr_hora_inicio' =>'required',
            'cfr_hora_fin' =>'required',
            'cfr_dias' =>'integer|required',
            'cfr_descripcion' =>'alpha|max:256|required',
            'cfr_estado' =>'required',
            'cfr_fecha_inicio' =>'required|date',
			'cfr_frecuencia_id' =>'required',
        ];
    }

    public function messages(){
        return [
		    'cfr_hora_inicio.required' => 'Hora de inicio es requerida',
            'cfr_hora_fin.required' => 'Fecha de fin es requerido',
            'cfr_dias.required' => 'Días es requerido',
            'cfr_descripcion.required' => 'Descripción es requerido',
            'cfr_estado.required' => 'Estado es requerido',
            'cfr_fecha_inicio.required' => 'Fecha de inicio es requerido',
            'cfr_frecuencia_id.required' => 'Frecuencia es requerido',
        ];
    }
}