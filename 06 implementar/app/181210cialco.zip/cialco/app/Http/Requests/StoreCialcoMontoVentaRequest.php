<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreCialcoMontoVentaRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
		    'cmv_cialco_id' =>'required',
            'cmv_ejercicio' =>'integer|required',
            'cmv_periodo' =>'integer|required',
            'cmv_monto' =>'numeric|required',
            'cmv_fecha_inicio' =>'date|required',
            'cmv_estado' =>'required',

        ];
    }
    public function messages(){
        return [
            'cmv_cialco_id.required' =>'Cialco es requerido',
            'cmv_ejercicio.required' => 'Año es requerido',
            'cmv_periodo.required' => 'Mes es requerida',
            'cmv_monto.required' => 'Monto es requerido',
            'cmv_fecha_inicio.required' =>'Fecha de inicio es requerida',
            'cmv_estado.required' => 'Estado es requerido',
        ];
    }
}