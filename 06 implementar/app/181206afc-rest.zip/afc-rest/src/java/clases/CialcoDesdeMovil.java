/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Wilson Yánez
 */
public class CialcoDesdeMovil {
    private String cialco;
    private String cialcoDetv;
    private String cialcoDeth;

    public CialcoDesdeMovil() {
    }

    public CialcoDesdeMovil(String cialco, String cialcoDetv, String cialcoDeth) {
        this.cialco = cialco;
        this.cialcoDetv = cialcoDetv;
        this.cialcoDeth = cialcoDeth;
    }

    public String getCialco() {
        return cialco;
    }

    public void setCialco(String cialco) {
        this.cialco = cialco;
    }

    public String getCialcoDetv() {
        return cialcoDetv;
    }

    public void setCialcoDetv(String cialcoDetv) {
        this.cialcoDetv = cialcoDetv;
    }

    public String getCialcoDeth() {
        return cialcoDeth;
    }

    public void setCialcoDeth(String cialcoDeth) {
        this.cialcoDeth = cialcoDeth;
    }
    
    public void imprimirCial(){
        System.out.println(cialco+" "+cialcoDetv+" "+cialcoDeth);
    }

}