<?php

use App\Catalogs\Frecuencia;
use App\Entities\Cialco;
use Illuminate\Database\Seeder;

class CialcoFrecuenciaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('cialco_frecuencia')->delete();
        $faker = Faker\Factory::create();
        $arr = [
            'L' => true,
            'M' => false,
            'Mi' => true,
            'J' => false,
            'V' => true,
            'S' => false,
            'D' => true
        ];

        for ($i = 0; $i < 200; $i++) {
            \DB::table('cialco_frecuencia')->insert([

                'cfr_dias' => json_encode($arr),
                'cfr_descripcion' => $faker->address,

                'cfr_fecha_inicio' => date_create('now UTC'),
                'cfr_fecha_fin' => date_create('now UTC'),

                'cfr_hora_inicio' => date_create('now UTC'),
                'cfr_hora_fin' => date_create('now UTC'),
                'cfr_fecha_inserta' => date_create('now UTC'),
                'cfr_fecha_actualiza' => date_create('now UTC'),

                'cfr_frecuencia_id' => Frecuencia::inRandomOrder()->get()->first()->fre_frecuencia_id,
                'cfr_cialco_id' => Cialco::inRandomOrder()->get()->first()->cia_cialco_id,

            ]);
        }
    }
}
