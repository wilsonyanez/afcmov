<?php

namespace App\Http\Controllers;

use App\Catalogs\Producto;
use App\Entities\Cialco;
use App\Entities\CialcoProducto;
use App\Http\Requests\StoreCialcoRequest;
use App\Http\Requests\StoreProductoRequest;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;

class CialcoProductoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $grid = \DataGrid::source(CialcoProducto::with('cialco', 'producto'));
        $grid->add('cpr_cialco_producto_id','ID', true)->style("width:100px");
        $grid->add('{{$cialco->cia_nombre}}','Cialco');
        $grid->add('{{$producto->prd_nombre}}','Producto');
        $grid->add('cpr_ejercicio','Año',true);
        $grid->add('cpr_periodo','Mes',true);
        $grid->add('cpr_precio','Precio',true);
        $grid->add('cpr_unidad','Unidad',true);
        $grid->add('cpr_fecha_inicio','Fecha Inicio',true);
        $grid->add('cpr_fecha_fin','Fecha Fin',true);
        $grid->add('texto_estado','Estado',true);
        $grid->add('<a href="/cialcoproducto/{{$cpr_cialco_producto_id}}"><span class="glyphicon glyphicon-eye-open"> </span></span></a>','');
        $grid->link('/cialcoproducto/create',"Nuevo", "TR");
        $grid->add('<a href="/cialcoproducto/{{$cpr_cialco_producto_id}}/edit"><span class="glyphicon glyphicon-pencil"> </span></span></a>','');
        $grid->paginate(20);

        $results = CialcoProducto::get();
        return view('cialcoproducto.index',['results'=>$results,'grid'=>$grid]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
	 
	public function cialco()
    {
		$cialco = Cialco::with('cialco')->get();
        return view('cialco.show', compact('$cialco'));
    }

    public function producto()
    {
		$producto = Producto::with('producto')->get();
        return view('producto.show', compact('$producto'));
    }

    public function create()
    {
		$cialcos = Cialco::pluck('cia_nombre', 'cia_cialco_id');
        $productos = Producto::pluck('prd_nombre', 'prd_producto_id');
        return view('cialcoproducto.create', ['cialcos' => $cialcos, 'productos' => $productos]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreCialcoProductoRequest $request)
    {
        try {
            $cialcoproducto=CialcoProducto::create($request->all());
            Session::flash('flash_message', Config::get('session.create'));
        } catch (\Exception $e) {
            Session::flash('error', Config::get('session.error'));
            return back()->withInput();
        }

        return redirect()->route('cialcoproducto.show', ['id' => $cialcoproducto->cpr_cialco_producto_id]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $result= CialcoProducto::find($id);
        return view('cialcoproducto.show',['result' =>$result]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $result = CialcoProducto::find($id);
		$cialcos = Cialco::pluck('cia_nombre', 'cia_cialco_id');
        $productos = Producto::pluck('prd_nombre', 'prd_producto_id');
        return view('cialcoproducto.edit', ['result'=>$result, 'cialcos'=>$cialcos, 'productos' => $productos]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $result = CialcoProducto::find($id);

        request()->validate([
          'cpr_cialco_id' => 'required',
          'cpr_producto_id' => 'required',
          'cpr_ejercicio' => 'required',
          'cpr_periodo' => 'required',
          'cpr_precio' => 'required',
          'cpr_unidad' => 'required',
          'cpr_fecha_inicio' => 'required',
          'cpr_estado' => 'required',
        ]);

        $input = $request->all();
        $result->fill($input)->save();
        Session::flash('flash_message','El registro fue actualizado exitosamente');

        return redirect()->route('cialcoproducto.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}