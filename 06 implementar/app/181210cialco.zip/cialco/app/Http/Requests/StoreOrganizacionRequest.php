<?php

namespace App\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;

class StoreOrganizacionRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
          'org_hecho_derecho' =>'required',
          'org_ruc' =>'required|digits:13|integer',
          'org_razon_social' =>'alpha|max:256|required',
          'org_nro_productores_total' =>'integer|required',
          'org_nro_productores_hombres' =>'integer|required',
          'org_nro_productores_mujeres' =>'integer|required',
          'org_fecha_inicio' =>'date|required',
          'org_estado' =>'required',
        ];
    }
    public function messages()
    {
        return [
          'org_hecho_derecho.required' =>'Organización de Hecho o Derecho es requerido',
          'org_ruc.required' =>'Número de RUC es requerido',
          'org_razon_social.required' =>'Razón Social es requerido',
          'org_nro_productores_total.required' =>'Número Total de Productores es requerido',
          'org_nro_productores_hombres.required' =>'Número de Productores Hombres es requerido',
          'org_nro_productores_mujeres.required' =>'Número de Productores Mujeres es requerido',
          'org_fecha_inicio.required' => 'Fecha de inicio es requerido',
          'org_estado.required' => 'Estado es requerido',
        ];
    }
}