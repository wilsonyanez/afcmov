@extends('adminlte::page')

@section('title', 'UTM')

@section('content_header')
    <h1>UTM</h1>
@stop

@section('content')
    {!! Form::model($result, ['method' => 'PATCH','route' => ['utm.update', 'id'=>$result->utm_utm_id]]) !!}
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Catálogo Utm</h3>
        </div>
        <div class="box-body">
            <div class="row"> <!-- ROW 1 -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="utm_descripcion">Descripción</label>
                        {{ Form::text('utm_descripcion',$result->utm_descripcion,['class'=>'form-control', 'required' => 'required|alpha'])}}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="utm_orden">Orden</label>
                        {{ Form::number('utm_orden',$result->utm_orden,['class'=>'form-control', 'required' => 'required|integer'])}}
                    </div>
                </div>
				<div class="col-md-3">
					<div class="form-group">
						<label for="utm_fecha_inicio">Fecha Inicio</label></br>
							{{ Form::date('utm_fecha_inicio', $result->utm_fecha_inicio, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
							@include('include.error_form_element',['name'=>'utm_fecha_inicio'])
					</div>
				</div>
            </div>
            <div class="row"> <!-- ROW 2 -->
				<div class="col-md-3">
					<div class="form-group">
						<label for="utm_fecha_fin">Fecha Fin</label></br>
							{{ Form::date('utm_fecha_fin', $result->utm_fecha_fin, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
							@include('include.error_form_element',['name'=>'utm_fecha_fin'])
					</div>
				</div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="utm_estado">Estado</label>
                        {{ Form::select('utm_estado',['1' => 'Activo', '0' => 'Inactivo'],$result->utm_estado,['class'=>'form-control'])}}
						@include('include.error_form_element',['name'=>'utm_estado'])
                    </div>
                </div>

            </div>
        </div>

	<div class="box-footer">
		<button type="submit" class="btn btn-primary">Editar</button>
	</div>
	{!! Form::close() !!}
	<div class="box-footer">
		<a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
	</div>
	@stop
	@section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
	@stop
	@section('js')
@stop