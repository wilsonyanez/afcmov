@extends('adminlte::page')

@section('title', 'Modalidades')

@section('content_header')
    <h1>Represenante</h1>
@stop

@section('content')
    <div class="box box-primary">
        <div class="box-header with-border">
            <h2 class="page-header"><i class="fa fa-globe"></i>Detalle Representante</h2>

            <div class="row invoice-info">
                <div class="col-sm-4 invoice-col">
                    <p><b>Cialco: </b>{{$result->cialco->cia_nombre}}</p>
                    <p><b>Identificación: </b>{{$result->rep_identificacion}}</p>
                    <p><b>Nombre: </b>{{$result->rep_contacto}}</p>
                    <p><b>Correo: </b>{{$result->rep_correo_electronico}}</p>
                    <p><b>Estado: </b>{!!$result->texto_estado_html!!}</p>

                </div>
            </div>
        </div>
        <div class="box-footer">
            <a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
        </div>

        @stop



        @section('css')

            <link rel="stylesheet" href="/css/admin_custom.css">

        @stop



        @section('js')

            <script> console.log('Hi!'); </script>

@stop