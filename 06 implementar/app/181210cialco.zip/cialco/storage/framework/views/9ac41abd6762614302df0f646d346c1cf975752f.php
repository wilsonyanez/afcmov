
<?php $__env->startSection('title', 'Organizaciones'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Organizaciones</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="box box-primary">
        <div class="box-header with-border">
            <h2 class="page-header">
                <i class="fa fa-globe"></i> Listado
            </h2>
        </div>
        <div class="row">
            <div class="col-xs-14 table-responsive">
                <table class="table table-striped">
                <tr>
                  <th>ID</th>
                  <th>Organización hecho/derecho</th>
                  <th>RUC</th>
                  <th>Razon Social</th>
                  <th>Registro SEPS</th>
                  <th>Acreditado MAG</th>
                  <th>Nro Productores Total</th>
                  <th>Nro Productores Hombres</th>
                  <th>Nro Productores Mujeres</th>
                  <th>Fecha Inicio</th>
                  <th>Fecha Fin</th>
                  <th>Estado</th>
                  <th>Fecha Creación</th>
				  <th>Acciones</th>
                </tr>
                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($key+1); ?></td>
                  <td><?php echo $item->texto_hecho_derecho_html; ?></td>
                  <td><?php echo e($item->org_ruc); ?></td>
                  <td><?php echo e($item->org_razon_social); ?></td>
                  <td><?php echo $item->texto_registro_seps_html; ?></td>
                  <td><?php echo $item->texto_acreditado_mag_html; ?></td>
                  <td><?php echo e($item->org_nro_productores_total); ?></td>
                  <td><?php echo e($item->org_nro_productores_hombres); ?></td>
                  <td><?php echo e($item->org_nro_productores_mujeres); ?></td>
                  <td><?php echo e($item->org_fecha_inicio); ?></td>
                  <td><?php echo e($item->org_fecha_fin); ?></td>
                  <td><?php echo $item->texto_estado_html; ?></td>
                  <td><?php echo e($item->org_fecha_inserta); ?></td>
                  <td>
                     <a href="<?php echo e(route('organizacion.show',['id'=>$item->org_organizacion_id])); ?> "class="label label-primary">Ver</a>
                     <a href="<?php echo e(route('organizacion.edit',['id'=>$item->org_organizacion_id])); ?>" class="label label-primary">Editar</a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </table>
            </div>
        </div>
        <div class="box-footer">
        
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>