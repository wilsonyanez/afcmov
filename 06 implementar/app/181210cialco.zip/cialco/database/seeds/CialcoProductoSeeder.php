<?php

use Illuminate\Database\Seeder;

class CialcoProductoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('cialco_producto')->delete();
        $faker = Faker\Factory::create();

        for ($i = 0; $i < 200; $i++) {
            \DB::table('cialco_producto')->insert([
                'cpr_ejercicio' => $faker->numberBetween(2010, 2030),
                'cpr_periodo' => $faker->numberBetween(1, 12),
                'cpr_precio' => $faker->numberBetween(0.01, 100000.00),
                'cpr_unidad' => $faker->numberBetween(1, 4),
                'cpr_estado' => $faker->numberBetween(0, 1),
                'cpr_fecha_inicio' => date_create('now UTC'),
                'cpr_fecha_fin' => date_create('now UTC'),
                'cpr_fecha_inserta' => date_create('now UTC'),
                'cpr_fecha_actualiza' => date_create('now UTC'),

                /*                'coa_cialco_interinstitucional_id' => OfertaAgropecuaria::inRandomOrder()->get()->first()->ofa_cialco_interinstitucional_id, */
                'cpr_producto_id' => $faker->numberBetween(1, 186),
                /*                'coa_cialco_id' => Cialco::inRandomOrder()->get()->first()->cia_cialco_id,    */
                'cpr_cialco_id' => $faker->numberBetween(1, 100),
            ]);
        }
    }
}
