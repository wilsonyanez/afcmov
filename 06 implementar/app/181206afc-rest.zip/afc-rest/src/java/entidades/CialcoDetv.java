/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Wilson Yánez
 */
@Entity
@Table(name = "cialco_detv")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CialcoDetv.findAll", query = "SELECT o FROM CialcoDetv o")
    , @NamedQuery(name = "CialcoDetv.findByIdOdetv", query = "SELECT o FROM CialcoDetv o WHERE o.idCdetv = :idCdetv")
    , @NamedQuery(name = "CialcoDetv.findByCodMod", query = "SELECT o FROM CialcoDetv o WHERE o.codMod = :codMod")
    , @NamedQuery(name = "CialcoDetv.findByOrden", query = "SELECT o FROM CialcoDetv o WHERE o.orden = :orden")
    , @NamedQuery(name = "CialcoDetv.findByCodPreg", query = "SELECT o FROM CialcoDetv o WHERE o.codPreg = :codPreg")
    , @NamedQuery(name = "CialcoDetv.findByValor", query = "SELECT o FROM CialcoDetv o WHERE o.valor = :valor")
    , @NamedQuery(name = "CialcoDetv.findByClave", query = "SELECT o FROM CialcoDetv o WHERE o.clave = :clave")})
public class CialcoDetv implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_cdetv")
    private Integer idCdetv;
    @Size(max = 10)
    @Column(name = "cod_mod")
    private String codMod;
    @Column(name = "orden")
    private Integer orden;
    @Size(max = 20)
    @Column(name = "cod_preg")
    private String codPreg;
    @Size(max = 2147483647)
    @Column(name = "valor")
    private String valor;
    @Size(max = 30)
    @Column(name = "clave")
    private String clave;
    @JoinColumn(name = "cod_cial", referencedColumnName = "id_cialco")
    @ManyToOne
    private Cialco codCial;

    public CialcoDetv() {
    }

    public CialcoDetv(Integer idCdetv) {
        this.idCdetv = idCdetv;
    }

    public Integer getIdOdetv() {
        return idCdetv;
    }

    public void setIdOdetv(Integer idCdetv) {
        this.idCdetv = idCdetv;
    }

    public String getCodMod() {
        return codMod;
    }

    public void setCodMod(String codMod) {
        this.codMod = codMod;
    }

    public Integer getOrden() {
        return orden;
    }

    public void setOrden(Integer orden) {
        this.orden = orden;
    }

    public String getCodPreg() {
        return codPreg;
    }

    public void setCodPreg(String codPreg) {
        this.codPreg = codPreg;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public Cialco getCodCial() {
        return codCial;
    }

    public void setCodCial(Cialco codCial) {
        this.codCial = codCial;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idCdetv != null ? idCdetv.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CialcoDetv)) {
            return false;
        }
        CialcoDetv other = (CialcoDetv) object;
        if ((this.idCdetv == null && other.idCdetv != null) || (this.idCdetv != null && !this.idCdetv.equals(other.idCdetv))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.CialcoDetv[ idCdetv=" + idCdetv + " ]";
    }
    
}
