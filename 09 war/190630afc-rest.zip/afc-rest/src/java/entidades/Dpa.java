/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;


import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author david
 */
@Entity
@Table(name = "dpa")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Dpa.findAll", query = "SELECT d FROM Dpa d")
    , @NamedQuery(name = "Dpa.findByIdDpa", query = "SELECT d FROM Dpa d WHERE d.idDpa = :idDpa")
    , @NamedQuery(name = "Dpa.findByNivel", query = "SELECT d FROM Dpa d WHERE d.nivel = :nivel")
    , @NamedQuery(name = "Dpa.findByTexto", query = "SELECT d FROM Dpa d WHERE d.texto = :texto")
    , @NamedQuery(name = "Dpa.findByCodDpa", query = "SELECT d FROM Dpa d WHERE d.codDpa = :codDpa")})
public class Dpa implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 6)
    @Column(name = "id_dpa")
    private String idDpa;
    @Column(name = "nivel")
    private Integer nivel;
    @Size(max = 100)
    @Column(name = "texto")
    private String texto;
    @Size(max = 4)
    @Column(name = "cod_dpa")
    private String codDpa;

    public Dpa() {
    }

    public Dpa(String idDpa) {
        this.idDpa = idDpa;
    }

    public String getIdDpa() {
        return idDpa;
    }

    public void setIdDpa(String idDpa) {
        this.idDpa = idDpa;
    }

    public Integer getNivel() {
        return nivel;
    }

    public void setNivel(Integer nivel) {
        this.nivel = nivel;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public String getCodDpa() {
        return codDpa;
    }

    public void setCodDpa(String codDpa) {
        this.codDpa = codDpa;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idDpa != null ? idDpa.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Dpa)) {
            return false;
        }
        Dpa other = (Dpa) object;
        if ((this.idDpa == null && other.idDpa != null) || (this.idDpa != null && !this.idDpa.equals(other.idDpa))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Dpa[ idDpa=" + idDpa + " ]";
    }
    
}
