<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOrganizacionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('organizacion', function (Blueprint $table) {
            $table->increments('org_organizacion_id');
            $table->text('org_ruc');
            $table->text('org_razon_social');
            $table->text('org_nro_productores_total')->nullable();
            $table->text('org_nro_productores_hombres')->nullable();
            $table->text('org_nro_productores_mujeres')->nullable();

			// COLUMNAS DE CONTROL
            $table->boolean('org_hecho_derecho')->default(true);
            $table->boolean('org_registro_seps')->default(true);
            $table->boolean('org_acreditado_mag')->default(true);
            $table->boolean('org_estado')->default(true);

            $table->date('org_fecha_inicio')->nullable();
            $table->date('org_fecha_fin')->nullable();

            $table->integer('org_usuario_inserta')->unsigned()->nullable();
            $table->timestamp('org_fecha_inserta')->nullable();

            $table->integer('org_usuario_actualiza')->unsigned()->nullable();
            $table->timestamp('org_fecha_actualiza')->nullable();

            $table->integer('org_usuario_elimina')->unsigned()->nullable();
            $table->timestamp('org_fecha_elimina')->nullable();

            // FOREINGS
            $table->unsignedInteger('org_ubicacion_geografica_id');
            $table->foreign('org_ubicacion_geografica_id')->references('uge_ubicacion_geografica_id')->on('ubicacion_geografica');

            $table->unsignedInteger('org_cialco_id');
            $table->foreign('org_cialco_id')->references('cia_cialco_id')->on('cialco');

            // TODO definir columna de relación API

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('organizacion');
    }
}