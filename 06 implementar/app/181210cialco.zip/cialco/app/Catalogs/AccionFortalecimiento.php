<?php

namespace App\Catalogs;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AccionFortalecimiento extends Model
{
    protected $table = 'accion_fortalecimiento';
    protected $primaryKey = 'afr_accion_fortalecimiento_id';
    const CREATED_AT = 'afr_fecha_inserta';
    const UPDATED_AT = 'afr_fecha_actualiza';

    use SoftDeletes;
    const DELETED_AT = 'afr_fecha_elimina';

    protected $append = [
        'texto_estado',
        'texto_estado_html'
    ];

    protected $fillable = [
        'afr_descripcion',
        'afr_estado',
        'afr_orden'
    ];
/*
    public function AccionFortalecimiento()
    {
        return $this->belongsTo('App\Catalogs\AccionFortalecimiento', 'afr_accion_fortalecimiento_id');
    }
*/
    public function getTextoEstadoAttribute()
    {
        return ($this->afr_estado ? 'Activo' : 'Inactivo');
    }

    public function getTextoEstadoHtmlAttribute()
    {
        if ($this->afr_estado)
            return ('<span class="label label-success">' . $this->texto_estado . '</span>');
        return ('<span class="label label-default">' . $this->texto_estado . '</span>');
    }
}