@extends('adminlte::page')

@section('title', 'Oferta Agropecuaria')

@section('content_header')
    <h1>Oferta Agropecuaria</h1>
@stop

@section('content')
    <div class="box box-primary">
        <div class="box-header with-border">
            <h2 class="page-header"><i class="fa fa-globe"></i>Detalle Oferta Agropecuaria</h2>

            <div class="row invoice-info">
                <div class="col-sm-4 invoice-col">
                    <p><b>ID: </b>{{$result->ofa_oferta_agropecuaria_id}}</p>
                    <p><b>Descripción: </b>{{$result->ofa_descripcion}}</p>
                    <p><b>Estado: </b>{!!$result->texto_estado_html!!}</p>

                </div>
            </div>
            <div class="box-footer">
                <a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
            </div>
        </div>

        @stop

        @section('css')
            <link rel="stylesheet" href="/css/admin_custom.css">
        @stop

        @section('js')

@stop