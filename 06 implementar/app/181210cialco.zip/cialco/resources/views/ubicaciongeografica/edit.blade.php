@extends('adminlte::page')
@section('title', 'Ubicación Geográfica')
@section('content_header')
    <h1>Ubicación Geográfica</h1>
@stop
@section('content')
    {!! Form::model($result, ['method' => 'PATCH','route' => ['ubicaciongeografica.update', 'id'=>$result->uge_ubicacion_geografica_id]]) !!}
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Catálogo Ubicación Geográfica</h3>
        </div>
        <div class="box-body">
            <div class="row"> <!-- ROW 1 -->
                <div class="col-md-3">
					<div class="form-group">
						<label for="uge_codigo_ubicacion">Código ubicación</label>
						{{ Form::text('uge_codigo_ubicacion',$result->uge_codigo_ubicacion,['class'=>'form-control'])}}
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="uge_nivel">Nivel</label>
						{{ Form::text('uge_nivel',$result->uge_nivel,['class'=>'form-control', 'required' => 'required|integer'])}}
					</div>
				</div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="uge_nombre">Nombre</label>
                        {{ Form::text('uge_nombre',$result->uge_nombre,['class'=>'form-control', 'required' => 'required|alpha'])}}
                    </div>
                </div>
            </div>
            <div class="row"> <!-- ROW 2 -->
                <div class="col-md-3">
					<div class="form-group">
						<label for="uge_padre_ubicacion">Padre Código ubicación</label>
						{{ Form::text('uge_padre_ubicacion',$result->uge_padre_ubicacion,['class'=>'form-control'])}}
					</div>
				</div>
				<div class="col-md-3">
					<div class="form-group">
						<label for="uge_fecha_inicio">Fecha Inicio</label></br>
							{{ Form::date('uge_fecha_inicio', $result->uge_fecha_inicio, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
							@include('include.error_form_element',['name'=>'uge_fecha_inicio'])
					</div>
				</div>
				<div class="col-md-3">
					<div class="form-group">
						<label for="uge_fecha_fin">Fecha Fin</label></br>
							{{ Form::date('uge_fecha_fin', $result->uge_fecha_fin, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
							@include('include.error_form_element',['name'=>'uge_fecha_fin'])
					</div>
				</div>
            </div>
            <div class="row"> <!-- ROW 3 -->
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="uge_estado">Estado</label>
                        {{ Form::select('uge_estado',['1' => 'Activo', '0' => 'Inactivo'],$result->uge_estado,['class'=>'form-control'])}}
                    </div>
                </div>
            </div>
        </div>
	<div class="box-footer">
		<button type="submit" class="btn btn-primary">Editar</button>
	</div>
	{!! Form::close() !!}
	<div class="box-footer">
		<a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
	</div>
    @stop
    @section('css')
      <link rel="stylesheet" href="/css/admin_custom.css">
    @stop
    @section('js')
@stop