<?php

namespace App\Http\Controllers;

use App\Entities\Cialco;
use App\Entities\CialcoFrecuencia;
use App\Http\Requests\StoreCialcoRequest;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;

class CialcoFrecuenciaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $grid = \DataGrid::source(CialcoFrecuencia::with('cialco'));
        $grid->add('cfr_cialco_frecuencia_id','ID', true)->style("width:100px");
        $grid->add('{{$cialco->cia_nombre}}','Cialco');
        $grid->add('cfr_hora_inicio','Hora inicio',true);
        $grid->add('cfr_hora_fin','Hora fin',true);
        $grid->add('cfr_dias','Días',true);
        $grid->add('cfr_descripcion','Descripción',true);
        $grid->add('cfr_fecha_inicio','Fecha Inicio',true);
        $grid->add('cfr_fecha_fin','Fecha Fin',true);
        $grid->add('texto_estado','Estado',true);
        $grid->add('Acciones','Acciones',false);
        $grid->add('<a href="/cialcofrecuencia/{{$cfr_cialco_frecuencia_id}}"><span class="glyphicon glyphicon-eye-open"> </span></span></a>','');
        $grid->link('/cialcofrecuencia/create',"Nuevo", "TR");
        $grid->add('<a href="/cialcofrecuencia/{{$cfr_cialco_frecuencia_id}}/edit"><span class="glyphicon glyphicon-pencil"> </span></span></a>','');
        $grid->paginate(20);

        $results = CialcoFrecuencia::get();
        return view('cialcofrecuencia.index',['results'=>$results,'grid'=>$grid]);
    }

	public function cialco()
    {
		$cialco = Cialco::with('cialco')->get();
        return view('cialco.show', compact('$cialco'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
		$cialcos = Cialco::pluck('cia_nombre', 'cia_cialco_id');
        return view('cialcofrecuencia.create', ['cialcos' => $cialcos]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreCialcoFrecuenciaRequest $request)
    {
        try {
            CialcoFrecuencia::create($request->all());
            Session::flash('flash_message', Config::get('session.create'));
        } catch (\Exception $e) {
            Session::flash('error', Config::get('session.error'));
            return back()->withInput();
        }

        return redirect()->route('cialcofrecuencia.show', ['id' => $cialcofrecuencia->cfr_cialco_frecuencia_id]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $result= CialcoFrecuencia::find($id);
        return view('cialcofrecuencia.show',['result' =>$result]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $result = CialcoFrecuencia::find($id);
		$cialcos = Cialco::pluck('cia_nombre', 'cia_cialco_id');
        return view('cialcofrecuencia.edit',['result'=>$result, 'cialcos'=>$cialcos]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $result = CialcoFrecuencia::find($id);

        request()->validate([
          'cfr_cialco_frecuencia_id' => 'required',
          'cfr_hora_inicio' => 'required',
          'cfr_hora_fin' => 'required',
          'cfr_dias' => 'required',
          'cfr_descripcion',
          'cfr_fecha_inicio' => 'required',
          'cfr_fecha_fin',
          'cfr_estado' => 'required',
        ]);

        $input = $request->all();
        $result->fill($input)->save();
        Session::flash('flash_message','El registro fue actualizado exitosamente');

        return redirect()->route('cialcofrecuencia.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}