<?php

namespace App\Http\Controllers\Catalogs;

use App\Catalogs\AccionFortalecimiento;
use App\Http\Requests\StoreAccionFortalecimientoRequest;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;

class AccionFortalecimientoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $results = AccionFortalecimiento::orderBy('afr_orden','ASC')->get();
        return view('accionfortalecimiento.index', ['results' => $results]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $order = [
            1 => 1,
            2 => 2,
            3 => 3,
            4 => 4,
            5 => 5,
            6 => 6,
        ];
        return view('accionfortalecimiento.create', ['order' => $order]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreAccionFortalecimientoRequest $request)
    {
        try {
            // INSERT
            $result = new AccionFortalecimiento;
            $result->afr_usuario_inserta = Auth::id();
            $result->fill($request->all())->save();

            Session::flash('flash_message', config('content.session.create'));
        } catch (\Exception $e) {
            Session::flash('error', config('content.session.error'));
            return back()->withInput();
        }
        return redirect()->route('accionfortalecimiento.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $result = AccionFortalecimiento::find($id);
        return view('accionfortalecimiento.show', ['result' => $result]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $order = [
            1 => 1,
            2 => 2,
            3 => 3,
            4 => 4,
            5 => 5,
            6 => 6,
        ];
        $result = AccionFortalecimiento::find($id);
        return view('accionfortalecimiento.edit', ['result' => $result, 'order' => $order]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try {
            request()->validate([
                'afr_descripcion' => 'required',
                'afr_estado' => 'required',
                'afr_orden' => 'required',
            ]);

            // UPDATE
            $result = AccionFortalecimiento::find($id);
            $result->afr_usuario_actualiza = Auth::id();
            $result->fill($request->all())->update();

            Session::flash('flash_message', config('content.session.update'));
        } catch (\Exception $e) {
            Session::flash('error', content('content.session.error'));
            return back()->withInput();
        }
        return redirect()->route('accionfortalecimiento.index');
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // NOT REQUIRED
        /*$result=AccionFortalecimiento::find($id);
        $result->fre_usuario_elimina=Auth::id();
        $result->delete();
         return redirect()->route('accionfortalecimiento.index')->with('success'); */
    }
}