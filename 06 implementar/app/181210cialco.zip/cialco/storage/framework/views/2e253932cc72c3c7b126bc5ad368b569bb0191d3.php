

<?php $__env->startSection('title', 'Modalidades'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Modalidades</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="box box-primary">
        <div class="box-header with-border">
            <h2 class="page-header">
                <i class="fa fa-globe"></i> Listado
                <a class="btn btn-sm btn-default pull-right" href="<?php echo e(route('modalidad.create')); ?>">Nuevo</a>
            </h2>
        </div>
        <div class="row">
            <div class="col-xs-12 table-responsive">
                <table class="table table-striped">
                        <tr>
                          <th>ID</th>
                          <th>Descripción</th>
                          <th>Orden</th>
						  <th>Fecha Inicio</th>
						  <th>Fecha Fin</th>
                          <th>Fecha de creación</th>
                          <th>Estado</th>
                          <th>Acciones</th>
                        </tr>
                        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->mod_modalidad_id); ?></td>
                            <td><?php echo e($item->mod_descripcion); ?></td>
                            <td><?php echo e($item->mod_orden); ?></td>
						    <td><?php echo e($item->mod_fecha_inicio); ?></td>
						    <td><?php echo e($item->mod_fecha_fin); ?></td>
                            <td><?php echo e($item->mod_fecha_inserta); ?></td>
                            <td><?php echo $item->texto_estado_html; ?></td>
                            <td>
                                <a href="<?php echo e(route('modalidad.show',['id'=>$item->mod_modalidad_id])); ?> "class="label label-primary">Ver</a>
                                <a href="<?php echo e(route('modalidad.edit',['id'=>$item->mod_modalidad_id])); ?>" class="label label-primary">Editar</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </table>
            </div>
        </div>


        <div class="box-footer">
            <a class="btn btn-sm btn-default pull-right" href="<?php echo e(route('modalidad.create')); ?>">Nuevo</a>
        </div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>

    <link rel="stylesheet" href="/css/admin_custom.css">

<?php $__env->stopSection(); ?>



<?php $__env->startSection('js'); ?>

    <script> console.log('Hi!'); </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>