@extends('adminlte::page')

@section('title', 'Nueva Dirección')

@section('content_header')
    <h1>Dirección</h1>
@stop

@section('content')
    @include('include.alert')
   {!! Form::open(['route' => 'cialco.direccion.store', 'method' => 'post']) !!}

    <div class="box box-primary">
        {{ Form::hidden('dir_cialco_id',$cialco->cia_cialco_id,['class'=>'form-control'])}}
        <div class="box-header with-border">
            <h3 class="box-title">Nueva</h3>
        </div>
        <div class="box-body">
			<div class="row">
				<div class="col-md-12">
					<div class="form-group">
						<label for="dir_sector">Sector</label>
						{{ Form::text('dir_sector',null,['class'=>'form-control', 'required' => 'required|alpha'])}}
						@include('include.error_form_element',['name'=>'dir_sector'])
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<label for="dir_calle_principal">Calle Principal</label>
						{{ Form::text('dir_calle_principal',null,['class'=>'form-control', 'required' => 'required|alpha'])}}
						@include('include.error_form_element',['name'=>'dir_calle_principal'])
					</div>
				</div>
				<div class="col-md-2">
					<div class="form-group">
						<label for="dir_numero">Número #</label>
						{{ Form::text('dir_numero',null,['class'=>'form-control', 'required' => 'required|alpha'])}}
						@include('include.error_form_element',['name'=>'dir_numero'])
					</div>
				</div>
			</div>

			<div class="row">
			  <div class="col-md-6">
				<div class="form-group">
				  <label for="dir_calle_secundaria">Calle Secundaria</label>
				  {{ Form::text('dir_calle_secundaria',null,['class'=>'form-control', 'required' => 'required|alpha'])}}
					@include('include.error_form_element',['name'=>'dir_calle_secundaria'])
				</div>
			  </div>
			  <div class="col-md-6">
				<div class="form-group">
				  <label for="dir_referencia">Referencia</label>
				  {{ Form::text('dir_referencia',null,['class'=>'form-control', 'required' => 'required|alpha'])}}
				  @include('include.error_form_element',['name'=>'dir_referencia'])
			   </div>
			 </div>
			 <div class="col-md-6">
				<div class="form-group">
				  <label for="dir_consumidores">Consumidores</label>
				  {{ Form::number('dir_consumidores',null,['class'=>'form-control', 'required' => 'required|integer'])}}
				  @include('include.error_form_element',['name'=>'dir_consumidores'])
			   </div>
			 </div>
		   </div>
               <!-- /.row -->

		<div class="row"><!--  ROW 2 -->
				 <div class="col-md-4">
				   <div class="form-group">
					 <label for="exampleInputEmail1">Provincia</label>
					 <select class="form-control">
					   <option>option 1</option>
					   <option>option 2</option>
					   <option>option 3</option>
					   <option>option 4</option>
					   <option>option 5</option>
					 </select>

					 <p>
					   <span class="label label-info">Dropdown? de base actual existe? no nueva?</span>
					 </p>
				   </div>
				 </div>

				 <div class="col-md-4">
				   <div class="form-group">
					 <label for="exampleInputEmail1">Cantón</label>
					 <select class="form-control">
					   <option>option 1</option>
					   <option>option 2</option>
					   <option>option 3</option>
					   <option>option 4</option>
					   <option>option 5</option>
					 </select>
					 <p>
					   <span class="label label-info">Dropdown? de base actual existe? no nueva?</span>
					 </p>
				   </div>
				 </div>

				 <div class="col-md-4">
				   <div class="form-group">
					 <label for="exampleInputEmail1">Parroquia</label>
					 <select class="form-control">
					   <option>option 1</option>
					   <option>option 2</option>
					   <option>option 3</option>
					   <option>option 4</option>
					   <option>option 5</option>
					 </select>
					 <p>
					   <span class="label label-info">Dropdown? de base actual existe? no nueva?</span>
					 </p>
				   </div>
				 </div>
		   </div><!-- CLOSE ROW 2 -->

		  <div class="row"><!--  ROW 3 -->
		    <div class="col-md-6">
		    <label for="dir_fecha_inicio">Fecha Inicio</label></br>
				{{ Form::date('dir_fecha_inicio', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
				@include('include.error_form_element',['name'=>'dir_fecha_inicio'])
		    </div>
		    <div class="col-md-6">
		      <label for="dir_fecha_fin">Fecha Fin</label></br>
				{{ Form::date('dir_fecha_fin', null, array('id' => 'datepicker({changeMonth: true, changeYear: true, dateFormat: "yyyy-mm-dd", firstDay: 1});')) }}
				@include('include.error_form_element',['name'=>'dir_fecha_fin'])
		      </div>
		    <div class="col-md-6">
			  <label for="dir_estado">Estado</label>
				{{ Form::select('dir_estado',['1' => 'Activo', '0' => 'Inactivo'],null,['class'=>'form-control'])}}
            </div>
		  </div><!-- CLOSE ROW 3 -->
        </div>

	<div class="box-footer">
		<button type="submit" class="btn btn-primary">Guardar</button>
	</div>
	{!! Form::close() !!}
	<div class="box-footer">
		<a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
	</div>
	@stop
	@section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
	@stop
	@section('js')
		<script> console.log('Hi!'); </script>
@stop