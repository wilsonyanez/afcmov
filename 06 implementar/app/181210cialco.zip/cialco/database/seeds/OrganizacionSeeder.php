<?php

use Illuminate\Database\Seeder;

class OrganizacionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('organizacion')->delete();
        $faker = Faker\Factory::create();
        for ($i = 0; $i < 200; $i++) {
            \DB::table('organizacion')->insert([
              'org_hecho_derecho' =>$faker->numberBetween(0,1),
              'org_ruc' =>$faker->ean13,
              'org_razon_social' =>$faker->name,
              'org_registro_seps' =>$faker->numberBetween(0,1),
              'org_acreditado_mag' =>$faker->numberBetween(0,1),
              'org_nro_productores_total' => $faker->numberBetween(0, 50),
              'org_nro_productores_hombres' => $faker->numberBetween(0, 25),
              'org_nro_productores_mujeres' => $faker->numberBetween(0, 25),
              'org_fecha_inicio' => date_create('now UTC'),
              'org_fecha_fin' => date_create('now UTC'),
              'org_fecha_inserta' => date_create('now UTC'),
              'org_fecha_actualiza' => date_create('now UTC'),
              'org_ubicacion_geografica_id' => $faker->numberBetween(1, 349),
              'org_cialco_id' => $faker->numberBetween(1, 100),
            ]);
        }
    }
}