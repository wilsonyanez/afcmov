
<?php $__env->startSection('title', 'Productores'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Productores</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::model($result, ['method' => 'PATCH','route' => ['productor.update', 'id'=>$result->pro_productor_id]]); ?>

    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Productor</h3>
        </div>
        <div class="box-body">
            <div class="row"> <!-- ROW 1 -->
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="pro_dispone_sello_afc">Dispone Sello Afc?</label>
                        <?php echo e(Form::select('pro_dispone_sello_afc',['1' => 'SI', '0' => 'NO'],$result->pro_dispone_sello_afc,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'pro_dispone_sello_afc'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="pro_identificacion_sello_afc">Identificacion sello AFC</label>
						<?php echo e(Form::text('pro_identificacion_sello_afc',$result->pro_identificacion_sello_afc,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'pro_identificacion_sello_afc'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="pro_numero_cedula">Número cédula</label>
						<?php echo e(Form::text('pro_numero_cedula',$result->pro_numero_cedula,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'pro_numero_cedula'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>

            <div class="row"> <!-- ROW 2 -->
                <div class="col-md-3">
					<div class="form-group">
						<label for="pro_nombres">Nombres</label>
						<?php echo e(Form::text('pro_nombres',$result->pro_nombres,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'pro_nombres'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="pro_apellidos">Apellidos</label>
                        <?php echo e(Form::text('pro_apellidos',$result->pro_apellidos,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'pro_apellidos'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="pro_genero">Género</label>
                        <?php echo e(Form::select('pro_genero',['1' => 'Masculino', '0' => 'Femenino'],$result->pro_genero,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'pro_genero'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
            <div class="row"> <!-- ROW 3 -->
                <div class="col-md-3">
					<div class="form-group">
						<label for="pro_fecha_nacimiento">Fecha Nacimiento</label>
						<?php echo e(Form::text('pro_fecha_nacimiento',$result->pro_fecha_nacimiento,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'pro_fecha_nacimiento'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
                <div class="col-md-3">
					<div class="form-group">
						<label for="pro_nacionalidad">Nacionalidad</label>
						<?php echo e(Form::text('pro_nacionalidad',$result->pro_nacionalidad,['class'=>'form-control'])); ?>

                        <?php echo $__env->make('include.error_form_element',['name'=>'pro_nacionalidad'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
            </div>
            <div class="row"> <!-- ROW 4 -->
				<div class="col-md-3">
					<div class="form-group">
						<label for="pro_fecha_inicio">Fecha Inicio</label></br>
						<?php echo e(Form::date('pro_fecha_inicio',$result->pro_fecha_inicio, array('id' => 'datepicker'))); ?>

						<?php echo $__env->make('include.error_form_element',['name'=>'pro_fecha_inicio'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
                </div>
				<div class="col-md-3">
					<div class="form-group">
					    <label for="pro_fecha_fin">Fecha Fin</label></br>
						<?php echo e(Form::date('pro_fecha_fin',$result->pro_fecha_fin, array('id' => 'datepicker'))); ?>

						<?php echo $__env->make('include.error_form_element',['name'=>'pro_fecha_inicio'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="pro_estado">Estado</label>
                        <?php echo e(Form::select('pro_estado',['1' => 'Activo', '0' => 'Inactivo'],$result->pro_estado,['class'=>'form-control'])); ?>

                    </div>
                </div>
            </div>
        </div>

        <div class="box-footer">
            <button type="submit" class="btn btn-primary">Editar</button>
        </div>
        <?php echo Form::close(); ?>

        <div class="box-footer">
            <a href="<?php echo e(URL::previous()); ?>" class="pull-right btn btn-default">Regresar</a>
        </div>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('css'); ?>
            <link rel="stylesheet" href="/css/admin_custom.css">
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>