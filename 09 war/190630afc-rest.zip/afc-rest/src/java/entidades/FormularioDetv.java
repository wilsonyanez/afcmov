/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author david
 */
@Entity
@Table(name = "formulario_detv")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "FormularioDetv.findAll", query = "SELECT f FROM FormularioDetv f")
    , @NamedQuery(name = "FormularioDetv.findByIdFdetv", query = "SELECT f FROM FormularioDetv f WHERE f.idFdetv = :idFdetv")
    , @NamedQuery(name = "FormularioDetv.findByCodMod", query = "SELECT f FROM FormularioDetv f WHERE f.codMod = :codMod")
    , @NamedQuery(name = "FormularioDetv.findByOrden", query = "SELECT f FROM FormularioDetv f WHERE f.orden = :orden")
    , @NamedQuery(name = "FormularioDetv.findByCodPreg", query = "SELECT f FROM FormularioDetv f WHERE f.codPreg = :codPreg")
    , @NamedQuery(name = "FormularioDetv.findByValor", query = "SELECT f FROM FormularioDetv f WHERE f.valor = :valor")
    , @NamedQuery(name = "FormularioDetv.findByClave", query = "SELECT f FROM FormularioDetv f WHERE f.clave = :clave")})
public class FormularioDetv implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_fdetv")
    private Integer idFdetv;
    @Size(max = 10)
    @Column(name = "cod_mod")
    private String codMod;
    @Column(name = "orden")
    private Integer orden;
    @Size(max = 20)
    @Column(name = "cod_preg")
    private String codPreg;
    @Size(max = 2147483647)
    @Column(name = "valor")
    private String valor;
    @Size(max = 30)
    @Column(name = "clave")
    private String clave;
    @JoinColumn(name = "cod_form", referencedColumnName = "id_formulario")
    @ManyToOne
    private Formulario codForm;

    public FormularioDetv() {
    }

    public FormularioDetv(Integer idFdetv) {
        this.idFdetv = idFdetv;
    }

    public Integer getIdFdetv() {
        return idFdetv;
    }

    public void setIdFdetv(Integer idFdetv) {
        this.idFdetv = idFdetv;
    }

    public String getCodMod() {
        return codMod;
    }

    public void setCodMod(String codMod) {
        this.codMod = codMod;
    }

    public Integer getOrden() {
        return orden;
    }

    public void setOrden(Integer orden) {
        this.orden = orden;
    }

    public String getCodPreg() {
        return codPreg;
    }

    public void setCodPreg(String codPreg) {
        this.codPreg = codPreg;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public Formulario getCodForm() {
        return codForm;
    }

    public void setCodForm(Formulario codForm) {
        this.codForm = codForm;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idFdetv != null ? idFdetv.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof FormularioDetv)) {
            return false;
        }
        FormularioDetv other = (FormularioDetv) object;
        if ((this.idFdetv == null && other.idFdetv != null) || (this.idFdetv != null && !this.idFdetv.equals(other.idFdetv))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.FormularioDetv[ idFdetv=" + idFdetv + " ]";
    }
    
}
