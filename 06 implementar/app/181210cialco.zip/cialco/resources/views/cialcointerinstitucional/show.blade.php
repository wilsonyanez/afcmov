@extends('adminlte::page')
@section('title', 'Apoyo Interinstitucional')
@section('content_header')
    <h1>Apoyo Interinstitucional</h1>
@stop
@section('content')
    <div class="box box-primary">
        <div class="box-header with-border">
            <h2 class="page-header"><i class="fa fa-globe"></i>Detalle Apoyo Interinstitucional</h2>

            <div class="row invoice-info">
                <div class="col-sm-4 invoice-col">
                    <p><b>ID: </b>{{$result->int_cialco_interins_id}}</p>
                    <address>
                        <strong>Cialco: </strong> {{$result->cialco->cia_nombre}}<br>
                        <strong>Accion Fortalecimiento: </strong>{{$result->accionfortalecimiento->afr_descripcion}}<br>
                        <strong>Apoyo Institucional: </strong> {{$result->apoyoinstitucional->ain_descripcion}}<br>
                    </address>
						<p><b>Provincial: </b>{!!$result->texto_provincial_html!!}   {{$result->ubicacionprovincial->uge_nombre}}</p>
						<p><b>Cantonal: </b>{!!$result->texto_cantonal_html!!}   {{$result->ubicacioncantonal->uge_nombre}}</p>
						<p><b>Parroquial: </b>{!!$result->texto_parroquial_html!!}   {{$result->ubicacionparroquial->uge_nombre}}</p> 
                    <address>
						<p><b>Otro: </b>{!!$result->texto_otro_html!!}</p>
						<p><b>Descripción: </b>{{$result->int_descripcion}}</p>
                    </address>					
                    <p><b>Fecha Inicio: </b>{{$result->int_fecha_inicio}}</p>
                    <p><b>Fecha Fin: </b>{{$result->int_fecha_fin}}</p>
                    <p><b>Estado: </b>{!!$result->texto_estado_html!!}</p>
                    <p><b>Fecha Creación: </b>{{$result->int_fecha_inserta}}</p>
                </div>
            </div>
            <div class="box-footer">
                <a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
            </div>
        </div>

	@stop
	@section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
	@stop
	@section('js')
@stop