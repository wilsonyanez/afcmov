@extends('adminlte::page')
@section('title', 'Acciones de Fortalecimiento')
@section('content_header')
    <h1>Acciones de Fortalecimiento</h1>
@stop
	@section('content')
    <div class="box box-primary">
        <div class="box-header with-border">
            <h2 class="page-header"><i class="fa fa-globe"></i>Detalle Acciones de Fortalecimiento</h2>
            <div class="row invoice-info">
                <div class="col-sm-4 invoice-col">
                    <p><b>ID: </b>{{$result->afr_accion_fortalecimiento_id}}</p>
                    <p><b>Descripción: </b>{{$result->afr_descripcion}}</p>
                    <p><b>Orden: </b>{{$result->afr_orden}}</p>
                    <p><b>Estado: </b>{!!$result->texto_estado_html!!}</p>
                </div>
            </div>
            <div class="box-footer">
                <a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
            </div>
        </div>
	@stop
	@section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
	@stop
	@section('js')
		<script> console.log('Hi!'); </script>
@stop