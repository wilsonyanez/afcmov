<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('producto', function (Blueprint $table) {
            $table->increments('prd_producto_id');
            $table->text('prd_codigo_producto')->unsigned();
            $table->text('prd_nivel')->unsigned();
            $table->text('prd_nombre');
            $table->text('prd_padre_producto')->unsigned()->nullable();

			// COLUMNAS DE CONTROL
            $table->boolean('prd_estado')->default(true);

            $table->date('prd_fecha_inicio');
            $table->date('prd_fecha_fin')->nullable();

            $table->integer('prd_usuario_inserta')->unsigned()->nullable();
            $table->timestamp('prd_fecha_inserta')->nullable();

            $table->integer('prd_usuario_actualiza')->unsigned()->nullable();
            $table->timestamp('prd_fecha_actualiza')->nullable();

            $table->integer('prd_usuario_elimina')->unsigned()->nullable();
            $table->timestamp('prd_fecha_elimina')->nullable();

            // FOREINGS

            // TODO definir columna de relación API
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('producto');
    }
}