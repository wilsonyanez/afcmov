@extends('adminlte::page')
@section('title', 'Cialco Productos')
@section('content_header')
    <h1>Cialco Productos</h1>
@stop
@section('content')
    <div class="box box-primary">
        <div class="box-header with-border">
            <h2 class="page-header"><i class="fa fa-globe"></i>Detalle Cialco Productos</h2>
            <div class="row invoice-info">
                <div class="col-sm-4 invoice-col">
                    <p><b>ID: </b>{{$result->cpr_cialco_producto_id}}</p>
                    <address>
                        <strong>Cialco</strong><br>
                        {{$result->cialco->cia_nombre}}<br>
                         <strong>Producto</strong><br>
                        {{$result->producto->prd_nombre}}<br>
                     </address>
                    <p><b>Año: </b>{{$result->cpr_ejercicio}}</p>
                    <p><b>Mes: </b>{{$result->cpr_periodo}}</p>
                    <p><b>Precio: </b>{{$result->cpr_precio}}</p>
                    <p><b>Unidad (Kg): </b>{!!$result->texto_unidad_html!!}</p>
                    <p><b>Fecha Inicio: </b>{{$result->cpr_fecha_inicio}}</p>
                    <p><b>Fecha Fin: </b>{{$result->cpr_fecha_fin}}</p>
                    <p><b>Estado: </b>{!!$result->texto_estado_html!!}</p>
                    <p><b>Fecha Creación: </b>{{$result->cpr_fecha_inserta}}</p>
                </div>
            </div>
            <div class="box-footer">
                <a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
            </div>
        </div>
	@stop
	@section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
	@stop
	@section('js')
@stop