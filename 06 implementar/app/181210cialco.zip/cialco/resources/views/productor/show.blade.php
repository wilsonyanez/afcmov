@extends('adminlte::page')
@section('title', 'Productores')
@section('content_header')
    <h1>Productores</h1>
@stop
@section('content')
    <div class="box box-primary">
        <div class="box-header with-border">
            <h2 class="page-header"><i class="fa fa-globe"></i>Detalle Productores</h2>

            <div class="row invoice-info">
                <div class="col-sm-4 invoice-col">
                    <p><b>ID: </b>{{$result->pro_productor_id}}</p>
                    <p><b>Dispone Sello Afc: </b>{!!$result->texto_dispone_sello_afc_html!!}</p>
                    <p><b>Identificacion Sello Afc: </b>{{$result->pro_identificacion_sello_afc}}</p>
                    <p><b>Número Cédula: </b>{{$result->pro_numero_cedula}}</p>
                    <p><b>Nombres: </b>{{$result->pro_nombres}}</p>
                    <p><b>Apellidos: </b>{{$result->pro_apellidos}}</p>
                    <p><b>Género: </b>{!!$result->texto_genero_html!!}</p>
                    <p><b>Fecha Nacimiento: </b>{{$result->pro_fecha_nacimiento}}</p>
                    <p><b>Nacionalidad: </b>{{$result->pro_nacionalidad}}</p>
                    <p><b>Fecha Inicio: </b>{{$result->pro_fecha_inicio}}</p>
                    <p><b>Fecha Fin: </b>{{$result->pro_fecha_fin}}</p>
                    <p><b>Estado: </b>{!!$result->texto_estado_html!!}</p>
                    <p><b>Fecha Creación: </b>{{$result->pro_fecha_inserta}}</p>
                </div>
            </div>
            <div class="box-footer">
                <a href="{{ URL::previous() }}" class="pull-right btn btn-default">Regresar</a>
            </div>
        </div>

	@stop
	@section('css')
		<link rel="stylesheet" href="/css/admin_custom.css">
	@stop
	@section('js')
@stop