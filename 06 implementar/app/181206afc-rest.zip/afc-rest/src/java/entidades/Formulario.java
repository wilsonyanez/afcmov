/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Wilson Yánez
 */
@Entity
@Table(name = "formulario")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Formulario.findAll", query = "SELECT f FROM Formulario f")
    , @NamedQuery(name = "Formulario.findByIdFormulario", query = "SELECT f FROM Formulario f WHERE f.idFormulario = :idFormulario")
    , @NamedQuery(name = "Formulario.findByNumero", query = "SELECT f FROM Formulario f WHERE f.numero = :numero")
    , @NamedQuery(name = "Formulario.findByFecha", query = "SELECT f FROM Formulario f WHERE f.fecha = :fecha")
    , @NamedQuery(name = "Formulario.findByReferencia", query = "SELECT f FROM Formulario f WHERE f.referencia = :referencia")
    , @NamedQuery(name = "Formulario.findByEstadoP", query = "SELECT f FROM Formulario f WHERE f.estadoP = :estadoP")
    , @NamedQuery(name = "Formulario.findByEstadoT", query = "SELECT f FROM Formulario f WHERE f.estadoT = :estadoT")
    , @NamedQuery(name = "Formulario.findByClave", query = "SELECT f FROM Formulario f WHERE f.clave = :clave")
    , @NamedQuery(name = "Formulario.findByLongUsuario", query = "SELECT f FROM Formulario f WHERE f.longUsuario = :longUsuario")
    , @NamedQuery(name = "Formulario.findByLongIdentificador", query = "SELECT f FROM Formulario f WHERE f.longIdentificador = :longIdentificador")
})
public class Formulario implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_formulario")
    private Integer idFormulario;
    @Size(max = 50)
    @Column(name = "numero")
    private String numero;
    @Column(name = "fecha")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fecha;
    @Size(max = 200)
    @Column(name = "referencia")
    private String referencia;
    @Size(max = 1)
    @Column(name = "estado_p")
    private String estadoP;
    @Size(max = 1)
    @Column(name = "estado_t")
    private String estadoT;
    @Size(max = 30)
    @Column(name = "clave")
    private String clave;
    @Column(name = "cod_usuario")
    private String codUsuario;
    @Column(name = "long_usuario")
    private Integer longUsuario;
    @Column(name = "long_identificador")
    private Integer longIdentificador;

    public Formulario() {
    }

    public Formulario(Integer idFormulario) {
        this.idFormulario = idFormulario;
    }

    public Integer getIdFormulario() {
        return idFormulario;
    }

    public void setIdFormulario(Integer idFormulario) {
        this.idFormulario = idFormulario;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public String getEstadoP() {
        return estadoP;
    }

    public void setEstadoP(String estadoP) {
        this.estadoP = estadoP;
    }

    public String getEstadoT() {
        return estadoT;
    }

    public void setEstadoT(String estadoT) {
        this.estadoT = estadoT;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(String codUsuario) {
        this.codUsuario = codUsuario;
    }

    public Integer getLongUsuario() {
        return longUsuario;
    }

    public void setLongUsuario(Integer longUsuario) {
        this.longUsuario = longUsuario;
    }

    public Integer getLongIdentificador() {
        return longIdentificador;
    }

    public void setLongIdentificador(Integer longIdentificador) {
        this.longIdentificador = longIdentificador;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idFormulario != null ? idFormulario.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Formulario)) {
            return false;
        }
        Formulario other = (Formulario) object;
        if ((this.idFormulario == null && other.idFormulario != null) || (this.idFormulario != null && !this.idFormulario.equals(other.idFormulario))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Formulario[ idFormulario=" + idFormulario + " ]";
    }
    
}
