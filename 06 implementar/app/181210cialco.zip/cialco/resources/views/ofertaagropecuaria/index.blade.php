@extends('adminlte::page')
@section('title', 'Oferta Agropecuaria')
@section('content_header')
    <h1>Oferta Agropecuaria</h1>
@stop
@section('content')
    @include('include.alert')

    <div class="box box-primary">
        <div class="box-header with-border">
            <h2 class="page-header">
                <i class="fa fa-globe"></i> Listado
                <a class="btn btn-sm btn-default pull-right" href="{{route('ofertaagropecuaria.create')}}">Nuevo</a>
            </h2>
        </div>
        <div class="row">
            <div class="col-xs-12 table-responsive">
                <table class="table table-striped">
                <tr>

                  <th>ID</th>
                  <th>Descripción</th>
                  <th>Orden</th>
                  <th>Fecha Inicio</th>
                  <th>Fecha Fin</th>
                  <th>Fecha Creación</th>
                  <th>Estado</th>
				  <th>Acciones</th>
                </tr>
                @foreach($results as $key=>$item)
                <tr>
                       <td>{{$key+1}}</td>
                       <td>{{$item->ofa_descripcion}}</td>
                       <td>{{$item->ofa_orden}}</td>
					   <td>{{$item->ofa_fecha_inicio}}</td>
					   <td>{{$item->ofa_fecha_fin}}</td>
                       <td>{{$item->ofa_fecha_inserta}}</td>
                       <td>{!!$item->texto_estado_html!!}</td>
                        <td>
                            <a href="{{route('ofertaagropecuaria.show',['id'=>$item->ofa_oferta_agropecuaria_id])}} "class="label label-primary">Ver</a>
                            <a href="{{route('ofertaagropecuaria.edit',['id'=>$item->ofa_oferta_agropecuaria_id])}}" class="label label-primary">Editar</a>
                        </td>
                </tr>
                @endforeach
              </table>
        </div>
        </div>
        <div class="box-footer">
        {{--<a class="btn btn-sm btn-default pull-right" href="{{route('cialco.create')}}">Nuevo</a>--}}
        </div>
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')

@stop