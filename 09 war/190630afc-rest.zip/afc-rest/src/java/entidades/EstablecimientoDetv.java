/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author david
 */
@Entity
@Table(name = "establecimiento_detv")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "EstablecimientoDetv.findAll", query = "SELECT e FROM EstablecimientoDetv e")
    , @NamedQuery(name = "EstablecimientoDetv.findByIdEdetv", query = "SELECT e FROM EstablecimientoDetv e WHERE e.idEdetv = :idEdetv")
    , @NamedQuery(name = "EstablecimientoDetv.findByCodMod", query = "SELECT e FROM EstablecimientoDetv e WHERE e.codMod = :codMod")
    , @NamedQuery(name = "EstablecimientoDetv.findByOrden", query = "SELECT e FROM EstablecimientoDetv e WHERE e.orden = :orden")
    , @NamedQuery(name = "EstablecimientoDetv.findByCodPreg", query = "SELECT e FROM EstablecimientoDetv e WHERE e.codPreg = :codPreg")
    , @NamedQuery(name = "EstablecimientoDetv.findByValor", query = "SELECT e FROM EstablecimientoDetv e WHERE e.valor = :valor")
    , @NamedQuery(name = "EstablecimientoDetv.findByClave", query = "SELECT e FROM EstablecimientoDetv e WHERE e.clave = :clave")})
public class EstablecimientoDetv implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_edetv")
    private Integer idEdetv;
    @Size(max = 10)
    @Column(name = "cod_mod")
    private String codMod;
    @Column(name = "orden")
    private Integer orden;
    @Size(max = 20)
    @Column(name = "cod_preg")
    private String codPreg;
    @Size(max = 2147483647)
    @Column(name = "valor")
    private String valor;
    @Size(max = 30)
    @Column(name = "clave")
    private String clave;
    @JoinColumn(name = "cod_esta", referencedColumnName = "id_establecimiento")
    @ManyToOne
    private Establecimiento codEsta;

    public EstablecimientoDetv() {
    }

    public EstablecimientoDetv(Integer idEdetv) {
        this.idEdetv = idEdetv;
    }

    public Integer getIdEdetv() {
        return idEdetv;
    }

    public void setIdEdetv(Integer idEdetv) {
        this.idEdetv = idEdetv;
    }

    public String getCodMod() {
        return codMod;
    }

    public void setCodMod(String codMod) {
        this.codMod = codMod;
    }

    public Integer getOrden() {
        return orden;
    }

    public void setOrden(Integer orden) {
        this.orden = orden;
    }

    public String getCodPreg() {
        return codPreg;
    }

    public void setCodPreg(String codPreg) {
        this.codPreg = codPreg;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public Establecimiento getCodEsta() {
        return codEsta;
    }

    public void setCodEsta(Establecimiento codEsta) {
        this.codEsta = codEsta;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idEdetv != null ? idEdetv.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof EstablecimientoDetv)) {
            return false;
        }
        EstablecimientoDetv other = (EstablecimientoDetv) object;
        if ((this.idEdetv == null && other.idEdetv != null) || (this.idEdetv != null && !this.idEdetv.equals(other.idEdetv))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.EstablecimientoDetv[ idEdetv=" + idEdetv + " ]";
    }
    
}
