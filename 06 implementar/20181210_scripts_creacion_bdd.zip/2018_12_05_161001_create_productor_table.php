<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductorTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('productor', function (Blueprint $table) {
            $table->increments('pro_productor_id');
            $table->text('pro_identificacion_sello_afc');
            $table->text('pro_numero_cedula');
            $table->text('pro_nombres');
            $table->text('pro_apellidos');
            $table->timestamp('pro_fecha_nacimiento');
            $table->text('pro_nacionalidad');

            // COLUMNAS DE CONTROL
            $table->boolean('pro_dispone_sello_afc')->default(true);
            $table->boolean('pro_genero')->default(true);
            $table->boolean('pro_estado')->default(true);

            $table->date('pro_fecha_inicio')->nullable();
            $table->date('pro_fecha_fin')->nullable();

            $table->integer('pro_usuario_inserta')->unsigned()->nullable();
            $table->timestamp('pro_fecha_inserta')->nullable();

            $table->integer('pro_usuario_actualiza')->unsigned()->nullable();
            $table->timestamp('pro_fecha_actualiza')->nullable();

            $table->integer('pro_usuario_elimina')->unsigned()->nullable();
            $table->timestamp('pro_fecha_elimina')->nullable();

            // FOREINGS
            $table->unsignedInteger('pro_cialco_id');
            $table->foreign('pro_cialco_id')->references('cia_cialco_id')->on('cialco');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('productor');
    }
}